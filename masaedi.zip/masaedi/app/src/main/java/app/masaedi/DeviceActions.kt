package app.masaedi

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneId
import kotlin.math.roundToInt

data class ActionResult(val ok: Boolean, val message: String, val leftApp: Boolean)

object DeviceActions {

    private val ALIASES = mapOf(
        "واتساب" to "whatsapp", "واتس اب" to "whatsapp", "واتس" to "whatsapp",
        "يوتيوب" to "youtube", "تلغرام" to "telegram", "تليجرام" to "telegram",
        "انستغرام" to "instagram", "انستا" to "instagram", "سناب" to "snapchat",
        "سناب شات" to "snapchat", "تيك توك" to "tiktok", "كاميرا" to "camera",
        "الكاميرا" to "camera", "اعدادات" to "settings", "الاعدادات" to "settings",
        "خرائط" to "maps", "الخرائط" to "maps", "جيميل" to "gmail", "كروم" to "chrome",
        "المتصفح" to "browser", "متصفح" to "browser", "الصور" to "photos",
        "معرض الصور" to "gallery", "الحاسبه" to "calculator", "الساعه" to "clock",
        "الرسائل" to "messages", "الهاتف" to "phone", "جهات الاتصال" to "contacts",
        "الملفات" to "files", "الموسيقى" to "music", "موسيقى" to "music",
        "متجر بلاي" to "play store", "بلاي ستور" to "play store",
        "تويتر" to "x", "فيسبوك" to "facebook", "ماسنجر" to "messenger"
    )

    private fun norm(s: String): String {
        return s.lowercase().trim()
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace('ة', 'ه').replace('ى', 'ي')
            .replace(Regex("[\\u064B-\\u065F]"), "")
    }

    fun run(ctx: Context, a: JSONObject): ActionResult {
        return try {
            when (a.optString("type")) {
                "open_app" -> openApp(ctx, a.optString("name"))
                "call" -> call(ctx, a.optString("to"))
                "sms" -> sms(ctx, a.optString("to"), a.optString("text"))
                "whatsapp" -> whatsapp(ctx, a.optString("to"), a.optString("text"))
                "alarm" -> alarm(ctx, a)
                "timer" -> timer(ctx, a)
                "web_search" -> webSearch(ctx, a.optString("query"))
                "open_url" -> openUrl(ctx, a.optString("url"))
                "navigate" -> navigate(ctx, a.optString("destination"))
                "settings" -> settings(ctx, a.optString("page"))
                "flashlight" -> flashlight(ctx, a.optBoolean("on", true))
                "volume" -> volume(ctx, a)
                "music" -> music(ctx, a.optString("command"))
                "camera" -> launch(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "ما قدرت أفتح الكاميرا")
                "calendar" -> calendar(ctx, a)
                "copy" -> copy(ctx, a.optString("text"))
                "share" -> share(ctx, a.optString("text"))
                else -> ActionResult(false, "ما أعرف هذا الأمر", false)
            }
        } catch (e: Exception) {
            ActionResult(false, "صار خطأ وأنا أنفذ الأمر", false)
        }
    }

    private fun launch(ctx: Context, intent: Intent, failMsg: String): ActionResult {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            ActionResult(true, "", true)
        } catch (e: Exception) {
            ActionResult(false, failMsg, false)
        }
    }

    // ---------- apps ----------

    private fun openApp(ctx: Context, nameRaw: String): ActionResult {
        if (nameRaw.isBlank()) return ActionResult(false, "ما عرفت أي تطبيق تقصد", false)
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)

        var q = norm(nameRaw)
        val alias = ALIASES[q]
        if (alias != null) q = alias

        var bestPkg: String? = null
        var bestScore = 0
        var bestLen = Int.MAX_VALUE
        for (ri in apps) {
            val label = norm(ri.loadLabel(pm).toString())
            val score = when {
                label == q -> 100
                label.startsWith(q) -> 80
                label.contains(q) -> 60
                label.length >= 3 && q.contains(label) -> 40
                else -> 0
            }
            if (score > bestScore || (score == bestScore && score > 0 && label.length < bestLen)) {
                bestScore = score
                bestLen = label.length
                bestPkg = ri.activityInfo.packageName
            }
        }
        if (bestPkg == null || bestScore == 0) {
            return ActionResult(false, "ما لقيت تطبيق اسمه $nameRaw", false)
        }
        val li = pm.getLaunchIntentForPackage(bestPkg)
            ?: return ActionResult(false, "ما قدرت أفتح $nameRaw", false)
        return launch(ctx, li, "ما قدرت أفتح $nameRaw")
    }

    // ---------- contacts / calls / messages ----------

    private fun resolveNumber(ctx: Context, to: String): String? {
        val t = to.trim()
        if (t.isEmpty()) return null
        val hasLetters = t.any { it.isLetter() }
        val digitCount = t.count { it.isDigit() }
        if (!hasLetters && digitCount >= 3) {
            return t.filter { it.isDigit() || it == '+' }
        }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$t%"),
            null
        ) ?: return null
        var bestNumber: String? = null
        var bestLen = Int.MAX_VALUE
        cursor.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: ""
                val number = c.getString(1) ?: ""
                if (number.isNotEmpty() && name.length < bestLen) {
                    bestLen = name.length
                    bestNumber = number
                }
            }
        }
        return bestNumber
    }

    private fun needNumberMsg(ctx: Context, to: String): String {
        return if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            "ما عندي صلاحية جهات الاتصال، فعّلها من إعدادات التطبيق"
        else
            "ما لقيت رقم لـ $to"
    }

    private fun call(ctx: Context, to: String): ActionResult {
        val num = resolveNumber(ctx, to) ?: return ActionResult(false, needNumberMsg(ctx, to), false)
        val direct = Config(ctx).directCall &&
            ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val intent = Intent(
            if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL,
            Uri.fromParts("tel", num, null)
        )
        return launch(ctx, intent, "ما قدرت أبدأ الاتصال")
    }

    private fun sms(ctx: Context, to: String, text: String): ActionResult {
        val num = resolveNumber(ctx, to) ?: return ActionResult(false, needNumberMsg(ctx, to), false)
        val intent = Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", num, null))
        intent.putExtra("sms_body", text)
        return launch(ctx, intent, "ما قدرت أفتح الرسائل")
    }

    private fun intlDigits(num: String, cc: String): String {
        val trimmed = num.trim()
        val d = trimmed.filter { it.isDigit() }
        if (trimmed.startsWith("+")) return d
        if (d.startsWith("00")) return d.substring(2)
        if (d.startsWith("0")) return cc + d.substring(1)
        return d
    }

    private fun whatsapp(ctx: Context, to: String, text: String): ActionResult {
        val num = resolveNumber(ctx, to) ?: return ActionResult(false, needNumberMsg(ctx, to), false)
        val digits = intlDigits(num, Config(ctx).countryCode)
        val uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(text))
        return launch(ctx, Intent(Intent.ACTION_VIEW, uri), "ما قدرت أفتح واتساب")
    }

    // ---------- time ----------

    private fun alarm(ctx: Context, a: JSONObject): ActionResult {
        val h = a.optInt("hour", -1)
        val m = a.optInt("minute", 0)
        if (h !in 0..23 || m !in 0..59) return ActionResult(false, "الوقت غير واضح", false)
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val label = a.optString("label", "")
        if (label.isNotBlank()) intent.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        return launch(ctx, intent, "ما قدرت أضبط المنبه")
    }

    private fun timer(ctx: Context, a: JSONObject): ActionResult {
        val s = a.optInt("seconds", 0)
        if (s <= 0) return ActionResult(false, "المدة غير واضحة", false)
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, s)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val label = a.optString("label", "")
        if (label.isNotBlank()) intent.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        return launch(ctx, intent, "ما قدرت أشغل المؤقت")
    }

    private fun calendar(ctx: Context, a: JSONObject): ActionResult {
        val title = a.optString("title", "")
        val start = a.optString("start", "")
        if (title.isBlank() || start.isBlank()) return ActionResult(false, "تفاصيل الموعد ناقصة", false)
        val zone = ZoneId.systemDefault()
        val s = LocalDateTime.parse(start)
        val endStr = a.optString("end", "")
        val e = if (endStr.isBlank()) s.plusHours(1) else LocalDateTime.parse(endStr)
        val intent = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, s.atZone(zone).toInstant().toEpochMilli())
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, e.atZone(zone).toInstant().toEpochMilli())
        val loc = a.optString("location", "")
        if (loc.isNotBlank()) intent.putExtra(CalendarContract.Events.EVENT_LOCATION, loc)
        return launch(ctx, intent, "ما قدرت أفتح التقويم")
    }

    // ---------- web / maps / settings ----------

    private fun webSearch(ctx: Context, q: String): ActionResult {
        if (q.isBlank()) return ActionResult(false, "ما عرفت وش أبحث", false)
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))
        return launch(ctx, Intent(Intent.ACTION_VIEW, uri), "ما قدرت أفتح البحث")
    }

    private fun openUrl(ctx: Context, url: String): ActionResult {
        val u = url.trim()
        if (!u.startsWith("http://") && !u.startsWith("https://")) {
            return ActionResult(false, "الرابط غير صحيح", false)
        }
        return launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)), "ما قدرت أفتح الرابط")
    }

    private fun navigate(ctx: Context, dest: String): ActionResult {
        if (dest.isBlank()) return ActionResult(false, "ما عرفت الوجهة", false)
        val uri = Uri.parse("geo:0,0?q=" + Uri.encode(dest))
        return launch(ctx, Intent(Intent.ACTION_VIEW, uri), "ما قدرت أفتح الخرائط")
    }

    private fun settings(ctx: Context, page: String): ActionResult {
        val action = when (page.lowercase().trim()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            "nfc" -> Settings.ACTION_NFC_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return launch(ctx, Intent(action), "ما قدرت أفتح الإعدادات")
    }

    // ---------- hardware ----------

    private fun flashlight(ctx: Context, on: Boolean): ActionResult {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return ActionResult(false, "الجهاز ما فيه فلاش", false)
        cm.setTorchMode(id, on)
        return ActionResult(true, "", false)
    }

    private fun volume(ctx: Context, a: JSONObject): ActionResult {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (a.has("level")) {
            val level = a.optInt("level", 50).coerceIn(0, 100)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                (level / 100f * max).roundToInt(),
                AudioManager.FLAG_SHOW_UI
            )
        } else {
            val dir = if (a.optString("change") == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        }
        return ActionResult(true, "", false)
    }

    private fun music(ctx: Context, cmd: String): ActionResult {
        val code = when (cmd.lowercase().trim()) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return ActionResult(false, "ما عرفت أمر الموسيقى", false)
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ActionResult(true, "", false)
    }

    // ---------- clipboard / share ----------

    private fun copy(ctx: Context, text: String): ActionResult {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("text", text))
        return ActionResult(true, "", false)
    }

    private fun share(ctx: Context, text: String): ActionResult {
        val send = Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, text)
        return launch(ctx, Intent.createChooser(send, null), "ما قدرت أفتح المشاركة")
    }
}
