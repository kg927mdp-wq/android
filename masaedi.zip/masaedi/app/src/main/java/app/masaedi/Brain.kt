package app.masaedi

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class ApiError(val provider: Provider, val code: Int, detail: String) : Exception(detail)

data class Reply(val say: String, val actions: List<JSONObject>, val followUp: Boolean)

object Brain {

    private val history = ArrayList<Pair<String, String>>()
    private const val MAX_HISTORY = 8

    private val SYSTEM_PROMPT = """
You are "مساعدي" (Masaedi), a smart voice assistant that lives on the user's Android phone.
Reply with ONE JSON object only. No markdown, no code fences, no text outside the JSON.

Schema:
{"say": string, "actions": [ ...device actions... ], "follow_up": boolean}

Rules for "say":
- It is spoken aloud. Use the same language and dialect as the user (Arabic stays Arabic).
- Keep it short: one to three sentences unless the user asks for detail.
- No markdown, no emoji, no bullet symbols, no URLs read out letter by letter.
- If you are not sure about a fact, say you are not sure. Never invent facts, numbers, contacts or links.

Rules for "actions":
- Use actions only when the user wants something done on the phone. Otherwise return an empty list.
- Run in order. Never claim an action already succeeded; the app will report failures itself.
- If a required detail is missing (who to call, what time), ask for it, set follow_up to true and return no actions.
- Never invent phone numbers. Use the name the user said, or digits the user said.

Available actions (use exactly these field names):
{"type":"open_app","name":"app name as shown on the phone, English name for well known apps"}
{"type":"call","to":"contact name or phone digits"}
{"type":"sms","to":"contact name or phone digits","text":"message"}
{"type":"whatsapp","to":"contact name or phone digits","text":"message"}
{"type":"alarm","hour":0-23,"minute":0-59,"label":"optional"}
{"type":"timer","seconds":number,"label":"optional"}
{"type":"web_search","query":"search words"}
{"type":"open_url","url":"https://..."}
{"type":"navigate","destination":"place or address"}
{"type":"settings","page":"wifi|bluetooth|display|sound|battery|location|apps|accessibility|date|language|nfc|airplane|main"}
{"type":"flashlight","on":true or false}
{"type":"volume","level":0-100}  or  {"type":"volume","change":"up" or "down"}
{"type":"music","command":"play|pause|next|previous"}
{"type":"camera"}
{"type":"calendar","title":"...","start":"yyyy-MM-ddTHH:mm","end":"yyyy-MM-ddTHH:mm","location":"optional"}
{"type":"copy","text":"text to copy"}
{"type":"share","text":"text to share"}

"follow_up": true only when you asked the user a question and expect a spoken answer.
""".trimIndent()

    private val REVIEW_PROMPT = """
You are a strict reviewer for a phone voice assistant. You receive the conversation context, the user's latest request and a DRAFT reply in JSON.
Check carefully:
1. Facts: fix anything wrong. If the draft states something you cannot be sure of, change it to say you are not sure.
2. Actions: types and fields must match the schema, nothing invented (no made-up numbers, contacts or links), times and dates must be correct relative to the current time given below, and the action must really match what the user asked.
3. Language: the reply must use the user's language and dialect, short and easy to speak, no markdown or emoji.
Output ONLY the final JSON object in the same schema as the draft: {"say":..., "actions":[...], "follow_up":...}. If the draft is already correct, output it unchanged.
""".trimIndent()

    private fun nowString(): String {
        val z = ZonedDateTime.now()
        return z.format(DateTimeFormatter.ofPattern("EEEE yyyy-MM-dd HH:mm", Locale.ENGLISH)) +
            " (" + z.zone.id + ", UTC" + z.offset.id + ")"
    }

    private fun systemMessage(base: String): JSONObject =
        JSONObject().put("role", "system").put("content", base + "\n\nCurrent local time: " + nowString())

    private fun order(cfg: Config, mode: String): List<Provider> {
        val o = when (mode) {
            "fast" -> listOf(Provider.GEMINI, Provider.DEEPSEEK, Provider.GROK)
            else -> listOf(Provider.DEEPSEEK, Provider.GEMINI, Provider.GROK)
        }
        return o.filter { cfg.hasKey(it) }
    }

    private fun chat(cfg: Config, p: Provider, messages: JSONArray, maxTokens: Int): String {
        val body = JSONObject()
            .put("model", cfg.model(p))
            .put("messages", messages)
            .put("temperature", 0.3)
            .put("max_tokens", maxTokens)
            .put("stream", false)

        val conn = URL(p.url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Authorization", "Bearer " + cfg.key(p))
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw ApiError(p, code, text.take(300))

            val choices = JSONObject(text).optJSONArray("choices")
                ?: throw ApiError(p, code, "empty response")
            val msg = choices.getJSONObject(0).optJSONObject("message")
                ?: throw ApiError(p, code, "no message")
            val content = msg.optString("content", "")
            if (content.isBlank()) throw ApiError(p, code, "blank answer")
            return content
        } finally {
            conn.disconnect()
        }
    }

    /** Tries providers in order until one answers. Returns provider + raw content. */
    private fun chain(
        cfg: Config,
        providers: List<Provider>,
        messages: JSONArray,
        maxTokens: Int,
        errors: MutableList<ApiError>
    ): Pair<Provider, String>? {
        for (p in providers) {
            try {
                return Pair(p, chat(cfg, p, messages, maxTokens))
            } catch (e: ApiError) {
                errors.add(e)
            } catch (e: Exception) {
                errors.add(ApiError(p, -1, e.message ?: e.javaClass.simpleName))
            }
        }
        return null
    }

    private fun parse(raw: String): Reply {
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s >= 0 && e > s) {
            try {
                val o = JSONObject(raw.substring(s, e + 1))
                val acts = ArrayList<JSONObject>()
                val arr = o.optJSONArray("actions")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val a = arr.optJSONObject(i)
                        if (a != null) acts.add(a)
                    }
                }
                return Reply(o.optString("say", "").trim(), acts, o.optBoolean("follow_up", false))
            } catch (ex: Exception) {
                // fall through to plain text
            }
        }
        return Reply(raw.trim(), emptyList(), false)
    }

    private fun describeError(e: ApiError): String {
        val why = when (e.code) {
            401, 403 -> "المفتاح غير صحيح أو ما عنده صلاحية"
            402 -> "الرصيد خلص"
            404 -> "اسم الموديل غلط"
            429 -> "طلبات كثيرة، جرّب بعد شوي"
            -1 -> "ما في اتصال بالإنترنت"
            else -> "خطأ " + e.code
        }
        return e.provider.label + ": " + why
    }

    fun ask(ctx: Context, userText: String): Reply {
        val cfg = Config(ctx)
        val mode = cfg.mode
        val providers = order(cfg, mode)
        if (providers.isEmpty()) {
            return Reply("ما أقدر أجاوب لأن ما في مفتاح محفوظ. افتح إعدادات التطبيق وحط مفتاح واحد على الأقل.", emptyList(), false)
        }

        val messages = JSONArray()
        messages.put(systemMessage(SYSTEM_PROMPT))
        synchronized(history) {
            for (h in history) messages.put(JSONObject().put("role", h.first).put("content", h.second))
        }
        messages.put(JSONObject().put("role", "user").put("content", userText))

        val errors = ArrayList<ApiError>()
        val draft = chain(cfg, providers, messages, 2000, errors)
        if (draft == null) {
            val msg = errors.joinToString("، ") { describeError(it) }
            return Reply("ما قدرت أوصل لأي نموذج. $msg", emptyList(), false)
        }

        var finalRaw = draft.second

        if (mode == "accurate") {
            val reviewers = listOf(Provider.GEMINI, Provider.GROK, Provider.DEEPSEEK)
                .filter { it != draft.first && cfg.hasKey(it) }
            if (reviewers.isNotEmpty()) {
                val ctxText = StringBuilder()
                synchronized(history) {
                    for (h in history) {
                        ctxText.append(if (h.first == "user") "User: " else "Assistant: ")
                            .append(h.second).append('\n')
                    }
                }
                val rm = JSONArray()
                rm.put(systemMessage(REVIEW_PROMPT + "\n\nSchema reference:\n" + SYSTEM_PROMPT))
                rm.put(
                    JSONObject().put("role", "user").put(
                        "content",
                        "Conversation so far:\n" + ctxText + "\nLatest user request:\n" + userText +
                            "\n\nDRAFT reply (from " + draft.first.label + "):\n" + draft.second
                    )
                )
                val reviewed = chain(cfg, reviewers, rm, 2000, ArrayList())
                if (reviewed != null) {
                    val r = parse(reviewed.second)
                    // accept the review only if it produced something usable
                    if (r.say.isNotEmpty() || r.actions.isNotEmpty()) finalRaw = reviewed.second
                }
            }
        }

        val reply = parse(finalRaw)
        synchronized(history) {
            history.add(Pair("user", userText))
            history.add(Pair("assistant", finalRaw))
            while (history.size > MAX_HISTORY) history.removeAt(0)
        }
        return reply
    }

    /** Used by the settings screen to test one key. */
    fun ping(ctx: Context, p: Provider): String {
        val cfg = Config(ctx)
        if (!cfg.hasKey(p)) return "لا يوجد مفتاح"
        return try {
            val m = JSONArray().put(
                JSONObject().put("role", "user").put("content", "Reply with the single word OK")
            )
            chat(cfg, p, m, 1000)
            "يشتغل ✓"
        } catch (e: ApiError) {
            describeError(e) + " ✗"
        } catch (e: Exception) {
            "فشل: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    fun clearHistory() {
        synchronized(history) { history.clear() }
    }
}
