package app.masaedi

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class ApiError(val provider: Provider, val code: Int, detail: String) : Exception(detail)

interface BrainListener {
    fun isCancelled(): Boolean
    fun onSearching(query: String)
    fun onSentence(text: String)
    fun onAction(action: JSONObject)
    fun onDone(followUp: Boolean)
    fun onCorrection(text: String)
    fun onFailure(message: String)
}

object Brain {

    private val history = ArrayList<Pair<String, String>>()
    private const val MAX_HISTORY = 10

    private val SYSTEM_PROMPT = """
You are "مساعدي" (Masaedi), a fast, smart voice assistant on the user's Android phone.
Your reply is spoken aloud sentence by sentence while you are still writing it.

OUTPUT FORMAT (plain text only, no JSON, no markdown):
1. First the spoken answer: short natural sentences in the user's own language and dialect (Arabic stays Arabic). One to three sentences unless the user asks for detail. No lists, no emoji, no URLs, no symbols.
2. Then, only if needed, command lines. Each one on its own line and starting with @@
@@ACT: {one json action}
@@ASK
@@SEARCH: query

@@ASK means you asked the user a question and expect a spoken answer.

SEARCH: For anything that may have changed after your training or that you cannot be sure of (news, prices, exchange rates, sports scores, weather, who currently holds a role, recent releases or events, opening hours), output ONLY one line: @@SEARCH: <short search query>. Write no spoken text before it. The app then gives you web results; answer from them and name the source briefly. Do not search for stable knowledge, chit-chat, math or phone commands.

ACCURACY: Never invent facts, numbers, names, contacts or links. If you are not sure, say so. Resolve times relative to the current local time given below.

ACTIONS: only when the user wants something done on the phone. Say a short spoken confirmation first, then the @@ACT line. If a needed detail is missing (who to call, what time), ask for it, add @@ASK and no action. Never invent phone numbers: use the name or digits the user said. For alarms use the next upcoming occurrence of the time.
Action fields (exact names):
{"type":"open_app","name":"app name, English name for well known apps"}
{"type":"call","to":"contact name or digits"}
{"type":"sms","to":"contact name or digits","text":"message"}
{"type":"whatsapp","to":"contact name or digits","text":"message"}
{"type":"alarm","hour":0-23,"minute":0-59,"label":"optional"}
{"type":"timer","seconds":number,"label":"optional"}
{"type":"web_search","query":"words"}
{"type":"open_url","url":"https://..."}
{"type":"navigate","destination":"place or address"}
{"type":"settings","page":"wifi|bluetooth|display|sound|battery|location|apps|accessibility|date|language|nfc|airplane|main"}
{"type":"flashlight","on":true}
{"type":"volume","level":0-100}  or  {"type":"volume","change":"up"}  or  {"type":"volume","change":"down"}
{"type":"music","command":"play|pause|next|previous"}
{"type":"camera"}
{"type":"calendar","title":"...","start":"yyyy-MM-ddTHH:mm","end":"yyyy-MM-ddTHH:mm","location":"optional"}
{"type":"copy","text":"text"}
{"type":"share","text":"text"}

Examples:
User: نبهني الساعة سبعة الصبح
Reply:
تمام، ضبطت منبه الساعة سبعة الصبح.
@@ACT: {"type":"alarm","hour":7,"minute":0}

User: كلم أحمد
Reply:
أي أحمد تقصد؟ قولي الاسم كامل أو الرقم.
@@ASK

User: سعر الذهب اليوم
Reply:
@@SEARCH: سعر الذهب اليوم
""".trimIndent()

    private val REVIEW_FULL = """
You are a strict reviewer for a phone voice assistant. You get the conversation, the user's latest request and a DRAFT reply written in the output protocol described below.
Fix factual errors, wrong or invented actions (types, fields, made-up numbers or contacts), wrong times relative to the current time, and wrong language or dialect. If the draft states something uncertain, rewrite it so it admits uncertainty. Keep it short and easy to speak.
Output ONLY the final reply in the same protocol (spoken text first, then @@ lines). If the draft is already correct, output it unchanged.
""".trimIndent()

    private val REVIEW_QUICK = """
You are a fact checker for a voice assistant. You get the user's question and the assistant's spoken answer.
Reply with exactly OK unless you are confident (at least 90 percent) that the answer contains a clear factual error or a dangerous mistake.
If it does, reply with FIX: followed by one or two short spoken sentences that correct it, in the same language and dialect as the answer. No other text.
""".trimIndent()

    // ------------------------------------------------------------------ helpers

    private fun nowString(): String {
        val z = ZonedDateTime.now()
        return z.format(DateTimeFormatter.ofPattern("EEEE yyyy-MM-dd HH:mm", Locale.ENGLISH)) +
            " (" + z.zone.id + ", UTC" + z.offset.id + ")"
    }

    private fun msg(role: String, content: String): JSONObject =
        JSONObject().put("role", role).put("content", content)

    private fun systemMessage(base: String): JSONObject =
        msg("system", base + "\n\nCurrent local time: " + nowString())

    private fun prompt(cfg: Config): String =
        SYSTEM_PROMPT + "\n\nWeb search: " +
            (if (cfg.searchEnabled) "available." else "NOT available. Never output @@SEARCH; say you cannot check live information.")

    private fun order(cfg: Config): List<Provider> {
        val first = try {
            Provider.valueOf(cfg.primary)
        } catch (e: Exception) {
            Provider.DEEPSEEK
        }
        val all = listOf(first) + Provider.values().filter { it != first }
        return all.filter { cfg.hasKey(it) }
    }

    private fun describeError(e: ApiError): String {
        val why = when (e.code) {
            401, 403 -> "المفتاح غير صحيح أو ما عنده صلاحية"
            402 -> "الرصيد خلص"
            404 -> "اسم الموديل غلط"
            429 -> "طلبات كثيرة، جرّب بعد شوي"
            -1 -> "ما في اتصال بالإنترنت"
            -2 -> "رجّع جواب فاضي"
            else -> "خطأ " + e.code + " " + (e.message ?: "").replace(Regex("\\s+"), " ").take(120)
        }
        return e.provider.label + ": " + why
    }

    // ------------------------------------------------------------------ network

    private fun body(cfg: Config, p: Provider, messages: JSONArray, stream: Boolean): JSONObject {
        val b = JSONObject()
            .put("model", cfg.model(p))
            .put("messages", messages)
            .put("stream", stream)
        if (p == Provider.DEEPSEEK) {
            b.put("temperature", 0.3)
            b.put("max_tokens", 2000)
        }
        return b
    }

    private fun post(cfg: Config, p: Provider, body: JSONObject): HttpURLConnection {
        val conn = URL(p.url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Authorization", "Bearer " + cfg.key(p))
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return conn
    }

    private fun checkOk(p: Provider, conn: HttpURLConnection) {
        val code = conn.responseCode
        if (code !in 200..299) {
            val text = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            throw ApiError(p, code, text.take(300))
        }
    }

    /** Streams the answer and calls onDelta for each piece of text. */
    private fun stream(
        cfg: Config,
        p: Provider,
        messages: JSONArray,
        cancelled: () -> Boolean,
        onDelta: (String) -> Unit
    ) {
        val conn = post(cfg, p, body(cfg, p, messages, true))
        try {
            checkOk(p, conn)
            val reader = conn.inputStream.bufferedReader(Charsets.UTF_8)
            while (true) {
                if (cancelled()) break
                val line = reader.readLine() ?: break
                if (!line.startsWith("data:")) continue
                val data = line.substring(5).trim()
                if (data.isEmpty()) continue
                if (data == "[DONE]") break
                val delta: JSONObject? = try {
                    val ch = JSONObject(data).optJSONArray("choices")
                    if (ch == null || ch.length() == 0) null else ch.getJSONObject(0).optJSONObject("delta")
                } catch (e: Exception) {
                    null
                }
                if (delta == null || delta.isNull("content")) continue
                val c = delta.optString("content", "")
                if (c.isNotEmpty()) onDelta(c)
            }
        } finally {
            conn.disconnect()
        }
    }

    /** One normal (non streaming) call. */
    private fun chat(cfg: Config, p: Provider, messages: JSONArray): String {
        val conn = post(cfg, p, body(cfg, p, messages, false))
        try {
            checkOk(p, conn)
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val choices = JSONObject(text).optJSONArray("choices")
            if (choices == null || choices.length() == 0) throw ApiError(p, -2, "empty")
            val m = choices.getJSONObject(0).optJSONObject("message") ?: throw ApiError(p, -2, "empty")
            if (m.isNull("content")) throw ApiError(p, -2, "empty")
            val content = m.optString("content", "")
            if (content.isBlank()) throw ApiError(p, -2, "empty")
            return content
        } finally {
            conn.disconnect()
        }
    }

    // ------------------------------------------------------------------ stream parser

    /** Splits the streamed text into spoken sentences and "@@" command lines. */
    private class Parser(private val sink: (String) -> Unit) {
        private val buf = StringBuilder()
        private val cmd = StringBuilder()
        private var inCmd = false
        val spoken = StringBuilder()
        val actions = ArrayList<JSONObject>()
        var follow = false
        var search: String? = null

        fun feed(d: String) {
            if (inCmd) {
                cmd.append(d)
                return
            }
            buf.append(d)
            val i = buf.indexOf("@@")
            if (i >= 0) {
                cmd.append(buf.substring(i))
                buf.setLength(i)
                inCmd = true
                drain(true)
            } else {
                drain(false)
            }
        }

        private fun cut(): Int {
            val n = buf.length
            for (i in 0 until n) {
                val c = buf[i]
                if (c == '\n') return i
                if (c == '.' || c == '!' || c == '?' || c == '؟' || c == '؛') {
                    if (i >= n - 1) return -1
                    if (buf[i + 1].isWhitespace()) return i
                }
            }
            if (n > 200) {
                val sp = buf.lastIndexOf(" ", 190)
                if (sp > 60) return sp
            }
            return -1
        }

        private fun drain(all: Boolean) {
            while (true) {
                val i = cut()
                if (i < 0) break
                emit(buf.substring(0, i + 1))
                buf.delete(0, i + 1)
            }
            if (all) {
                if (buf.isNotBlank()) emit(buf.toString())
                buf.setLength(0)
            }
        }

        private fun emit(raw: String) {
            val t = raw.replace(Regex("[*#`~]"), "").trim()
            if (t.isEmpty()) return
            if (spoken.isNotEmpty()) spoken.append(' ')
            spoken.append(t)
            sink(t)
        }

        fun finish() {
            if (!inCmd) drain(true)
            if (cmd.isEmpty()) return
            for (part in cmd.toString().split("@@")) {
                val t = part.trim()
                if (t.isEmpty()) continue
                val head = t.substringBefore(':').trim().uppercase(Locale.ROOT)
                val rest = t.substringAfter(':', "").trim()
                when {
                    head.startsWith("SEARCH") -> if (rest.isNotEmpty() && search == null) search = rest
                    head.startsWith("ASK") -> follow = true
                    head.startsWith("ACT") -> {
                        try {
                            actions.add(JSONObject(rest))
                        } catch (e: Exception) {
                            // ignore a broken action line
                        }
                    }
                }
            }
        }
    }

    private class Pass(
        val provider: Provider,
        val raw: String,
        val spoken: String,
        val actions: List<JSONObject>,
        val follow: Boolean,
        val search: String?
    )

    /** Runs one streamed answer, trying the providers in order until one works. */
    private fun runPass(
        cfg: Config,
        providers: List<Provider>,
        messages: JSONArray,
        live: Boolean,
        l: BrainListener,
        errors: MutableList<ApiError>
    ): Pass? {
        for (p in providers) {
            if (l.isCancelled()) return null
            val raw = StringBuilder()
            val parser = Parser { s -> if (live) l.onSentence(s) }
            try {
                stream(cfg, p, messages, { l.isCancelled() }) { d ->
                    raw.append(d)
                    parser.feed(d)
                }
            } catch (e: ApiError) {
                errors.add(e)
                if (raw.isEmpty() || !live) continue
            } catch (e: Exception) {
                errors.add(ApiError(p, -1, e.message ?: e.javaClass.simpleName))
                if (raw.isEmpty() || !live) continue
            }
            if (raw.isBlank()) {
                errors.add(ApiError(p, -2, "empty"))
                continue
            }
            parser.finish()
            return Pass(p, raw.toString(), parser.spoken.toString().trim(), parser.actions, parser.follow, parser.search)
        }
        return null
    }

    // ------------------------------------------------------------------ reviewers

    private fun reviewers(cfg: Config, draft: Provider): List<Provider> =
        listOf(Provider.GEMINI, Provider.GROK, Provider.DEEPSEEK).filter { it != draft && cfg.hasKey(it) }

    private fun historyText(): String {
        val sb = StringBuilder()
        synchronized(history) {
            for (h in history) {
                sb.append(if (h.first == "user") "User: " else "Assistant: ").append(h.second).append('\n')
            }
        }
        return sb.toString()
    }

    private fun reviewFull(cfg: Config, draft: Provider, userText: String, raw: String): String? {
        val list = reviewers(cfg, draft)
        if (list.isEmpty()) return null
        val m = JSONArray()
        m.put(systemMessage(REVIEW_FULL + "\n\nOUTPUT PROTOCOL:\n" + SYSTEM_PROMPT))
        m.put(
            msg(
                "user",
                "Conversation so far:\n" + historyText() + "\nLatest user request:\n" + userText +
                    "\n\nDRAFT reply (from " + draft.label + "):\n" + raw
            )
        )
        for (p in list) {
            try {
                val out = chat(cfg, p, m)
                if (out.isNotBlank()) return out
            } catch (e: Exception) {
                // try the next reviewer
            }
        }
        return null
    }

    /** Returns a short correction, or null when the answer looks fine or nobody could check it. */
    private fun reviewQuick(cfg: Config, draft: Provider, userText: String, spoken: String): String? {
        val m = JSONArray()
        m.put(systemMessage(REVIEW_QUICK))
        m.put(msg("user", "Question:\n" + userText + "\n\nAnswer:\n" + spoken))
        for (p in reviewers(cfg, draft)) {
            try {
                val out = chat(cfg, p, m).trim()
                if (out.startsWith("FIX", ignoreCase = true)) {
                    val fix = out.substringAfter(":", "").trim()
                    return if (fix.isEmpty()) null else fix
                }
                return null
            } catch (e: Exception) {
                // try the next reviewer
            }
        }
        return null
    }

    // ------------------------------------------------------------------ main entry

    fun ask(ctx: Context, userText: String, l: BrainListener) {
        val cfg = Config(ctx)
        val providers = order(cfg)
        if (providers.isEmpty()) {
            l.onFailure("ما أقدر أجاوب لأن ما في مفتاح محفوظ. افتح الإعدادات وحط مفتاح واحد على الأقل.")
            return
        }
        val mode = cfg.mode
        val live = mode != "careful"

        val messages = JSONArray()
        messages.put(systemMessage(prompt(cfg)))
        synchronized(history) {
            for (h in history) messages.put(msg(h.first, h.second))
        }
        messages.put(msg("user", userText))

        val errors = ArrayList<ApiError>()
        var cur: Pass = runPass(cfg, providers, messages, live, l, errors) ?: run {
            if (!l.isCancelled()) {
                l.onFailure("ما قدرت أوصل لأي نموذج. " + errors.joinToString("، ") { describeError(it) })
            }
            return
        }
        if (l.isCancelled()) return

        var searched = false
        val q = cur.search
        if (q != null && cfg.searchEnabled) {
            l.onSearching(q)
            val hits = try {
                WebSearch.search(q, cfg.tavilyKey)
            } catch (e: Exception) {
                emptyList()
            }
            if (l.isCancelled()) return
            messages.put(msg("assistant", cur.raw))
            messages.put(
                msg(
                    "user",
                    WebSearch.format(q, hits) +
                        "\n\nUse these results to answer the user's request now. Do not search again. " +
                        "If they do not contain the answer, say you could not verify it. Name the source briefly."
                )
            )
            val ordered = listOf(cur.provider) + providers.filter { it != cur.provider }
            cur = runPass(cfg, ordered, messages, live, l, errors) ?: run {
                if (!l.isCancelled()) {
                    l.onFailure("ما قدرت أكمل الجواب. " + errors.joinToString("، ") { describeError(it) })
                }
                return
            }
            if (l.isCancelled()) return
            searched = true
        }

        var finalRaw = cur.raw
        var spoken = cur.spoken
        var actions: List<JSONObject> = cur.actions
        var follow = cur.follow

        if (!live) {
            // careful mode: a second model checks the draft before anything is spoken
            var raw = cur.raw
            if (!searched) {
                val reviewed = reviewFull(cfg, cur.provider, userText, raw)
                if (reviewed != null) raw = reviewed
            }
            if (l.isCancelled()) return
            val parser = Parser { s -> l.onSentence(s) }
            parser.feed(raw)
            parser.finish()
            finalRaw = raw
            spoken = parser.spoken.toString().trim()
            actions = parser.actions
            follow = parser.follow
        }

        if (spoken.isBlank() && actions.isEmpty()) {
            l.onSentence("ما قدرت أجاوب على هذا، جرّب تعيد السؤال.")
        }
        for (a in actions) l.onAction(a)

        synchronized(history) {
            history.add(Pair("user", userText))
            history.add(Pair("assistant", finalRaw))
            while (history.size > MAX_HISTORY) history.removeAt(0)
        }
        l.onDone(follow)

        if (mode == "instant" && !searched && actions.isEmpty() && !follow && spoken.length > 40) {
            val provider = cur.provider
            val answer = spoken
            Thread {
                try {
                    val fix = reviewQuick(cfg, provider, userText, answer)
                    if (fix != null && !l.isCancelled()) {
                        synchronized(history) {
                            if (history.isNotEmpty()) {
                                val last = history.size - 1
                                history[last] = Pair("assistant", history[last].second + "\n(Correction: " + fix + ")")
                            }
                        }
                        l.onCorrection(fix)
                    }
                } catch (e: Exception) {
                    // the check is best effort
                }
            }.start()
        }
    }

    /** Used by the settings screen to test one key. */
    fun ping(ctx: Context, p: Provider): String {
        val cfg = Config(ctx)
        if (!cfg.hasKey(p)) return "لا يوجد مفتاح"
        return try {
            val m = JSONArray().put(msg("user", "Reply with the single word OK"))
            chat(cfg, p, m)
            "يشتغل ✓"
        } catch (e: ApiError) {
            describeError(e) + " ✗"
        } catch (e: Exception) {
            "فشل: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    fun clearHistory() {
        synchronized(history) { history.clear() }
    }
}
