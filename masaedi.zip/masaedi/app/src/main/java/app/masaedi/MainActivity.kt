package app.masaedi

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var cfg: Config
    private val keyFields = HashMap<Provider, EditText>()
    private val modelFields = HashMap<Provider, EditText>()
    private val resultViews = HashMap<Provider, TextView>()
    private lateinit var modeSpinner: Spinner
    private lateinit var langSpinner: Spinner
    private lateinit var countryField: EditText
    private lateinit var directSwitch: Switch
    private lateinit var logView: TextView

    private val modeValues = listOf("accurate", "balanced", "fast")
    private val modeLabels = listOf(
        "دقيق: نموذج يجاوب ونموذج ثاني يراجع",
        "متوازن: نموذج واحد مع بدائل",
        "سريع: أسرع جواب"
    )
    private val langValues = listOf("ar-IQ", "ar-SA", "ar-AE", "ar-EG", "en-US", "")
    private val langLabels = listOf(
        "عربي – العراق", "عربي – السعودية", "عربي – الإمارات", "عربي – مصر", "English", "لغة الجهاز"
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 14f, color: String = "#AEB6D6"): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = size
        tv.setTextColor(Color.parseColor(color))
        tv.setPadding(0, dp(14), 0, dp(4))
        return tv
    }

    private fun edit(value: String, hint: String, secret: Boolean): EditText {
        val e = EditText(this)
        e.setText(value)
        e.hint = hint
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.parseColor("#5C6485"))
        e.isSingleLine = true
        e.layoutDirection = View.LAYOUT_DIRECTION_LTR
        e.gravity = Gravity.START
        e.inputType = if (secret) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT
        }
        return e
    }

    private fun button(text: String, color: String, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(16), dp(14), dp(16), dp(14))
        val g = GradientDrawable()
        g.cornerRadius = dp(14).toFloat()
        g.setColor(Color.parseColor(color))
        b.background = g
        b.setOnClickListener { onClick() }
        return b
    }

    private fun addFull(parent: LinearLayout, v: View, topMargin: Int = 0) {
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = topMargin
        parent.addView(v, lp)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Config(this)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#0B1020"))
        scroll.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(40), dp(20), dp(40))
        scroll.addView(
            col,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        val title = TextView(this)
        title.text = "مساعدي"
        title.textSize = 30f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        addFull(col, title)

        addFull(
            col,
            label(
                "حط مفتاح واحد على الأقل. المفاتيح تنحفظ داخل جوالك فقط وما تنرسل إلا للشركة صاحبة المفتاح.",
                14f
            )
        )

        for (p in Provider.values()) {
            addFull(col, label("مفتاح " + p.label, 15f, "#FFFFFF"))
            val k = edit(cfg.key(p), "API key", true)
            keyFields[p] = k
            addFull(col, k)
            val m = edit(cfg.model(p), "اسم الموديل", false)
            modelFields[p] = m
            addFull(col, m)
            val r = label("", 13f, "#7FE3C2")
            r.setPadding(0, 0, 0, dp(4))
            resultViews[p] = r
            addFull(col, r)
        }

        addFull(col, label("طريقة العمل", 15f, "#FFFFFF"))
        modeSpinner = Spinner(this)
        val modeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, modeLabels)
        modeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        modeSpinner.adapter = modeAdapter
        modeSpinner.setSelection(modeValues.indexOf(cfg.mode).coerceAtLeast(0))
        addFull(col, modeSpinner)

        addFull(col, label("لغة الكلام", 15f, "#FFFFFF"))
        langSpinner = Spinner(this)
        val langAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, langLabels)
        langAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        langSpinner.adapter = langAdapter
        langSpinner.setSelection(langValues.indexOf(cfg.lang).coerceAtLeast(0))
        addFull(col, langSpinner)

        addFull(col, label("رمز دولتك للأرقام (العراق 964، السعودية 966)", 14f))
        countryField = edit(cfg.countryCode, "964", false)
        countryField.inputType = InputType.TYPE_CLASS_NUMBER
        addFull(col, countryField)

        directSwitch = Switch(this)
        directSwitch.text = "الاتصال مباشرة بدون فتح لوحة الأرقام"
        directSwitch.setTextColor(Color.WHITE)
        directSwitch.isChecked = cfg.directCall
        directSwitch.setPadding(0, dp(14), 0, dp(4))
        addFull(col, directSwitch)

        addFull(col, button("حفظ", "#3D5AFE") { save(); toast("انحفظت الإعدادات") }, dp(22))
        addFull(col, button("اختبر المفاتيح", "#2A2F4A") { testKeys() }, dp(10))
        addFull(col, button("إعطاء الصلاحيات (ميكروفون، جهات اتصال، اتصال)", "#2A2F4A") { askPermissions() }, dp(10))
        addFull(col, button("اجعله مساعدي الافتراضي", "#00897B") { openAssistantSettings() }, dp(10))
        addFull(col, button("جرّب المساعد الحين", "#6A1B9A") {
            save()
            startActivity(Intent(this, AssistantActivity::class.java))
        }, dp(10))

        logView = label("", 14f, "#AEB6D6")
        addFull(col, logView, dp(14))

        addFull(
            col,
            label(
                "بعد ما تختاره مساعد افتراضي: اضغط مطولاً على زر الهوم أو زر الباور حسب جوالك. " +
                    "اسم الموديل تقدر تغيّره إذا طلعت لك رسالة «اسم الموديل غلط».",
                13f
            )
        )

        setContentView(scroll)
    }

    private fun toast(msg: String) {
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun save() {
        for (p in Provider.values()) {
            cfg.setKey(p, keyFields[p]?.text?.toString() ?: "")
            cfg.setModel(p, modelFields[p]?.text?.toString() ?: "")
        }
        cfg.mode = modeValues[modeSpinner.selectedItemPosition.coerceIn(0, modeValues.size - 1)]
        cfg.lang = langValues[langSpinner.selectedItemPosition.coerceIn(0, langValues.size - 1)]
        val cc = countryField.text.toString()
        if (cc.isNotBlank()) cfg.countryCode = cc
        cfg.directCall = directSwitch.isChecked
        Brain.clearHistory()
    }

    private fun testKeys() {
        save()
        for (p in Provider.values()) {
            resultViews[p]?.setTextColor(Color.parseColor("#AEB6D6"))
            resultViews[p]?.text = "أختبر…"
        }
        val app = applicationContext
        Thread {
            for (p in Provider.values()) {
                val res = Brain.ping(app, p)
                runOnUiThread {
                    val v = resultViews[p]
                    if (v != null) {
                        v.text = res
                        v.setTextColor(
                            Color.parseColor(if (res.contains("✓")) "#7FE3C2" else "#FF8A80")
                        )
                    }
                }
            }
        }.start()
    }

    private fun askPermissions() {
        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE
            ),
            1
        )
    }

    private fun openAssistantSettings() {
        try {
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            logView.text = "اختر «مساعدي» من قائمة تطبيق المساعد الرقمي."
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                logView.text = "ادخل: التطبيقات الافتراضية ← تطبيق المساعد الرقمي ← مساعدي."
            } catch (e2: Exception) {
                logView.text = "ما قدرت أفتح الإعدادات."
            }
        }
    }
}
