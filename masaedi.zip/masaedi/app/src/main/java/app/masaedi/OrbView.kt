package app.masaedi

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

internal fun withAlpha(c: Int, a: Int): Int =
    Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

internal val PALETTE = intArrayOf(
    Color.parseColor("#5B6CFF"),
    Color.parseColor("#A06BFF"),
    Color.parseColor("#FF5FA8"),
    Color.parseColor("#3DE3D0")
)

/** Aurora orb: four glowing colour blobs drift inside a dark glass sphere.
 *  Calm when idle, follows the voice while listening, spins while thinking,
 *  and pulses while speaking. */
class OrbView(context: Context) : View(context) {

    var state: OrbState = OrbState.IDLE
        set(value) {
            field = value
            invalidate()
        }

    private var target = 0f
    private var level = 0f
    private var phase = 0f
    private var lastNs = 0L

    private val blobShaders = Array(4) { i ->
        RadialGradient(
            0f, 0f, 1f,
            intArrayOf(withAlpha(PALETTE[i], 235), withAlpha(PALETTE[i], 95), withAlpha(PALETTE[i], 0)),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
    }
    private val blobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(222, 10, 13, 34)
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringShader = SweepGradient(
        0f, 0f,
        intArrayOf(PALETTE[0], PALETTE[1], PALETTE[2], PALETTE[3], PALETTE[0]),
        null
    )
    private val sheenShader = RadialGradient(
        0f, 0f, 1f,
        intArrayOf(Color.argb(70, 255, 255, 255), Color.argb(0, 255, 255, 255)),
        null,
        Shader.TileMode.CLAMP
    )

    fun setLevel(v: Float) {
        target = v.coerceIn(0f, 1f)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastNs = System.nanoTime()
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - lastNs) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastNs = now
        phase += dt

        val energy = when (state) {
            OrbState.IDLE -> 0.14f + 0.06f * sin(phase * 1.4f)
            OrbState.LISTENING -> 0.12f + target * 0.88f
            OrbState.THINKING -> 0.32f + 0.08f * sin(phase * 5f)
            OrbState.SPEAKING -> 0.45f + 0.30f * sin(phase * 7f) * sin(phase * 2.3f)
        }
        level += (energy.coerceIn(0f, 1f) - level) * min(1f, dt * 9f)

        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f
        val spin = if (state == OrbState.THINKING) 2.4f else 1f

        for (i in 0 until 4) {
            val a = phase * (0.55f + 0.3f * i) * spin + i * 1.5708f
            val d = r * (0.10f + 0.12f * level)
            val bx = cx + cos(a) * d
            val by = cy + sin(a * 1.27f) * d
            val br = r * (0.50f + 0.20f * level + 0.04f * sin(phase * 2f + i))
            canvas.save()
            canvas.translate(bx, by)
            canvas.scale(br, br)
            blobPaint.shader = blobShaders[i]
            canvas.drawCircle(0f, 0f, 1f, blobPaint)
            canvas.restore()
        }

        val rc = r * 0.42f * (1f + 0.05f * level)
        canvas.drawCircle(cx, cy, rc, corePaint)

        // glass sheen on the upper left of the core
        canvas.save()
        canvas.translate(cx - rc * 0.35f, cy - rc * 0.4f)
        canvas.scale(rc * 0.9f, rc * 0.9f)
        sheenPaint.shader = sheenShader
        canvas.drawCircle(0f, 0f, 1f, sheenPaint)
        canvas.restore()

        // rotating colour ring
        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate((phase * (if (state == OrbState.THINKING) 220f else 40f)) % 360f)
        ringPaint.shader = ringShader
        ringPaint.strokeWidth = r * (if (state == OrbState.THINKING) 0.06f else 0.035f)
        canvas.drawCircle(0f, 0f, rc, ringPaint)
        canvas.restore()

        postInvalidateOnAnimation()
    }
}
