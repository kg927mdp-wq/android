package app.masaedi

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

/** Animated orb: breathing when idle, reacts to the voice level when listening,
 *  spins while thinking, and ripples while speaking. */
class OrbView(context: Context) : View(context) {

    var state: OrbState = OrbState.IDLE
        set(value) {
            field = value
            invalidate()
        }

    private var target = 0f      // incoming level 0..1
    private var level = 0f       // smoothed level
    private var phase = 0f
    private var lastNs = 0L

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val path = Path()
    private val oval = RectF()

    fun setLevel(v: Float) {
        target = v.coerceIn(0f, 1f)
    }

    private fun colorFor(s: OrbState): Int = when (s) {
        OrbState.IDLE -> Color.parseColor("#6C7BFF")
        OrbState.LISTENING -> Color.parseColor("#2FD6C4")
        OrbState.THINKING -> Color.parseColor("#FFB34D")
        OrbState.SPEAKING -> Color.parseColor("#B07CFF")
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastNs = System.nanoTime()
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - lastNs) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastNs = now
        phase += dt

        // simulated level for states that have no real audio meter
        val sim = when (state) {
            OrbState.IDLE -> 0.12f + 0.08f * sin(phase * 1.6f)
            OrbState.THINKING -> 0.18f
            OrbState.SPEAKING -> 0.45f + 0.35f * sin(phase * 7f) * sin(phase * 2.3f)
            OrbState.LISTENING -> target
        }
        level += (sim.coerceIn(0f, 1f) - level) * min(1f, dt * 10f)

        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val base = min(w, h) * 0.22f
        val color = colorFor(state)

        // soft glow
        val glowR = base * (2.2f + level * 0.8f)
        fill.shader = RadialGradient(
            cx, cy, glowR,
            intArrayOf(withAlpha(color, 120), withAlpha(color, 0)),
            floatArrayOf(0.2f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, glowR, fill)

        // expanding rings
        ring.shader = null
        ring.strokeWidth = base * 0.04f
        for (i in 0 until 3) {
            val t = ((phase * (if (state == OrbState.IDLE) 0.18f else 0.5f)) + i / 3f) % 1f
            val r = base * (1.05f + t * (0.55f + level * 0.5f))
            ring.color = withAlpha(color, ((1f - t) * 140f).toInt())
            canvas.drawCircle(cx, cy, r, ring)
        }

        // wobbling body
        path.reset()
        val points = 96
        val amp = base * (0.04f + 0.16f * level)
        for (i in 0..points) {
            val a = (i.toFloat() / points) * 2f * PI.toFloat()
            val wob = amp * (
                sin(a * 3f + phase * 3.2f) * 0.55f +
                    sin(a * 5f - phase * 2.1f) * 0.30f +
                    cos(a * 2f + phase * 1.4f) * 0.15f
                )
            val r = base + wob
            val x = cx + r * cos(a)
            val y = cy + r * sin(a)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        fill.shader = RadialGradient(
            cx - base * 0.3f, cy - base * 0.35f, base * 1.5f,
            intArrayOf(Color.WHITE, color, darken(color)),
            floatArrayOf(0f, 0.45f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(path, fill)

        // spinner while thinking
        if (state == OrbState.THINKING) {
            ring.strokeWidth = base * 0.09f
            ring.color = Color.WHITE
            val r = base * 1.35f
            oval.set(cx - r, cy - r, cx + r, cy + r)
            val start = (phase * 280f) % 360f
            canvas.drawArc(oval, start, 70f, false, ring)
            canvas.drawArc(oval, start + 180f, 40f, false, ring)
        }

        postInvalidateOnAnimation()
    }

    private fun withAlpha(c: Int, a: Int): Int {
        val aa = a.coerceIn(0, 255)
        return Color.argb(aa, Color.red(c), Color.green(c), Color.blue(c))
    }

    private fun darken(c: Int): Int =
        Color.rgb((Color.red(c) * 0.45f).toInt(), (Color.green(c) * 0.45f).toInt(), (Color.blue(c) * 0.55f).toInt())
}
