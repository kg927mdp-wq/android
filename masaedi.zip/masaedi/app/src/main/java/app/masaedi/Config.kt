package app.masaedi

import android.content.Context
import android.content.SharedPreferences

enum class Provider(val label: String, val url: String, val defaultModel: String) {
    DEEPSEEK("DeepSeek", "https://api.deepseek.com/chat/completions", "deepseek-chat"),
    GEMINI(
        "Gemini",
        "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
        "gemini-flash-latest"
    ),
    GROK("Grok", "https://api.x.ai/v1/chat/completions", "grok-4.7")
}

class Config(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun key(p: Provider): String = (sp.getString("key_" + p.name, "") ?: "").trim()

    fun setKey(p: Provider, v: String) {
        sp.edit().putString("key_" + p.name, v.trim()).apply()
    }

    fun model(p: Provider): String {
        val m = (sp.getString("model_" + p.name, "") ?: "").trim()
        return if (m.isEmpty()) p.defaultModel else m
    }

    fun setModel(p: Provider, v: String) {
        sp.edit().putString("model_" + p.name, v.trim()).apply()
    }

    /** instant = stream the answer and fact-check in the background,
     *  careful = check before speaking, fast = stream with no check */
    var mode: String
        get() {
            val m = sp.getString("mode2", "instant") ?: "instant"
            return if (m == "careful" || m == "fast") m else "instant"
        }
        set(v) {
            sp.edit().putString("mode2", v).apply()
        }

    /** which provider answers first */
    var primary: String
        get() = sp.getString("primary", "DEEPSEEK") ?: "DEEPSEEK"
        set(v) {
            sp.edit().putString("primary", v).apply()
        }

    var searchEnabled: Boolean
        get() = sp.getBoolean("search", true)
        set(v) {
            sp.edit().putBoolean("search", v).apply()
        }

    /** optional Tavily key; empty = Tavily keyless mode */
    var tavilyKey: String
        get() = (sp.getString("tavily", "") ?: "").trim()
        set(v) {
            sp.edit().putString("tavily", v.trim()).apply()
        }

    /** speech recognition language, empty = device default */
    var lang: String
        get() = sp.getString("lang", "ar-IQ") ?: "ar-IQ"
        set(v) {
            sp.edit().putString("lang", v).apply()
        }

    var countryCode: String
        get() = sp.getString("country", "964") ?: "964"
        set(v) {
            sp.edit().putString("country", v.filter { it.isDigit() }).apply()
        }

    var directCall: Boolean
        get() = sp.getBoolean("direct_call", false)
        set(v) {
            sp.edit().putBoolean("direct_call", v).apply()
        }

    fun hasKey(p: Provider): Boolean = key(p).isNotEmpty()

    fun anyKey(): Boolean = Provider.values().any { hasKey(it) }
}
