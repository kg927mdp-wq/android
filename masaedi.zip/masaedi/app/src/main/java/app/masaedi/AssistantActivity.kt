package app.masaedi

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.Executors

class AssistantActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var cfg: Config
    private lateinit var orb: OrbView
    private lateinit var statusView: TextView
    private lateinit var textView: TextView

    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    private var recognizer: SpeechRecognizer? = null
    private var usingGoogle = true
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech: String? = null

    private var state = OrbState.IDLE
    private var requestId = 0
    private var leftApp = false
    private var followUpAfterSpeech = false
    private var destroyed = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ UI

    private fun pill(label: String, color: String, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 15f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(18), dp(10), dp(18), dp(10))
        val g = GradientDrawable()
        g.cornerRadius = dp(24).toFloat()
        g.setColor(Color.parseColor(color))
        tv.background = g
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun buildUi(): View {
        val root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setBackgroundColor(Color.parseColor("#66000000"))
        root.setOnClickListener { finish() }

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.CENTER_HORIZONTAL
        panel.isClickable = true
        panel.setPadding(dp(20), dp(16), dp(20), dp(28))
        val bg = GradientDrawable()
        val r = dp(28).toFloat()
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        bg.setColor(Color.parseColor("#F2101426"))
        panel.background = bg

        orb = OrbView(this)
        panel.addView(orb, LinearLayout.LayoutParams(dp(220), dp(220)))

        statusView = TextView(this)
        statusView.textSize = 15f
        statusView.setTextColor(Color.parseColor("#AEB6D6"))
        statusView.gravity = Gravity.CENTER
        panel.addView(
            statusView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        textView = TextView(this)
        textView.textSize = 20f
        textView.setTextColor(Color.WHITE)
        textView.gravity = Gravity.CENTER
        textView.minLines = 2
        textView.maxLines = 8
        textView.setPadding(0, dp(10), 0, dp(14))
        panel.addView(
            textView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        val lp = {
            val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            p.setMargins(dp(6), 0, dp(6), 0)
            p
        }
        row.addView(pill("تكلم", "#3D5AFE") { onMicClick() }, lp())
        row.addView(pill("الإعدادات", "#2A2F4A") {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, lp())
        row.addView(pill("إغلاق", "#2A2F4A") { finish() }, lp())
        panel.addView(
            row,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        root.addView(
            panel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )
        return root
    }

    private fun setState(s: OrbState, status: String) {
        state = s
        orb.state = s
        statusView.text = status
    }

    // ------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Config(this)
        setContentView(buildUi())
        setState(OrbState.IDLE, "جاهز")
        tts = TextToSpeech(this, this)
        startListening()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        startListening()
    }

    override fun onStop() {
        super.onStop()
        if (!leftApp && !isChangingConfigurations) finish()
    }

    override fun onDestroy() {
        destroyed = true
        requestId++
        destroyRecognizer()
        tts?.stop()
        tts?.shutdown()
        tts = null
        worker.shutdownNow()
        super.onDestroy()
    }

    // ---------------------------------------------------------- permissions

    private fun hasMic(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasMic()) {
            startListening()
        } else {
            setState(OrbState.IDLE, "ما عندي صلاحية الميكروفون")
            textView.text = "افتح إعدادات التطبيق وفعّل الميكروفون"
        }
    }

    // ------------------------------------------------------------ listening

    private fun onMicClick() {
        requestId++
        tts?.stop()
        startListening()
    }

    private fun destroyRecognizer() {
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
            // ignore
        }
        recognizer = null
    }

    private fun makeRecognizer(): SpeechRecognizer {
        if (usingGoogle) {
            try {
                packageManager.getServiceInfo(GOOGLE_RECOGNIZER, 0)
                return SpeechRecognizer.createSpeechRecognizer(this, GOOGLE_RECOGNIZER)
            } catch (e: Exception) {
                usingGoogle = false
            }
        }
        return SpeechRecognizer.createSpeechRecognizer(this)
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            orb.setLevel((rmsdB + 2f) / 12f)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            orb.setLevel(0f)
        }

        override fun onError(error: Int) {
            handleError(error)
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val t = (list?.firstOrNull() ?: "").trim()
            if (t.isEmpty()) handleError(SpeechRecognizer.ERROR_NO_MATCH) else process(t)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val t = list?.firstOrNull()
            if (!t.isNullOrEmpty()) textView.text = t
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun startListening() {
        if (destroyed) return
        leftApp = false
        if (!cfg.anyKey()) {
            setState(OrbState.IDLE, "ما في مفتاح محفوظ")
            textView.text = "افتح الإعدادات وحط مفتاح واحد على الأقل"
            return
        }
        if (!hasMic()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
            return
        }
        tts?.stop()
        destroyRecognizer()
        val r = makeRecognizer()
        recognizer = r
        r.setRecognitionListener(recognitionListener)

        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        val lang = cfg.lang
        if (lang.isNotEmpty()) {
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
        }
        try {
            r.startListening(i)
            setState(OrbState.LISTENING, "أسمعك…")
            textView.text = ""
        } catch (e: Exception) {
            setState(OrbState.IDLE, "ما قدرت أشغل الميكروفون")
        }
    }

    private fun handleError(error: Int) {
        if (destroyed) return
        if (error == SpeechRecognizer.ERROR_CLIENT && usingGoogle) {
            // Google's recogniser could not be used on this phone, fall back to the default one once
            usingGoogle = false
            startListening()
            return
        }
        val msg = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                "ما سمعت شي. اضغط «تكلم» وجرّب مرة ثانية"
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                "في مشكلة بالإنترنت"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                "أحتاج صلاحية الميكروفون"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                "التعرف على الصوت مشغول، جرّب بعد ثانية"
            else -> "تعذّر التعرف على الصوت (رمز $error)"
        }
        setState(OrbState.IDLE, "جاهز")
        textView.text = msg
    }

    // ------------------------------------------------------------- thinking

    private fun process(text: String) {
        textView.text = text
        setState(OrbState.THINKING, "أفكّر…")
        val id = ++requestId
        val app = applicationContext
        try {
            worker.execute {
                val reply = try {
                    Brain.ask(app, text)
                } catch (e: Exception) {
                    Reply("صار خطأ غير متوقع، جرّب مرة ثانية.", emptyList(), false)
                }
                ui.post {
                    if (!destroyed && id == requestId) onReply(reply)
                }
            }
        } catch (e: Exception) {
            setState(OrbState.IDLE, "جاهز")
        }
    }

    private fun onReply(reply: Reply) {
        val failures = ArrayList<String>()
        for (a in reply.actions) {
            val r = DeviceActions.run(this, a)
            if (r.leftApp) leftApp = true
            if (!r.ok) failures.add(r.message)
        }
        var spoken = if (failures.isEmpty()) reply.say else failures.joinToString("، ")
        if (spoken.isBlank()) spoken = "تم"
        followUpAfterSpeech = reply.followUp && failures.isEmpty()
        textView.text = spoken
        speak(spoken)
    }

    // -------------------------------------------------------------- speaking

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            ttsReady = false
            pendingSpeech?.let { setState(OrbState.IDLE, "الصوت غير متوفر") }
            return
        }
        val lang = cfg.lang
        val loc = if (lang.isEmpty()) Locale.getDefault() else Locale.forLanguageTag(lang)
        var res = t.setLanguage(loc)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            res = t.setLanguage(Locale("ar"))
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                ui.post { onSpeechDone() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                ui.post { onSpeechDone() }
            }
        })
        ttsReady = true
        val p = pendingSpeech
        if (p != null) {
            pendingSpeech = null
            speak(p)
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) {
            pendingSpeech = text
            return
        }
        setState(OrbState.SPEAKING, "أتكلم…")
        val t = text.take(3500)
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, Bundle(), "u" + System.nanoTime())
    }

    private fun onSpeechDone() {
        if (destroyed) return
        if (leftApp) {
            finish()
            return
        }
        if (followUpAfterSpeech) {
            followUpAfterSpeech = false
            startListening()
        } else {
            setState(OrbState.IDLE, "اضغط «تكلم» للمتابعة")
        }
    }
}
