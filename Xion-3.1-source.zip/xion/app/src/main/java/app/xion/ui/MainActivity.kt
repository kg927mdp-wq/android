package app.xion.ui

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import app.xion.ui.compose.AboutPage
import app.xion.ui.compose.ChatScreen
import app.xion.ui.compose.Page
import app.xion.ui.compose.ProvidersPage
import app.xion.ui.compose.SecurityPage
import app.xion.ui.compose.SettingsHome
import app.xion.ui.compose.UsagePage
import app.xion.ui.compose.XionBackground

/** Xion 3.0 launcher screen (Jetpack Compose). The old Views settings screen lives on as [LegacySettingsActivity]. */
class MainActivity : ComponentActivity() {
    private var controller: ChatController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val c = ChatController(this)
        controller = c
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                var page by remember { mutableStateOf(Page.CHAT) }
                val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { c.onMicPermissionResult(it) }
                LaunchedEffect(c.needMicPermission.value) {
                    if (c.needMicPermission.value) mic.launch(Manifest.permission.RECORD_AUDIO)
                }
                BackHandler(enabled = page != Page.CHAT) { page = if (page == Page.PROVIDERS || page == Page.USAGE || page == Page.SECURITY || page == Page.ABOUT) Page.SETTINGS else Page.CHAT }
                XionBackground {
                    when (page) {
                        Page.CHAT -> ChatScreen(c) { page = Page.SETTINGS }
                        Page.SETTINGS -> SettingsHome({ page = it }) { page = Page.CHAT }
                        Page.PROVIDERS -> ProvidersPage { page = Page.SETTINGS }
                        Page.USAGE -> UsagePage { page = Page.SETTINGS }
                        Page.SECURITY -> SecurityPage { page = Page.SETTINGS }
                        Page.ABOUT -> AboutPage { page = Page.SETTINGS }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        if (isFinishing) controller?.dispose()
        super.onDestroy()
    }
}
