package app.xion.voice.live

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.AudioAttributes
import android.media.AudioTrack.MODE_STREAM
import android.media.AudioRecord.READ_BLOCKING
import android.media.AudioTrack.WRITE_BLOCKING
import android.media.AudioFormat.CHANNEL_IN_MONO
import android.media.AudioFormat.CHANNEL_OUT_MONO
import android.media.AudioFormat.ENCODING_PCM_16BIT
import android.media.AudioTrack.PLAYSTATE_PLAYING
import android.util.Base64
import app.xion.data.Config
import app.xion.ai.provider.Provider
import app.xion.security.Redactor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Native Gemini Live bidirectional audio/video transport.
 * Audio input is PCM16/16kHz, output PCM16/24kHz; video is JPEG and capped by caller to <=1 FPS.
 * This direct-client implementation uses the existing encrypted Gemini key. Production deployments
 * should exchange it for a short-lived ephemeral token on a trusted backend before opening the socket.
 */
class GeminiLiveSession(
    context: Context,
    private val config: Config,
    private val callbacks: Callbacks,
    /** Recent turns of the shared conversation, sent once at the start so the voice session continues the same topic. */
    private val history: () -> List<Pair<String, String>> = { emptyList() }
) : Closeable {
    interface Callbacks {
        fun onStatus(text: String)
        fun onConnected(connected: Boolean) {}
        fun onTranscript(text: String, fromModel: Boolean) {}
        /** One finished exchange (what the user said and what Xion said). Goes into the shared conversation. */
        fun onTurn(user: String, model: String) {}
        /** The model wants a phone action. It must go through the policy gateway; answer with [sendToolResponse]. */
        fun onToolCall(id: String, name: String, args: Map<String, Any?>) {}
        fun onToolCancelled(ids: List<String>) {}
        fun onAudioActivity(active: Boolean) {}
        fun onError(message: String)
        /** The live session ended unexpectedly: the app should fall back to the ordinary voice path. */
        fun onFallback(reason: String) {}
    }

    private val app = context.applicationContext
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    private val alive = AtomicBoolean(false)
    private val ready = AtomicBoolean(false)
    private val playbackLock = Any()
    @Volatile private var socket: WebSocket? = null
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var track: AudioTrack? = null
    private var captureThread: Thread? = null
    private val assembler = LiveTurnAssembler()

    fun start(): Boolean {
        if (alive.get()) return true
        if (app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            callbacks.onError("يلزم إذن الميكروفون لتشغيل الصوت الحي.")
            return false
        }
        val key = config.key(Provider.GEMINI)
        if (key.isBlank()) {
            callbacks.onError("أضف مفتاح Gemini من إعدادات المزوّدات أولاً.")
            return false
        }
        alive.set(true)
        callbacks.onStatus("جارٍ الاتصال بـ Gemini Live…")
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" + java.net.URLEncoder.encode(key, "UTF-8")
        val request = Request.Builder().url(url).build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(LiveProtocol.setup(config.geminiLiveModel))
            }
            override fun onMessage(webSocket: WebSocket, text: String) = handleMessage(text)
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val was = alive.get()
                stopInternal()
                if (was) {
                    val why = Redactor.scrub(t.message ?: "خطأ شبكة").take(120)
                    callbacks.onError("تعذر اتصال Gemini Live: $why")
                    callbacks.onFallback(why)
                }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                val was = alive.get()
                stopInternal()
                if (was) callbacks.onFallback(Redactor.scrub(reason).take(120).ifBlank { "انتهت الجلسة" })
            }
        })
        return true
    }

    private fun handleMessage(raw: String) {
        try {
            for (e in LiveProtocol.parse(raw)) {
                when (e) {
                    is LiveEvent.SetupComplete -> {
                        ready.set(true)
                        LiveProtocol.history(history())?.let { socket?.send(it) }
                        callbacks.onConnected(true)
                        callbacks.onStatus("Gemini Live متصل · الصوت والرؤية جاهزان")
                        startAudioCapture()
                    }
                    is LiveEvent.Interrupted -> {
                        synchronized(playbackLock) { track?.pause(); track?.flush(); track?.play() }
                        assembler.feed(e)?.let { callbacks.onTurn(it.user, it.model) }
                    }
                    is LiveEvent.UserText -> {
                        callbacks.onTranscript(e.text, false)
                        assembler.feed(e)?.let { callbacks.onTurn(it.user, it.model) }
                    }
                    is LiveEvent.ModelText -> {
                        callbacks.onTranscript(e.text, true)
                        assembler.feed(e)
                    }
                    is LiveEvent.TurnComplete -> assembler.feed(e)?.let { callbacks.onTurn(it.user, it.model) }
                    is LiveEvent.Audio -> playPcm(Base64.decode(e.base64, Base64.DEFAULT))
                    is LiveEvent.ToolCall -> callbacks.onToolCall(e.id, e.name, e.args)
                    is LiveEvent.ToolCancelled -> callbacks.onToolCancelled(e.ids)
                    is LiveEvent.GoAway -> callbacks.onStatus("Gemini Live سينهي الجلسة قريباً")
                }
            }
        } catch (e: Exception) {
            callbacks.onError("تعذر قراءة استجابة الصوت الحي.")
        }
    }

    /** Answers a tool call. Only call this with the outcome of the policy gateway, never with a guess. */
    fun sendToolResponse(id: String, name: String, ok: Boolean, message: String): Boolean {
        if (!alive.get() || !ready.get()) return false
        return socket?.send(LiveProtocol.toolResponse(id, name, ok, message)) == true
    }

    private fun startAudioCapture() {
        if (captureThread != null) return
        val min = AudioRecord.getMinBufferSize(16_000, CHANNEL_IN_MONO, ENCODING_PCM_16BIT)
        if (min <= 0) { callbacks.onError("الجهاز لا يدعم تسجيل الصوت المطلوب."); return }
        val bufferSize = maxOf(min * 2, 6400)
        val input = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16_000, CHANNEL_IN_MONO, ENCODING_PCM_16BIT, bufferSize)
        if (input.state != AudioRecord.STATE_INITIALIZED) { input.release(); callbacks.onError("تعذر تهيئة الميكروفون."); return }
        recorder = input
        try { input.startRecording() } catch (e: Exception) { input.release(); recorder = null; callbacks.onError("تعذر بدء الميكروفون."); return }
        captureThread = thread(name = "Xion-Live-Audio", isDaemon = true) {
            val buffer = ByteArray(3200) // 100 ms at 16 kHz mono PCM16
            try {
                while (alive.get() && ready.get()) {
                    val count = input.read(buffer, 0, buffer.size, READ_BLOCKING)
                    if (count > 0) {
                        val bytes = if (count == buffer.size) buffer else buffer.copyOf(count)
                        val audio = JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
                            .put("mimeType", "audio/pcm;rate=16000")
                            .put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))))
                        socket?.send(audio.toString())
                    }
                }
            } catch (e: Exception) { if (alive.get()) callbacks.onError("توقف التقاط الصوت.") }
        }
    }

    private fun playPcm(bytes: ByteArray) {
        if (bytes.isEmpty()) return
        synchronized(playbackLock) {
            var output = track
            if (output == null || output.state != AudioTrack.STATE_INITIALIZED) {
                val min = AudioTrack.getMinBufferSize(24_000, CHANNEL_OUT_MONO, ENCODING_PCM_16BIT)
                if (min <= 0) return
                output = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(24_000).setChannelMask(CHANNEL_OUT_MONO).setEncoding(ENCODING_PCM_16BIT).build())
                    .setBufferSizeInBytes(maxOf(min * 2, 9600)).setTransferMode(MODE_STREAM).build()
                if (output.state != AudioTrack.STATE_INITIALIZED) { output.release(); return }
                track = output
            }
            if (output.playState != PLAYSTATE_PLAYING) output.play()
            var offset = 0
            while (offset < bytes.size && alive.get()) {
                val wrote = output.write(bytes, offset, bytes.size - offset, WRITE_BLOCKING)
                if (wrote <= 0) break
                offset += wrote
            }
        }
    }

    /** Send one JPEG frame into the same live session; callers must cap this to one frame per second. */
    fun sendVideoFrame(jpeg: ByteArray): Boolean {
        if (!alive.get() || !ready.get() || jpeg.isEmpty() || jpeg.size > 1_500_000) return false
        return socket?.send(JSONObject().put("realtimeInput", JSONObject().put("video", JSONObject()
            .put("mimeType", "image/jpeg").put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP)))).toString()) == true
    }

    fun sendText(text: String): Boolean {
        if (!alive.get() || !ready.get() || text.isBlank()) return false
        return socket?.send(JSONObject().put("realtimeInput", JSONObject().put("text", text.take(4000))).toString()) == true
    }

    private fun stopInternal() {
        val wasReady = ready.get()
        alive.set(false); ready.set(false)
        assembler.flush(true)?.let { callbacks.onTurn(it.user, it.model) }
        if (wasReady) callbacks.onConnected(false)
        try { recorder?.stop() } catch (_: Exception) { }
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null
        captureThread = null
        synchronized(playbackLock) {
            try { track?.pause(); track?.flush(); track?.stop() } catch (_: Exception) { }
            try { track?.release() } catch (_: Exception) { }
            track = null
        }
        callbacks.onAudioActivity(false)
    }

    override fun close() {
        alive.set(false)
        ready.set(false)
        socket?.close(1000, "Xion session closed")
        socket = null
        stopInternal()
    }
}
