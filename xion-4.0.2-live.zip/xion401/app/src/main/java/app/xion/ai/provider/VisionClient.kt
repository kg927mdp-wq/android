package app.xion.ai.provider

import android.util.Base64
import app.xion.data.Config
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** One-shot image understanding for OpenAI-compatible vision endpoints. Image bytes are sent only for this request. */
class VisionClient(private val config: Config) {
    fun analyze(jpeg: ByteArray, question: String): String {
        require(jpeg.isNotEmpty() && jpeg.size <= MAX_IMAGE_BYTES) { "حجم الصورة غير مناسب (الحد 6 MB)." }
        val provider = Provider.fromName(config.primary) ?: Provider.GEMINI
        val key = config.key(provider)
        require(key.isNotBlank()) { "أضف مفتاح ${provider.label} أولاً." }
        val model = config.model(provider)
        require(model.isNotBlank()) { "اختر موديلاً يدعم الصور من إعدادات ${provider.label}." }
        val modelInfo = config.savedModels(provider).firstOrNull { it.id == model }
        require(modelInfo?.supportsVision != false) { "الموديل المحدد لا يعلن دعماً للصور. اختر موديل Vision أولاً." }
        val data = "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP)
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", question.take(1500)))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", data)))
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", content))
        val body = JSONObject().put("model", model).put("messages", messages).put("stream", false)
            .put("max_tokens", 1200).toString()
        val connection = (URL(provider.url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            provider.extraHeaders.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        try {
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(120_000) }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("${provider.label}: رفض تحليل الصورة ($code). تأكد أن الموديل يدعم الصور وأن مزودك يقبل image_url.")
            val root = JSONObject(response)
            val message = root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
            val text = message?.optString("content")?.takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("الموديل لم يرجع وصفاً للصورة.")
            return text
        } finally {
            connection.disconnect()
        }
    }

    companion object { private const val MAX_IMAGE_BYTES = 6 * 1024 * 1024 }
}
