package app.xion.ai

import android.content.Context
import app.xion.ai.orchestrator.Orchestrator
import app.xion.ai.orchestrator.ProviderStats
import app.xion.ai.orchestrator.FlightRecorder
import app.xion.ai.orchestrator.TaskWorkflow
import app.xion.ai.provider.UrlTransport
import app.xion.data.Config
import app.xion.data.ConfigRouting

/** Builds the one engine and orchestrator the whole app shares: the chat screen, the voice overlay and the settings screens all use these. */
object XionApp {
    private var engineRef: ConversationEngine? = null
    private var orchRef: Orchestrator? = null
    private var routingRef: ConfigRouting? = null
    private var workflowRef: TaskWorkflow? = null

    @Synchronized
    private fun init(ctx: Context) {
        if (engineRef != null) return
        val app = ctx.applicationContext
        val cfg = Config(app)
        val routing = ConfigRouting(cfg)
        val stats = ProviderStats()
        val flight = FlightRecorder()
        try { stats.loadJson(cfg.statsJson) } catch (_: Exception) { /* remeasure */ }
        try { flight.loadJson(cfg.flightJson) } catch (_: Exception) { /* start a clean trace */ }
        val orch = Orchestrator(UrlTransport(), routing, stats, flightRecorder = flight)
        fun persistTelemetry() {
            cfg.statsJson = stats.toJson()
            cfg.flightJson = flight.toJson()
        }
        val settings = object : EngineSettings {
            override val mode: String get() = cfg.mode
            override val searchEnabled: Boolean get() = cfg.searchEnabled
        }
        val search = SearchPort { q ->
            val hits = try {
                WebSearch.search(q, cfg.tavilyKey)
            } catch (e: Exception) {
                emptyList()
            }
            WebSearch.format(q, hits)
        }
        routingRef = routing
        orchRef = orch
        workflowRef = TaskWorkflow(orch)
        engineRef = ConversationEngine(orch, settings, search, onTurnFinished = { persistTelemetry() })
    }

    fun engine(ctx: Context): ConversationEngine {
        init(ctx)
        return engineRef!!
    }

    fun orchestrator(ctx: Context): Orchestrator {
        init(ctx)
        return orchRef!!
    }

    fun routing(ctx: Context): ConfigRouting {
        init(ctx)
        return routingRef!!
    }

    fun workflow(ctx: Context): TaskWorkflow {
        init(ctx)
        return workflowRef!!
    }
}
