@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package app.xion.ui.compose

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.xion.ai.XionApp
import app.xion.ai.orchestrator.Strategy
import app.xion.ai.orchestrator.TaskType
import app.xion.ai.provider.ModelInfo
import app.xion.ai.provider.Provider
import app.xion.data.Config
import app.xion.device.ActionGateway
import app.xion.ui.LegacySettingsActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Page(val title: String) {
    CHAT("Xion"), SETTINGS("الإعدادات"), PROVIDERS("المزوّدون"), USAGE("الاستخدام والقياسات"), SECURITY("مركز الأمان"), ABOUT("حول")
}

@Composable
private fun Screen(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clickable(onClick = onBack), contentAlignment = Alignment.Center) {
                XIcon("arrow-right", Modifier.size(22.dp), X.text)
            }
            XText(title, 20, weight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 4.dp)) {
            content()
            Box(Modifier.size(24.dp))
        }
    }
}

@Composable
fun SettingsHome(go: (Page) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cfg = remember { Config(ctx) }
    var strategy by remember { mutableStateOf(cfg.strategy) }
    var mode by remember { mutableStateOf(cfg.mode) }
    var search by remember { mutableStateOf(cfg.searchEnabled) }
    var speak by remember { mutableStateOf(cfg.speakReplies) }
    var primary by remember { mutableStateOf(cfg.primary) }
    Screen("الإعدادات", onBack) {
        SectionTitle("اختيار المزوّد (Routing)")
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (s in Strategy.values()) Chip(s.label, if (s == strategy) X.cyan else X.muted) {
                        strategy = s; cfg.strategy = s; XionApp.routing(ctx).invalidate()
                    }
                }
                XText(strategy.help, 12, X.muted, modifier = Modifier.padding(top = 10.dp))
                XText("المزوّد المفضّل (يبدأ به)", 13, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (p in Provider.values()) Chip(p.label, if (p.name == primary) X.purple else X.muted) { primary = p.name; cfg.primary = p.name }
                }
            }
        }
        SectionTitle("توجيه المهام المتخصص")
        val routes = remember { mutableStateOf(TaskType.values().associateWith { cfg.taskRoute(it) }) }
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                XText("حدد المزوّد الذي يبدأ به كل نوع من المهام. خيار تلقائي يترك القرار لاستراتيجية التوجيه العامة. يلزم تفعيل المزوّد وحفظ مفتاحه واختيار موديل متاح حتى يدخل في التوجيه.", 12, X.muted)
                for (task in TaskType.values()) {
                    XText(task.label, 14, weight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Chip("تلقائي", if (routes.value[task] == null) X.cyan else X.muted) {
                            cfg.setTaskRoute(task, null)
                            routes.value = routes.value + (task to null)
                            XionApp.routing(ctx).invalidate()
                        }
                        for (provider in Provider.values()) {
                            Chip(provider.label, if (routes.value[task] == provider) X.purple else X.muted) {
                                cfg.setTaskRoute(task, provider)
                                routes.value = routes.value + (task to provider)
                                XionApp.routing(ctx).invalidate()
                            }
                        }
                    }
                }
            }
        }
        SectionTitle("الجواب")
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                XText("نمط الجواب", 13, modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for ((k, l) in listOf("instant" to "فوري + تدقيق", "careful" to "دقيق (يدقق قبل الكلام)", "fast" to "سريع بلا تدقيق"))
                        Chip(l, if (mode == k) X.cyan else X.muted) { mode = k; cfg.mode = k }
                }
                Row2("البحث بالإنترنت", "نتائج البحث تُعامل كمعلومات غير موثوقة") { Toggle(search) { search = it; cfg.searchEnabled = it } }
                Row2("قراءة الردود المكتوبة بصوت عالٍ", "أسئلة الصوت تُجاب بالصوت دائماً") { Toggle(speak) { speak = it; cfg.speakReplies = it } }
            }
        }
        SectionTitle("الأقسام")
        for ((p, d) in listOf(
            Page.PROVIDERS to "المفاتيح، الموديلات، الفحص",
            Page.USAGE to "السرعة والنجاح والتكلفة التقديرية (قياس فعلي)",
            Page.SECURITY to "الصلاحيات، سجل التدقيق، النسخ الاحتياطي",
            Page.ABOUT to "الإصدار والحدود المعروفة"
        )) {
            Glass(Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { go(p) }) {
                Column(Modifier.padding(16.dp)) { XText(p.title, 16, weight = FontWeight.SemiBold); XText(d, 12, X.muted, modifier = Modifier.padding(top = 2.dp)) }
            }
        }
        GlassButton("الإعدادات القديمة (اللغة، الدولة، النسخ الاحتياطي المشفّر)", Modifier.fillMaxWidth()) {
            ctx.startActivity(Intent(ctx, LegacySettingsActivity::class.java))
        }
    }
}

@Composable
fun ProvidersPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cfg = remember { Config(ctx) }
    val orch = remember { XionApp.orchestrator(ctx) }
    var tick by remember { mutableStateOf(0) } // forces a refresh after a change
    Screen("المزوّدون", onBack) {
        XText("لا يُفترض أي مزوّد مجانياً: التصنيف «مجاني» يظهر فقط إذا قال المزوّد نفسه ذلك في قائمة موديلاته أو إذا صنّفته أنت. معلومات الأسعار والحدود لم تُتحقق من وثائق كل مزوّد (ما عدا OpenRouter).", 12, X.muted)
        @Suppress("UNUSED_EXPRESSION") tick
        for (p in Provider.values()) ProviderCard(p, cfg, orch) { tick++ }
    }
}

@Composable
private fun ProviderCard(p: Provider, cfg: Config, orch: app.xion.ai.orchestrator.Orchestrator, changed: () -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    var keyDraft by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(cfg.model(p)) }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var models by remember { mutableStateOf(cfg.savedModels(p)) }
    var filter by remember { mutableStateOf("") }
    var enabled by remember { mutableStateOf(cfg.enabled(p)) }
    var free by remember { mutableStateOf(cfg.declaredFree(p)) }
    val s = orch.stats.snapshot(p)

    Glass(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.clickable { open = !open }, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    XText(p.label, 16, weight = FontWeight.SemiBold)
                    XText(
                        (if (cfg.hasKey(p)) "مفتاح محفوظ مشفّراً ✓" else "لا يوجد مفتاح") + " · " + (if (model.isEmpty()) "لم يُختر موديل" else model),
                        11, X.muted, maxLines = 1
                    )
                }
                if (s.cooldownUntil > System.currentTimeMillis()) Chip("متوقف مؤقتاً", X.warn)
                Box(Modifier.padding(start = 8.dp)) { Toggle(enabled) { enabled = it; cfg.setEnabled(p, it); changed() } }
            }
            if (open) {
                Chip(if (p.docsChecked) "الوثائق مراجعة" else "الوثائق لم تُراجع", if (p.docsChecked) X.ok else X.warn)
                GlassField(keyDraft, { keyDraft = it }, if (cfg.hasKey(p)) "مفتاح جديد (يستبدل المحفوظ)" else "مفتاح API", Modifier.fillMaxWidth().padding(top = 10.dp), secret = true)
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("حفظ المفتاح", accent = true, enabled = keyDraft.isNotBlank()) {
                        status = if (cfg.setKey(p, keyDraft)) { keyDraft = ""; orch.stats.resetHealth(p); changed(); "تم الحفظ مشفّراً" } else "تعذّر الحفظ الآمن، لم يُحفظ شيء"
                    }
                    if (cfg.hasKey(p)) GlassButton("حذف المفتاح") { cfg.setKey(p, ""); status = "حُذف المفتاح"; changed() }
                }
                GlassField(model, { model = it }, "اسم الموديل", Modifier.fillMaxWidth().padding(top = 10.dp))
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("حفظ الموديل") { cfg.setModel(p, model); status = "تم حفظ الموديل"; changed() }
                    GlassButton(if (busy) "…" else "اكتشاف الموديلات", enabled = !busy && cfg.hasKey(p)) {
                        busy = true; status = "أسأل المزوّد…"
                        Thread {
                            val r = try { val l = orch.discover(p); cfg.saveModels(p, l); XionApp.routing(ctx).invalidate(); models = l; "وجدت ${l.size} موديل" }
                            catch (e: app.xion.ai.provider.ProviderError) { e.describe() }
                            catch (e: Exception) { "تعذّر الاكتشاف" }
                            status = r; busy = false
                        }.start()
                    }
                    GlassButton("فحص", enabled = !busy && cfg.hasKey(p)) {
                        busy = true; status = "أفحص…"
                        Thread { val r = orch.ping(p); status = r; busy = false; XionApp.engine(ctx); cfg.statsJson = orch.stats.toJson() }.start()
                    }
                }
                status?.let { XText(it, 13, X.cyan, modifier = Modifier.padding(top = 8.dp)) }
                Row2("أنا على خطة مجانية عند هذا المزوّد", "تصنيفك أنت؛ لا يعني بلا حدود") { Toggle(free) { free = it; cfg.setDeclaredFree(p, it); changed() } }
                if (models.isNotEmpty()) {
                    GlassField(filter, { filter = it }, "ابحث في ${models.size} موديل", Modifier.fillMaxWidth())
                    val shown = models.filter { filter.isBlank() || it.id.contains(filter.trim(), true) || (it.name ?: "").contains(filter.trim(), true) }.take(30)
                    for (m in shown) ModelRow(m, m.id == model) { model = m.id; cfg.setModel(p, m.id); status = "اخترت ${m.id}"; changed() }
                    if (shown.size == 30) XText("يظهر أول 30 فقط، استخدم البحث.", 11, X.muted, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

@Composable
private fun ModelRow(m: ModelInfo, selected: Boolean, pick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = pick).padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            XText(m.id, 13, if (selected) X.cyan else X.text, maxLines = 1)
            XText(
                listOfNotNull(
                    if (m.isFree) "مجاني حسب المزوّد" else m.pricePerMillion?.let { "≈ \$" + String.format(Locale.US, "%.2f", it) + " / مليون" },
                    m.contextLength?.let { "سياق ${it / 1000}K" },
                    if (m.supportsTools == true) "أدوات" else null,
                    if (m.supportsVision == true) "صور" else null
                ).joinToString(" · ").ifEmpty { "المزوّد لم يذكر تفاصيل" }, 11, X.muted
            )
        }
        if (selected) XText("✓", 16, X.cyan)
    }
}

@Composable
fun UsagePage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val orch = remember { XionApp.orchestrator(ctx) }
    var trace by remember { mutableStateOf(orch.flightRecorder.recent(25)) }
    val traceFmt = remember { SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()) }
    Screen("الاستخدام والقياسات", onBack) {
        XText("كل الأرقام هنا مقاسة من استخدامك الفعلي. التوكنز والتكلفة تقديرات (عدد الحروف ÷ 4) وليست فواتير المزوّد.", 12, X.muted)
        SectionTitle("مسجل رحلات النماذج")
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                XText("يسجل المزوّد والموديل ونوع المهمة والمدة والنتيجة فقط. لا يحفظ نصوصك أو مفاتيح API.", 11, X.muted)
                if (trace.isEmpty()) XText("لا توجد رحلات بعد.", 12, X.muted, modifier = Modifier.padding(top = 8.dp))
                for (event in trace) {
                    val outcome = when (event.outcome) {
                        app.xion.ai.orchestrator.FlightEvent.Outcome.SUCCESS -> "نجاح"
                        app.xion.ai.orchestrator.FlightEvent.Outcome.FAILURE -> "فشل"
                        app.xion.ai.orchestrator.FlightEvent.Outcome.PARTIAL -> "جزئي"
                    }
                    XText("${traceFmt.format(Date(event.time))} · ${event.provider.label} / ${event.model}", 11, X.text, modifier = Modifier.padding(top = 9.dp), maxLines = 2)
                    XText("${event.task.label} · $outcome · ${event.durationMs} ms · ~${event.inputTokensEstimate}/${event.outputTokensEstimate} tokens" + (event.error?.let { " · $it" } ?: ""), 10, X.muted)
                }
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("تحديث") { trace = orch.flightRecorder.recent(25) }
                    GlassButton("مسح الرحلات") { orch.flightRecorder.clear(); Config(ctx).flightJson = ""; trace = emptyList() }
                }
            }
        }
        for (p in Provider.values()) {
            val s = orch.stats.snapshot(p)
            Glass(Modifier.fillMaxWidth().padding(top = 10.dp)) {
                Column(Modifier.padding(14.dp)) {
                    XText(p.label, 15, weight = FontWeight.SemiBold)
                    if (s.attempts == 0) XText("لا قياسات بعد", 12, X.muted, modifier = Modifier.padding(top = 4.dp))
                    else {
                        XText("نجاح ${s.ok} / فشل ${s.fail}  (${((s.successRate ?: 0.0) * 100).toInt()}%)", 13, modifier = Modifier.padding(top = 4.dp))
                        XText("أول كلمة: ${s.avgFirstTokenMs?.toLong() ?: "؟"} م.ث · كامل: ${s.avgTotalMs?.toLong() ?: "؟"} م.ث", 12, X.muted)
                        XText("توكنز تقديرية: دخل ${s.estTokensIn} · خرج ${s.estTokensOut}", 12, X.muted)
                        if (s.reviews > 0) XText("مراجعات: ${s.reviews} اختلفت عن المسودة في ${s.reviewFixes}", 12, X.muted)
                        s.lastError?.let { XText("آخر خطأ: $it", 12, X.bad) }
                    }
                }
            }
        }
        GlassButton("تصفير القياسات", Modifier.padding(top = 14.dp)) { orch.stats.clear(); Config(ctx).statsJson = "" }
    }
}

@Composable
fun SecurityPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cfg = remember { Config(ctx) }
    var direct by remember { mutableStateOf(cfg.directCall) }
    val log = remember { ActionGateway.auditFor(ctx) }
    var entries by remember { mutableStateOf(log.recent(40)) }
    val fmt = remember { SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()) }
    fun granted(perm: String) = ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
    Screen("مركز الأمان", onBack) {
        SectionTitle("الصلاحيات")
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                for ((n, perm) in listOf("الميكروفون" to Manifest.permission.RECORD_AUDIO, "الاتصال" to Manifest.permission.CALL_PHONE, "جهات الاتصال" to Manifest.permission.READ_CONTACTS))
                    Row(Modifier.padding(vertical = 4.dp)) { XText(n, 14, modifier = Modifier.weight(1f)); XText(if (granted(perm)) "ممنوحة" else "غير ممنوحة", 13, if (granted(perm)) X.ok else X.muted) }
                XText("الكتابة تعمل بدون أي صلاحية. Xion لا يستخدم خدمة إمكانية الوصول للتحكم بالجهاز.", 11, X.muted, modifier = Modifier.padding(top = 6.dp, bottom = 10.dp))
                GlassButton("فتح إعدادات التطبيق") {
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }
        SectionTitle("الموافقة")
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 14.dp)) {
                XText("كل اتصال أو رسالة أو فتح رابط يحتاج موافقتك. أوامر النموذج تمر بنظام سياسة يسمح فقط بقائمة محددة من الإجراءات.", 12, X.muted, modifier = Modifier.padding(top = 12.dp))
                Row2("بدء الاتصال مباشرة بعد موافقتك", "الموافقة تبقى مطلوبة دائماً") { Toggle(direct) { direct = it; cfg.directCall = it } }
            }
        }
        SectionTitle("سجل التدقيق (آخر 40)")
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                if (entries.isEmpty()) XText("لا سجلات", 13, X.muted)
                for (e in entries.reversed()) XText(fmt.format(Date(e.time)) + "  ${e.type}  ${e.outcome}  ${e.note}", 11, X.muted, modifier = Modifier.padding(vertical = 2.dp))
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton("تحديث") { entries = log.recent(40) }
                    GlassButton("مسح السجل") { log.clear(); entries = emptyList() }
                }
            }
        }
        SectionTitle("النسخ الاحتياطي")
        GlassButton("تصدير/استيراد مشفّر (الواجهة القديمة)", Modifier.fillMaxWidth()) { ctx.startActivity(Intent(ctx, LegacySettingsActivity::class.java)) }
    }
}

@Composable
fun AboutPage(onBack: () -> Unit) {
    Screen("حول", onBack) {
        Column(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            XionLogo(Modifier.size(120.dp), active = true)
            XText("Xion 4.0.0", 22, weight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            XText("TECH TO EASY LIFE", 12, X.cyan)
        }
        Glass(Modifier.fillMaxWidth().padding(top = 18.dp)) {
            Column(Modifier.padding(16.dp)) {
                XText("تطبيق منفصل عن مساعدي 2.1 (app.xion). لا يقرأ بيانات النسخة القديمة؛ انقل إعداداتك عبر نسخة احتياطية مشفّرة.", 13)
                XText("المتوفر: محادثة نصية وصوتية متتابعة، توجيه متكيّف بين المزوّدين، مجلس مراجعة متعدد النماذج، سير مهام محدود، ذاكرة مهام مشفّرة، سجل رحلات النماذج، بحث اختياري، وسياسة موافقة وسجل تدقيق لأوامر الجهاز.", 12, X.muted, modifier = Modifier.padding(top = 10.dp))
                XText("غير متوفر بعد: بث صوتي حي ثنائي الاتجاه مع مقاطعة طبيعية، بث الكاميرا/الشاشة، وكلاء مستقلون ينفذون أدوات خارجية، ومزامنة ذاكرة عبر الأجهزة. لا تعتبر هذه الميزات منفذة حالياً.", 12, X.warn, modifier = Modifier.padding(top = 8.dp))
                XText("الواجهة الحالية لم تُختبر على جهاز فعلي. يلزم بناء APK وتجربته في Android Studio قبل اعتماد الإصدار.", 11, X.muted, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}
