package app.xion.ui

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateOf
import app.xion.ai.BrainListener
import app.xion.ai.EngineSnapshot
import app.xion.ai.EngineState
import app.xion.ai.Role
import app.xion.ai.Source
import app.xion.ai.XionApp
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import app.xion.data.Config
import app.xion.data.TaskCapsule
import app.xion.data.TaskCapsuleStore
import app.xion.device.ActionGateway
import app.xion.security.Action
import app.xion.security.Decision
import app.xion.voice.ConfirmationMatcher
import app.xion.voice.Verdict
import app.xion.voice.VoiceController
import app.xion.voice.VoiceFailure
import app.xion.voice.VoiceSessionPolicy
import app.xion.voice.live.GeminiLiveSession
import app.xion.voice.live.LiveProtocol
import app.xion.device.ActionResult

/**
 * Glue between the chat screen, the shared [app.xion.ai.ConversationEngine] and the voice controller.
 * Typed and spoken messages take exactly the same path (engine -> orchestrator -> policy gateway); this class only
 * decides whether an answer is also read aloud and runs the approval flow for sensitive device actions.
 * Use from the main thread.
 */
class ChatController(context: Context) : VoiceController.Callback {

    private val app = context.applicationContext
    private val cfg = Config(app)
    val engine = XionApp.engine(app)
    private val main = Handler(Looper.getMainLooper())

    // state observed by the screen
    val snapshot = mutableStateOf(engine.snapshot())
    val listening = mutableStateOf(false)
    val speaking = mutableStateOf(false)
    val continuousVoice = mutableStateOf(cfg.continuousVoice)
    val level = mutableStateOf(0f)
    val partial = mutableStateOf("")
    val confirm = mutableStateOf<Decision.Confirm?>(null)
    val notice = mutableStateOf<String?>(null)
    /** Set when the microphone is wanted but not permitted yet; the screen asks Android and calls [onMicPermissionResult]. */
    val needMicPermission = mutableStateOf(false)
    val workflowBusy = mutableStateOf(false)
    val workflowCanCancel = mutableStateOf(false)
    val workflowStatus = mutableStateOf<String?>(null)
    private val capsuleStore = TaskCapsuleStore(app)
    val recentCapsules = mutableStateOf(capsuleStore.all())
    private val workflowExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "xion-workflow").also { it.isDaemon = true } }
    @Volatile private var workflowCancelled = AtomicBoolean(false)

    /** Gemini Live voice session state. The session shares this controller's conversation, policy gateway and approvals. */
    val liveOn = mutableStateOf(false)
    val liveReady = mutableStateOf(false)
    val liveStatus = mutableStateOf<String?>(null)
    private var liveSession: GeminiLiveSession? = null
    private var liveGateway: ActionGateway? = null
    private var pendingLive = false
    private val liveCalls = java.util.IdentityHashMap<Decision.Confirm, String>()
    private val liveTimeouts = HashMap<String, Runnable>()

    private var voiceRef: VoiceController? = null
    private var gateway: ActionGateway? = null
    private val queue = ArrayDeque<Decision.Confirm>()
    private var unheard = 0
    private var resumeAfterReply = false
    @Volatile private var lastCameraAnalysis: String = ""
    private val voiceRestart = Runnable {
        if (continuousVoice.value && confirm.value == null && engine.snapshot().state == EngineState.IDLE) startMic()
    }
    private var lastSource = Source.TEXT
    private val unsubscribe: () -> Unit = engine.subscribe { main.post { snapshot.value = engine.snapshot() } }

    private fun voice(): VoiceController = voiceRef ?: VoiceController(app, this).also { voiceRef = it }

    // ------------------------------------------------------------------ sending

    /** Sends a typed message. Returns false when nothing was sent (empty, or an answer is still being produced). */
    fun sendText(text: String): Boolean {
        if (text.isBlank()) return false
        if (liveOn.value) stopLive() // typing switches from the live voice session to text; the conversation stays the same
        if (workflowBusy.value) {
            notice.value = "Xion ينفّذ خطة متعددة النماذج الآن. أوقفها أو انتظر اكتمالها."
            return false
        }
        if (engine.snapshot().state != EngineState.IDLE) {
            notice.value = "Xion يجاوب الآن، انتظر لحظة."
            return false
        }
        return submit(text, Source.TEXT)
    }

    private fun submit(text: String, source: Source): Boolean {
        dropConfirmations()
        resumeAfterReply = false
        main.removeCallbacks(voiceRestart)
        voiceRef?.stopSpeaking()
        lastSource = source
        gateway = ActionGateway(app)
        notice.value = null
        return engine.submit(text, source, sink(source), interrupt = source == Source.VOICE)
    }

    /** Sends one camera frame to a vision model. The caller awaits completion, so frames never overlap. */
    suspend fun analyzeCameraFrame(jpeg: ByteArray, question: String = "حلّل ما يظهر في الصورة واشرح التفاصيل المهمة."): String {
        if (workflowBusy.value || engine.snapshot().state != EngineState.IDLE) return "تخطّيت الإطار لأن Xion مشغول بمهمة أخرى."
        if (jpeg.isEmpty() || jpeg.size > 6 * 1024 * 1024) return "تخطّيت إطاراً فارغاً أو أكبر من 6 MB."
        workflowBusy.value = true
        workflowCanCancel.value = false
        workflowStatus.value = "أحلّل إطار الكاميرا…"
        return try {
            val previous = lastCameraAnalysis.take(1800)
            val contextualQuestion = if (previous.isBlank()) question else
                question + "\n\nملخص تحليل الإطار السابق للمقارنة فقط: " + previous +
                    "\nاذكر التغيّرات المرئية المؤكدة فقط، ولا تفترض استمرار شيء غير ظاهر."
            val result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                app.xion.ai.provider.VisionClient(cfg).analyze(jpeg, contextualQuestion)
            }
            lastCameraAnalysis = result.take(1800)
            engine.addNote("[إطار كاميرا محلّل] $question")
            engine.addNote(result)
            notice.value = "تم تحديث سياق الرؤية من الإطار الجديد."
            result
        } catch (e: Exception) {
            val message = "تعذر تحليل إطار الكاميرا: ${e.message ?: "خطأ غير معروف"}"
            notice.value = message
            message
        } finally {
            workflowBusy.value = false
            workflowStatus.value = null
        }
    }

    /** Drops only the in-memory visual comparison context when the camera session closes. */
    fun clearCameraContext() { lastCameraAnalysis = "" }

    /** Backward-compatible one-shot entry point for still images. */
    fun analyzeCameraPhoto(jpeg: ByteArray, question: String = "حلّل ما يظهر في الصورة واشرح التفاصيل المهمة.") {
        if (workflowBusy.value) { notice.value = "انتظر انتهاء المهمة الحالية قبل تحليل صورة جديدة."; return }
        workflowExecutor.execute {
            val result = try { app.xion.ai.provider.VisionClient(cfg).analyze(jpeg, question) }
            catch (e: Exception) { "تعذر تحليل الصورة: ${e.message ?: "خطأ غير معروف"}" }
            main.post {
                if (result.startsWith("تعذر تحليل الصورة:")) notice.value = result
                else { engine.addNote("[تحليل صورة] $question"); engine.addNote(result); notice.value = "اكتمل تحليل الصورة وأُضيف إلى سياق المحادثة." }
            }
        }
    }

    /** Runs an explicit multi-provider analysis workflow; it never performs device actions. */
    fun runWorkflow(goal: String) {
        val task = goal.trim()
        if (task.length < 12 || workflowBusy.value || engine.snapshot().state != EngineState.IDLE) {
            notice.value = "اكتب هدفاً أوضح (12 حرفاً على الأقل)، وانتظر انتهاء الرد الحالي."
            return
        }
        workflowCancelled = AtomicBoolean(false)
        workflowBusy.value = true
        workflowCanCancel.value = true
        workflowStatus.value = "أخطط للمهمة…"
        notice.value = null
        workflowExecutor.execute {
            val errors = ArrayList<app.xion.ai.provider.ProviderError>()
            val result = try {
                XionApp.workflow(app).run(
                    task,
                    cancelled = { workflowCancelled.get() },
                    onProgress = { step -> main.post { workflowStatus.value = "الخطوة ${step.index}: ${step.title.take(48)}" } },
                    errors = errors
                )
            } catch (_: Exception) { null }
            main.post {
                workflowBusy.value = false
                workflowCanCancel.value = false
                workflowStatus.value = null
                cfg.statsJson = XionApp.orchestrator(app).stats.toJson()
                cfg.flightJson = XionApp.orchestrator(app).flightRecorder.toJson()
                when {
                    result == null -> notice.value = if (workflowCancelled.get()) "تم إيقاف سير العمل قبل اكتمال أي خطوة." else errors.firstOrNull()?.describe() ?: "تعذر بدء سير العمل. تأكد من إعداد مزوّد وموديل صالح."
                    else -> {
                        val done = result.steps.count { it.result != null }
                        val capsule = TaskCapsule(
                            System.currentTimeMillis(), task.take(4000), result.finalText.take(12000),
                            done, result.steps.size, result.complete, System.currentTimeMillis()
                        )
                        if (capsuleStore.save(capsule)) recentCapsules.value = capsuleStore.all()
                        engine.addNote("خطة Xion: $done/${result.steps.size} خطوات مكتملة" + when { result.complete -> " · اكتمل التنسيق"; workflowCancelled.get() -> " · أُوقفت مع حفظ التقدم"; else -> " · نتيجة جزئية" })
                        engine.addNote(result.finalText)
                    }
                }
            }
        }
    }

    /** Runs an explicit cross-provider review. It is analysis-only and never invokes device actions. */
    fun runCouncil(goal: String) {
        val task = goal.trim()
        if (task.length < 12 || workflowBusy.value || engine.snapshot().state != EngineState.IDLE) {
            notice.value = "اكتب سؤالاً أوضح (12 حرفاً على الأقل)، وانتظر انتهاء الرد الحالي."
            return
        }
        workflowCancelled = AtomicBoolean(false)
        workflowBusy.value = true
        workflowCanCancel.value = false
        workflowStatus.value = "مجلس النماذج: صياغة ومراجعة مستقلة…"
        notice.value = null
        workflowExecutor.execute {
            val errors = ArrayList<app.xion.ai.provider.ProviderError>()
            val result = try {
                val profile = app.xion.ai.orchestrator.TaskAnalyzer.analyze(task, 0)
                XionApp.orchestrator(app).council(
                    listOf(
                        app.xion.ai.provider.ChatMsg("system", "أجب عن طلب المستخدم بدقة. افصل الحقائق عن الافتراضات، ولا تنفذ أي إجراء خارجي أو أمر على الجهاز."),
                        app.xion.ai.provider.ChatMsg("user", task)
                    ), profile, reviewers = 2, errors = errors
                )
            } catch (_: Exception) { null }
            main.post {
                workflowBusy.value = false
                workflowCanCancel.value = false
                workflowStatus.value = null
                cfg.statsJson = XionApp.orchestrator(app).stats.toJson()
                cfg.flightJson = XionApp.orchestrator(app).flightRecorder.toJson()
                if (result == null) {
                    notice.value = errors.firstOrNull()?.describe() ?: "تعذر تشغيل مجلس النماذج. تأكد من إعداد ثلاثة مزوّدين على الأقل لمراجعة مستقلة كاملة."
                } else {
                    val reviewCount = result.reviews.size
                    val summary = buildString {
                        append(result.finalText)
                        append("\n\n— سجل المجلس —\nالمسودة: ").append(result.draft.provider.label)
                        result.reviews.forEachIndexed { i, review -> append("\nالمراجع ").append(i + 1).append(": ").append(review.provider.label) }
                        if (result.synthesis == null) append("\nلم يتوفر مزوّد مستقل للتجميع النهائي؛ عُرضت المسودة مع المراجعات المتاحة.")
                    }
                    val capsule = TaskCapsule(System.currentTimeMillis(), task.take(4000), summary.take(12000),
                        1 + reviewCount + if (result.synthesis != null) 1 else 0, 4, result.synthesis != null, System.currentTimeMillis())
                    if (capsuleStore.save(capsule)) recentCapsules.value = capsuleStore.all()
                    engine.addNote("مجلس النماذج: ${reviewCount} مراجعات مستقلة" + if (result.synthesis != null) " · تم التجميع النهائي" else " · نتيجة جزئية")
                    engine.addNote(result.finalText)
                }
            }
        }
    }

    /** Reintroduces a saved task capsule as explicit context; it does not silently execute anything. */
    fun restoreCapsule(capsule: TaskCapsule) {
        engine.addNote("سياق مهمة محفوظة: ${capsule.goal}")
        engine.addNote("ملخص المهمة السابقة: ${capsule.summary}")
        notice.value = "أُضيف ملخص المهمة إلى سياق المحادثة الحالية."
    }

    fun deleteCapsule(id: Long) {
        if (capsuleStore.delete(id)) recentCapsules.value = capsuleStore.all()
    }

    fun cancelWorkflow() {
        if (!workflowCanCancel.value) return
        workflowCancelled.set(true)
        workflowStatus.value = "جارٍ إيقاف سير العمل…"
    }

    fun retry() {
        val lastUser = engine.snapshot().messages.lastOrNull { it.role == Role.USER }
        val src = lastUser?.source ?: Source.TEXT
        gateway = ActionGateway(app)
        engine.retry(sink(src))
    }

    /** Forgets the conversation: screen, model context and any waiting approval. */
    fun clear() {
        if (liveOn.value) stopLive()
        if (workflowBusy.value) cancelWorkflow()
        resumeAfterReply = false
        main.removeCallbacks(voiceRestart)
        dropConfirmations()
        voiceRef?.stopSpeaking()
        voiceRef?.stopListening()
        engine.clear()
        notice.value = null
    }

    private fun sink(source: Source) = object : BrainListener {
        private val speak = source == Source.VOICE || cfg.speakReplies
        override fun isCancelled() = false
        override fun onSearching(query: String) {}
        override fun onSentence(text: String) {
            if (speak) main.post { voice().speak(text) }
        }

        override fun onAction(action: Map<String, Any?>, tainted: Boolean) {
            main.post { propose(action, tainted) }
        }

        override fun onDone(followUp: Boolean) {
            if (VoiceSessionPolicy.shouldResumeAfterReply(source == Source.VOICE, followUp, continuousVoice.value)) {
                main.post {
                    resumeAfterReply = true
                    if (!speaking.value) resumeVoiceSession()
                }
            }
        }

        override fun onCorrection(text: String) {
            if (speak) main.post { voice().speak("تصحيح: $text") }
        }

        override fun onFailure(message: String) {}
    }

    // ------------------------------------------------------------------ device actions (always through the policy gateway)

    private fun propose(raw: Map<String, Any?>, tainted: Boolean) {
        val gw = gateway ?: return
        when (val d = gw.propose(raw, tainted)) {
            is Decision.Allow -> run(gw, d.action, false)
            is Decision.Confirm -> {
                queue.addLast(d)
                showNext()
            }
            is Decision.Reject -> engine.addNote("ما أقدر أنفذ هذا الأمر.")
        }
    }

    private fun run(gw: ActionGateway, a: Action, confirmed: Boolean): ActionResult {
        val r = gw.execute(a, confirmed)
        engine.addNote(if (r.ok) "✓ " + a.describe() else "✗ " + r.message)
        return r
    }

    private fun showNext() {
        if (confirm.value != null) return
        val d = queue.removeFirstOrNull() ?: return
        confirm.value = d
        unheard = 0
        if (!liveOn.value && (lastSource == Source.VOICE || cfg.speakReplies)) {
            voice().speak(if (d.action is Action.OpenUrl) "أحتاج موافقتك لفتح رابط." else "أحتاج موافقتك: " + d.action.describe())
        }
    }

    /** The user pressed "نفّذ" or "إلغاء" (or said yes / no). */
    fun confirmAction(accept: Boolean) {
        val d = confirm.value ?: return
        confirm.value = null
        voiceRef?.stopListening()
        val liveId = liveCalls.remove(d)
        val gw = if (liveId != null) liveGateway else gateway
        var result: ActionResult? = null
        if (accept && gw != null) result = run(gw, d.action, true) else {
            gw?.deny(d.action)
            engine.addNote("أُلغي: " + d.action.describe())
        }
        if (liveId != null) answerLive(liveId, result?.ok == true, result?.let { if (it.ok) "تم التنفيذ" else it.message } ?: "المستخدم رفض أو ألغى")
        showNext()
    }

    private fun answerLive(id: String, ok: Boolean, message: String) {
        liveTimeouts.remove(id)?.let { main.removeCallbacks(it) }
        liveSession?.sendToolResponse(id, LiveProtocol.TOOL_NAME, ok, message)
    }

    private fun dropConfirmations() {
        val gw = gateway
        val cur = confirm.value
        if (gw != null) {
            if (cur != null) gw.deny(cur.action)
            for (d in queue) gw.deny(d.action)
        }
        confirm.value = null
        queue.clear()
        dropLiveConfirmations("أُلغي الطلب")
    }

    /** Denies every phone action the live model is still waiting on. */
    private fun dropLiveConfirmations(reason: String) {
        if (liveCalls.isEmpty()) return
        val gw = liveGateway
        for ((d, id) in liveCalls.entries.toList()) {
            gw?.deny(d.action)
            if (confirm.value === d) confirm.value = null
            queue.remove(d)
            answerLive(id, false, reason)
        }
        liveCalls.clear()
    }

    // ------------------------------------------------------------------ Gemini Live

    fun startLive() {
        if (liveOn.value) return
        if (workflowBusy.value || engine.snapshot().state != EngineState.IDLE) {
            notice.value = "انتظر انتهاء الجواب الحالي قبل تشغيل الصوت الحي."
            return
        }
        if (cfg.key(app.xion.ai.provider.Provider.GEMINI).isBlank()) {
            notice.value = "الصوت الحي يحتاج مفتاح Gemini. أضفه من المزوّدين. تقدر تكتب أو تستخدم الميكروفون العادي."
            return
        }
        if (!voice().hasMic()) {
            pendingLive = true
            needMicPermission.value = true
            return
        }
        resumeAfterReply = false
        main.removeCallbacks(voiceRestart)
        voiceRef?.stopListening()
        voiceRef?.stopSpeaking()
        liveGateway = ActionGateway(app)
        val session = GeminiLiveSession(app, cfg, liveCallbacks) { engine.recentTurns(LiveProtocol.MAX_HISTORY_TURNS) }
        if (session.start()) {
            liveSession = session
            liveOn.value = true
            liveStatus.value = "جارٍ الاتصال بـ Gemini Live…"
            notice.value = null
        }
    }

    /** Ends the live session. [message] is shown when the end was not the user's choice. */
    fun stopLive(message: String? = null) {
        dropLiveConfirmations("انتهت الجلسة")
        val s = liveSession
        liveSession = null
        liveOn.value = false
        liveReady.value = false
        liveStatus.value = null
        pendingLive = false
        try { s?.close() } catch (_: Exception) { }
        if (message != null) notice.value = message
    }

    /** The app moved to the background: Android does not allow a silent live microphone there. */
    fun onAppBackground() {
        if (liveOn.value) stopLive("توقف الصوت الحي لأن التطبيق انتقل للخلفية.")
    }

    fun sendLiveVideo(jpeg: ByteArray): Boolean = liveSession?.sendVideoFrame(jpeg) == true

    private fun onLiveTool(id: String, name: String, args: Map<String, Any?>) {
        val s = liveSession ?: return
        if (name != LiveProtocol.TOOL_NAME) {
            s.sendToolResponse(id, name, false, "أداة غير معروفة")
            return
        }
        val gw = liveGateway ?: ActionGateway(app).also { liveGateway = it }
        // everything the model sends is untrusted data: same policy, same approval, same audit log as the text path
        when (val d = gw.propose(args, false)) {
            is Decision.Allow -> {
                val r = run(gw, d.action, false)
                s.sendToolResponse(id, name, r.ok, if (r.ok) "تم التنفيذ" else r.message)
            }
            is Decision.Confirm -> {
                liveCalls[d] = id
                queue.addLast(d)
                val timeout = Runnable {
                    val pending = liveCalls.entries.firstOrNull { it.value == id }?.key ?: return@Runnable
                    if (confirm.value === pending) confirm.value = null
                    queue.remove(pending)
                    liveCalls.remove(pending)
                    liveGateway?.deny(pending.action)
                    engine.addNote("انتهت مهلة الموافقة: " + pending.action.describe())
                    answerLive(id, false, "انتهت مهلة موافقة المستخدم")
                    showNext()
                }
                liveTimeouts[id] = timeout
                main.postDelayed(timeout, LIVE_APPROVAL_MS)
                showNext()
            }
            is Decision.Reject -> {
                engine.addNote("ما أقدر أنفذ هذا الأمر.")
                s.sendToolResponse(id, name, false, "رُفض الإجراء حسب سياسة الأمان")
            }
        }
    }

    private val liveCallbacks = object : GeminiLiveSession.Callbacks {
        override fun onStatus(text: String) { main.post { if (liveOn.value) liveStatus.value = text } }
        override fun onConnected(connected: Boolean) { main.post { liveReady.value = connected } }
        override fun onTurn(user: String, model: String) {
            main.post {
                engine.recordLiveTurn(user, model)
                if (liveCalls.isEmpty()) liveGateway = ActionGateway(app) // fresh per-turn action budget, never while an approval is pending
            }
        }
        override fun onToolCall(id: String, name: String, args: Map<String, Any?>) { main.post { onLiveTool(id, name, args) } }
        override fun onToolCancelled(ids: List<String>) {
            main.post {
                for ((d, id) in liveCalls.entries.toList()) if (id in ids) {
                    liveGateway?.deny(d.action)
                    if (confirm.value === d) confirm.value = null
                    queue.remove(d)
                    liveCalls.remove(d)
                    liveTimeouts.remove(id)?.let { main.removeCallbacks(it) }
                    engine.addNote("أُلغي الطلب: " + d.action.describe())
                }
                showNext()
            }
        }
        override fun onError(message: String) { main.post { notice.value = message } }
        override fun onFallback(reason: String) {
            main.post {
                if (!liveOn.value) return@post
                stopLive("توقف الصوت الحي ($reason). رجعنا للمسار العادي: اضغط الميكروفون أو اكتب.")
                engine.addNote("انتهى الصوت الحي، المحادثة مستمرة بالمسار العادي.")
            }
        }
    }

    // ------------------------------------------------------------------ microphone

    fun onMicClick() {
        resumeAfterReply = false
        main.removeCallbacks(voiceRestart)
        val v = voice()
        if (listening.value) {
            v.stopListening()
            return
        }
        if (!v.hasMic()) {
            needMicPermission.value = true
            return
        }
        startMic()
    }

    /** Enables/disables hands-free turn-taking. Listening is resumed only after speech output completes. */
    fun setContinuousVoice(enabled: Boolean) {
        continuousVoice.value = enabled
        cfg.continuousVoice = enabled
        main.removeCallbacks(voiceRestart)
        if (!enabled) {
            resumeAfterReply = false
            voiceRef?.stopListening()
        } else if (!voice().hasMic()) {
            needMicPermission.value = true
        } else if (!listening.value && engine.snapshot().state == EngineState.IDLE && !speaking.value) {
            startMic()
        }
    }

    fun onMicPermissionResult(granted: Boolean) {
        needMicPermission.value = false
        val live = pendingLive
        pendingLive = false
        if (granted && live) {
            startLive()
        } else if (granted) {
            startMic()
        } else {
            notice.value = "الميكروفون غير مسموح. تقدر تكتب رسائلك، أو فعّل الميكروفون من إعدادات التطبيق."
        }
    }

    private fun startMic() {
        partial.value = ""
        voice().startListening(if (confirm.value != null) 5 else 1)
    }

    // ------------------------------------------------------------------ VoiceController.Callback

    override fun onListeningChanged(listening: Boolean) {
        this.listening.value = listening
        if (!listening) partial.value = ""
    }

    override fun onLevel(level: Float) {
        this.level.value = level
    }

    override fun onPartial(text: String) {
        partial.value = text
    }

    override fun onResult(alternatives: List<String>, confidences: FloatArray?) {
        if (confirm.value != null) {
            when (ConfirmationMatcher.interpret(alternatives, confidences)) {
                Verdict.YES -> confirmAction(true)
                Verdict.NO -> confirmAction(false)
                Verdict.UNSURE -> notUnderstood()
            }
            return
        }
        submit(alternatives.first(), Source.VOICE)
    }

    override fun onRecognitionError(code: Int) {
        if (confirm.value != null) {
            notUnderstood()
            return
        }
        notice.value = when (code) {
            android.speech.SpeechRecognizer.ERROR_NO_MATCH, android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                if (continuousVoice.value) "ما سمعت كلاماً. أستمع من جديد…" else "ما سمعت شي. اضغط الميكروفون وجرّب مرة ثانية."
            android.speech.SpeechRecognizer.ERROR_NETWORK, android.speech.SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "في مشكلة بالإنترنت."
            android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "أحتاج صلاحية الميكروفون."
            android.speech.SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "التعرف على الصوت مشغول، جرّب بعد ثانية."
            else -> "تعذّر التعرف على الصوت (رمز $code)."
        }
        val failure = when (code) {
            android.speech.SpeechRecognizer.ERROR_NO_MATCH -> VoiceFailure.NO_MATCH
            android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> VoiceFailure.SPEECH_TIMEOUT
            android.speech.SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> VoiceFailure.RECOGNIZER_BUSY
            android.speech.SpeechRecognizer.ERROR_NETWORK, android.speech.SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> VoiceFailure.NETWORK
            android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> VoiceFailure.PERMISSION
            else -> VoiceFailure.OTHER
        }
        if (VoiceSessionPolicy.shouldRetryListening(continuousVoice.value, failure)) {
            main.removeCallbacks(voiceRestart)
            main.postDelayed(voiceRestart, VoiceSessionPolicy.retryDelayMillis(failure))
        }
    }

    private fun notUnderstood() {
        unheard++
        if (unheard < 2) {
            notice.value = "ما فهمت. قل نعم أو لا، أو اضغط الزر."
            startMic()
        } else {
            notice.value = "اضغط نفّذ أو إلغاء."
        }
    }

    private fun resumeVoiceSession() {
        if (!resumeAfterReply) return
        resumeAfterReply = false
        if ((continuousVoice.value || lastSource == Source.VOICE) && confirm.value == null && voice().hasMic()) startMic()
    }

    override fun onSpeakingChanged(speaking: Boolean) {
        this.speaking.value = speaking
        // Resume only after TTS finishes; opening the recognizer stops any active speech output.
        if (!speaking && resumeAfterReply) resumeVoiceSession()
        // after Xion asks for approval out loud, listen for the answer once
        if (!speaking && confirm.value != null && unheard == 0 && lastSource == Source.VOICE && voice().hasMic()) startMic()
    }

    fun dispose() {
        stopLive()
        unsubscribe()
        main.removeCallbacks(voiceRestart)
        resumeAfterReply = false
        dropConfirmations()
        voiceRef?.shutdown()
        voiceRef = null
    }

    private companion object {
        /** How long a phone action asked for by the live model waits for the user's approval. */
        const val LIVE_APPROVAL_MS = 60_000L
    }
}
