package app.xion.ui.compose

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sin

/** Xion's colours: deep dark base, purple and cyan light, translucent white layers. */
object X {
    val bg = Color(0xFF060814)
    val purple = Color(0xFF8B5CFF)
    val cyan = Color(0xFF22D3EE)
    val text = Color(0xFFE9ECFF)
    val muted = Color(0xFF8F98C4)
    val ok = Color(0xFF4ADE80)
    val bad = Color(0xFFFF7A8A)
    val warn = Color(0xFFFBBF24)
    val accent = Brush.horizontalGradient(listOf(purple, cyan))
}

/** Full-screen dark background with two slow-moving soft lights (radial gradients: no blur API needed, works on every Android version). */
@Composable
fun XionBackground(content: @Composable () -> Unit) {
    val t = rememberInfiniteTransition(label = "bg")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "p")
    Box(Modifier.fillMaxSize().background(X.bg)) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawCircle(
                Brush.radialGradient(listOf(X.purple.copy(alpha = 0.30f), Color.Transparent), Offset(w * (0.15f + 0.25f * p), h * 0.12f), w * 0.9f),
                radius = w * 0.9f, center = Offset(w * (0.15f + 0.25f * p), h * 0.12f)
            )
            drawCircle(
                Brush.radialGradient(listOf(X.cyan.copy(alpha = 0.20f), Color.Transparent), Offset(w * (0.9f - 0.3f * p), h * 0.88f), w * 0.8f),
                radius = w * 0.8f, center = Offset(w * (0.9f - 0.3f * p), h * 0.88f)
            )
        }
        content()
    }
}

/** A translucent layered panel: light gradient fill, thin light edge. */
@Composable
fun Glass(modifier: Modifier = Modifier, radius: Dp = 22.dp, strong: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(radius)
    Column(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = if (strong) 0.20f else 0.11f), Color.White.copy(alpha = if (strong) 0.09f else 0.04f))), shape)
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.30f), Color.White.copy(alpha = 0.06f))), shape),
        content = content
    )
}

@Composable
fun XText(
    text: String,
    size: Int = 15,
    color: Color = X.text,
    weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier,
    maxLines: Int = Int.MAX_VALUE,
    lineHeight: Int = 0
) {
    BasicText(
        text,
        modifier,
        TextStyle(color = color, fontSize = size.sp, fontWeight = weight, lineHeight = if (lineHeight > 0) lineHeight.sp else TextStyle.Default.lineHeight),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun GlassButton(label: String, modifier: Modifier = Modifier, accent: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val fill = if (accent) Brush.horizontalGradient(listOf(X.purple.copy(alpha = 0.85f), X.cyan.copy(alpha = 0.75f)))
    else SolidColor(Color.White.copy(alpha = 0.10f))
    Box(
        modifier
            .clip(shape)
            .background(fill, shape)
            .border(1.dp, Color.White.copy(alpha = if (accent) 0.0f else 0.18f), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        XText(label, 14, if (enabled) X.text else X.muted, FontWeight.Medium)
    }
}

@Composable
fun Chip(label: String, color: Color = X.muted, onClick: (() -> Unit)? = null) {
    val shape = RoundedCornerShape(50)
    var m = Modifier.clip(shape).background(color.copy(alpha = 0.14f), shape).border(1.dp, color.copy(alpha = 0.35f), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Box(m.padding(horizontal = 12.dp, vertical = 5.dp)) { XText(label, 12, color) }
}

@Composable
fun Toggle(checked: Boolean, onChange: (Boolean) -> Unit) {
    val x by animateDpAsState(if (checked) 20.dp else 0.dp, label = "toggle")
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .size(width = 46.dp, height = 26.dp)
            .clip(shape)
            .background(if (checked) X.accent else SolidColor(Color.White.copy(alpha = 0.14f)), shape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onChange(!checked) }
            .padding(3.dp)
    ) {
        Box(Modifier.offset(x = x).size(20.dp).clip(CircleShape).background(Color.White))
    }
}

@Composable
fun GlassField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    secret: Boolean = false,
    singleLine: Boolean = true,
    maxLines: Int = if (singleLine) 1 else 5
) {
    val shape = RoundedCornerShape(14.dp)
    BasicTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier.clip(shape).background(Color.Black.copy(alpha = 0.28f), shape).border(1.dp, Color.White.copy(alpha = 0.14f), shape),
        textStyle = TextStyle(color = X.text, fontSize = 15.sp),
        cursorBrush = SolidColor(X.cyan),
        singleLine = singleLine,
        maxLines = maxLines,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions.Default,
        decorationBox = { inner ->
            Box(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                if (value.isEmpty()) XText(hint, 15, X.muted)
                inner()
            }
        }
    )
}

@Composable
fun SectionTitle(text: String) {
    XText(text, 13, X.cyan, FontWeight.SemiBold, Modifier.padding(start = 6.dp, top = 18.dp, bottom = 8.dp))
}

@Composable
fun Row2(label: String, hint: String? = null, content: @Composable () -> Unit) {
    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            XText(label, 15)
            if (hint != null) XText(hint, 12, X.muted, modifier = Modifier.padding(top = 2.dp))
        }
        content()
    }
}

/**
 * The Xion mark: an X built from four gradient arms around an open centre with a turning diamond node,
 * lit by a soft purple/cyan glow that breathes slowly. Drawn in code, so it scales to any size.
 */
@Composable
fun XionLogo(modifier: Modifier = Modifier.size(64.dp), active: Boolean = false) {
    val t = rememberInfiniteTransition(label = "logo")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(if (active) 1600 else 4200, easing = LinearEasing), RepeatMode.Restart), label = "p")
    Canvas(modifier) {
        val s = size.minDimension
        val c = Offset(size.width / 2, size.height / 2)
        val breath = 0.5f + 0.5f * sin(p * 6.2831855f)
        drawCircle(
            Brush.radialGradient(listOf(X.purple.copy(alpha = 0.22f + 0.22f * breath), X.cyan.copy(alpha = 0.06f), Color.Transparent), c, s * 0.62f),
            radius = s * 0.62f, center = c
        )
        val g1 = Brush.linearGradient(listOf(X.purple, X.cyan), Offset(c.x - s / 3, c.y - s / 3), Offset(c.x + s / 3, c.y + s / 3))
        val g2 = Brush.linearGradient(listOf(X.cyan, X.purple), Offset(c.x + s / 3, c.y - s / 3), Offset(c.x - s / 3, c.y + s / 3))
        val gap = s * 0.09f
        val arm = s * 0.36f
        val w = s * 0.13f
        fun arm(dx: Float, dy: Float, b: Brush) =
            drawLine(b, Offset(c.x + dx * gap, c.y + dy * gap), Offset(c.x + dx * arm, c.y + dy * arm), strokeWidth = w, cap = StrokeCap.Round)
        arm(-1f, -1f, g1)
        arm(1f, 1f, g1)
        arm(1f, -1f, g2)
        arm(-1f, 1f, g2)
        rotate(45f + 360f * p, c) {
            val d = s * 0.075f
            drawRect(X.accent, Offset(c.x - d, c.y - d), Size(d * 2, d * 2))
        }
    }
}

/** Three dots that pulse one after another while the answer is being prepared. */
@Composable
fun ThinkingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    val p by t.animateFloat(0f, 3f, infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart), label = "p")
    Row(Modifier.padding(vertical = 6.dp)) {
        for (i in 0..2) {
            val a = if (p.toInt() == i) 1f else 0.3f
            Box(Modifier.padding(end = 6.dp).size(8.dp).clip(CircleShape).background(X.cyan.copy(alpha = a)))
        }
    }
}

/** Small original vector glyphs used throughout Xion; deliberately no platform emoji glyphs. */
@Composable
fun XIcon(kind: String, modifier: Modifier = Modifier.size(20.dp), tint: Color = X.text) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = (size.minDimension * 0.085f).coerceAtLeast(1.5f)
        val c = Offset(w / 2f, h / 2f)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
            drawLine(tint, Offset(x1 * w, y1 * h), Offset(x2 * w, y2 * h), sw, StrokeCap.Round)
        when (kind) {
            "camera" -> {
                drawRoundRect(tint, Offset(w * .12f, h * .27f), Size(w * .76f, h * .58f), androidx.compose.ui.geometry.CornerRadius(w * .10f), style = androidx.compose.ui.graphics.drawscope.Stroke(sw))
                drawRoundRect(tint, Offset(w * .32f, h * .16f), Size(w * .30f, h * .12f), androidx.compose.ui.geometry.CornerRadius(w * .04f))
                drawCircle(tint, w * .16f, c, style = androidx.compose.ui.graphics.drawscope.Stroke(sw))
                drawCircle(tint, w * .055f, c)
            }
            "mic" -> {
                drawRoundRect(tint, Offset(w * .38f, h * .12f), Size(w * .24f, h * .52f), androidx.compose.ui.geometry.CornerRadius(w * .12f), style = androidx.compose.ui.graphics.drawscope.Stroke(sw))
                line(.25f, .48f, .25f, .54f); line(.25f, .54f, .34f, .70f); line(.34f, .70f, .50f, .76f)
                line(.50f, .76f, .66f, .70f); line(.66f, .70f, .75f, .54f); line(.75f, .54f, .75f, .48f)
                line(.50f, .76f, .50f, .90f); line(.36f, .90f, .64f, .90f)
            }
            "stop" -> drawRoundRect(tint, Offset(w * .25f, h * .25f), Size(w * .5f, h * .5f), androidx.compose.ui.geometry.CornerRadius(w * .06f))
            "trash" -> {
                line(.28f, .27f, .72f, .27f); line(.40f, .16f, .60f, .16f)
                line(.34f, .34f, .38f, .84f); line(.66f, .34f, .62f, .84f); line(.38f, .84f, .62f, .84f)
                line(.46f, .40f, .46f, .74f); line(.54f, .40f, .54f, .74f)
            }
            "settings" -> {
                drawCircle(tint, w * .31f, c, style = androidx.compose.ui.graphics.drawscope.Stroke(sw))
                drawCircle(tint, w * .09f, c)
                for (a in 0..7) {
                    val angle = a * Math.PI / 4.0
                    val x1 = .50f + kotlin.math.cos(angle).toFloat() * .36f
                    val y1 = .50f + kotlin.math.sin(angle).toFloat() * .36f
                    val x2 = .50f + kotlin.math.cos(angle).toFloat() * .46f
                    val y2 = .50f + kotlin.math.sin(angle).toFloat() * .46f
                    line(x1, y1, x2, y2)
                }
            }
            "send" -> { line(.14f, .50f, .86f, .50f); line(.58f, .22f, .86f, .50f); line(.58f, .78f, .86f, .50f) }
            "workflow" -> {
                drawCircle(tint, w * .12f, Offset(w * .22f, h * .22f))
                drawCircle(tint, w * .12f, Offset(w * .78f, h * .22f))
                drawCircle(tint, w * .12f, Offset(w * .50f, h * .78f))
                line(.34f, .22f, .66f, .22f); line(.27f, .34f, .44f, .66f); line(.73f, .34f, .56f, .66f)
            }
            "archive" -> {
                line(.18f, .30f, .82f, .30f); line(.22f, .30f, .26f, .84f); line(.78f, .30f, .74f, .84f)
                line(.26f, .84f, .74f, .84f); line(.38f, .48f, .62f, .48f); line(.42f, .60f, .58f, .60f)
            }
            "close" -> { line(.24f, .24f, .76f, .76f); line(.76f, .24f, .24f, .76f) }
            "arrow-down" -> { line(.50f, .12f, .50f, .84f); line(.22f, .56f, .50f, .84f); line(.78f, .56f, .50f, .84f) }
            "arrow-right" -> { line(.14f, .50f, .86f, .50f); line(.58f, .22f, .86f, .50f); line(.58f, .78f, .86f, .50f) }
            else -> { line(.2f, .5f, .8f, .5f); line(.5f, .2f, .5f, .8f) }
        }
    }
}
