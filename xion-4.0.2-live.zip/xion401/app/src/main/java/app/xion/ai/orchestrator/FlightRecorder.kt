package app.xion.ai.orchestrator

import app.xion.ai.provider.ErrorKind
import app.xion.ai.provider.Provider
import app.xion.security.Json

/** Privacy-preserving operational trace. It deliberately never stores prompts, completions, or API keys. */
data class FlightEvent(
    val time: Long,
    val provider: Provider,
    val model: String,
    val task: TaskType,
    val outcome: Outcome,
    val durationMs: Long,
    val inputTokensEstimate: Int,
    val outputTokensEstimate: Int,
    val error: ErrorKind? = null
) {
    enum class Outcome { SUCCESS, FAILURE, PARTIAL }
}

class FlightRecorder(private val clock: () -> Long = { System.currentTimeMillis() }, private val limit: Int = 60) {
    private val events = ArrayDeque<FlightEvent>()

    @Synchronized
    fun record(
        provider: Provider, model: String, task: TaskType, outcome: FlightEvent.Outcome,
        durationMs: Long, inputChars: Int, outputChars: Int, error: ErrorKind? = null
    ) {
        events.addLast(FlightEvent(clock(), provider, model.take(100), task, outcome,
            durationMs.coerceAtLeast(0), (inputChars.coerceAtLeast(0) / 4),
            (outputChars.coerceAtLeast(0) / 4), error))
        while (events.size > limit.coerceIn(1, 200)) events.removeFirst()
    }

    @Synchronized fun recent(max: Int = 30): List<FlightEvent> = events.toList().takeLast(max.coerceIn(1, 200)).reversed()
    @Synchronized fun clear() = events.clear()

    @Synchronized
    fun toJson(): String = Json.stringify(events.map { e ->
        mapOf("time" to e.time, "provider" to e.provider.name, "model" to e.model,
            "task" to e.task.name, "outcome" to e.outcome.name, "duration" to e.durationMs,
            "in" to e.inputTokensEstimate, "out" to e.outputTokensEstimate, "error" to e.error?.name)
    })

    @Synchronized
    fun loadJson(raw: String) {
        val list = Json.parse(raw, Json.API) as? List<*> ?: return
        events.clear()
        list.takeLast(limit.coerceIn(1, 200)).forEach { item ->
            val m = item as? Map<*, *> ?: return@forEach
            val provider = Provider.fromName(m["provider"] as? String ?: return@forEach) ?: return@forEach
            val task = runCatching { TaskType.valueOf(m["task"] as? String ?: "CHAT") }.getOrDefault(TaskType.CHAT)
            val outcome = runCatching { FlightEvent.Outcome.valueOf(m["outcome"] as? String ?: "FAILURE") }.getOrDefault(FlightEvent.Outcome.FAILURE)
            val error = (m["error"] as? String)?.let { runCatching { ErrorKind.valueOf(it) }.getOrNull() }
            events.addLast(FlightEvent(
                (m["time"] as? Number)?.toLong() ?: return@forEach, provider,
                (m["model"] as? String).orEmpty().take(100), task, outcome,
                (m["duration"] as? Number)?.toLong() ?: 0L,
                (m["in"] as? Number)?.toInt() ?: 0, (m["out"] as? Number)?.toInt() ?: 0, error
            ))
        }
    }
}
