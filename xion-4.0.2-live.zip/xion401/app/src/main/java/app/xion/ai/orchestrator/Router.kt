package app.xion.ai.orchestrator

import app.xion.ai.provider.ModelInfo
import app.xion.ai.provider.Provider

/** How the router orders providers. Every rule uses user choices or measured data, never invented rankings. */
enum class Strategy(val label: String, val help: String) {
    MANUAL("يدوي", "يبدأ بالمزوّد الذي اخترته ثم يجرّب الباقي عند الفشل"),
    AUTO("تلقائي", "للأوامر والمحادثة: الأسرع حسب القياس. للتحليل والبرمجة: المزوّد المفضّل أولاً"),
    SPEED("أسرع استجابة", "الأقل زمناً حسب القياسات الفعلية"),
    COST("أرخص", "الأقل سعراً حسب أسعار المزوّد نفسه، والمعروف سعره قبل المجهول"),
    FREE_ONLY("مجاني فقط", "فقط النماذج التي يقول المزوّد إنها بلا تكلفة، أو صنّفتها أنت مجاناً"),
    ADAPTIVE("ذكي متكيّف", "يرتّب النماذج حسب الاعتمادية والسرعة والتكلفة المقاسة، مع مراعاة نوع المهمة"),
    QUALITY("أعلى جودة", "يبدأ بالمزوّد المفضّل؛ استخدم زر مجلس النماذج لمراجعة مستقلة متعددة المزوّدين")
}

data class Candidate(val provider: Provider, val model: String, val info: ModelInfo?, val declaredFree: Boolean)

object Router {
    fun rank(
        profile: TaskProfile,
        candidates: List<Candidate>,
        strategy: Strategy,
        primary: Provider?,
        taskRoute: Provider?,
        stats: ProviderStats
    ): List<Candidate> {
        var pool = candidates
        if (strategy == Strategy.FREE_ONLY) pool = pool.filter { it.declaredFree || it.info?.isFree == true }

        fun fits(c: Candidate): Boolean {
            val ctx = c.info?.contextLength ?: return true
            return profile.approxTokens < ctx * 0.8
        }
        val byPrimary = compareBy<Candidate>(
            { if (it.provider == taskRoute) 0 else 1 },
            { if (it.provider == primary) 0 else 1 },
            { it.provider.ordinal }
        )
        val latency = compareBy<Candidate> {
            stats.snapshot(it.provider).let { s -> s.avgFirstTokenMs ?: s.avgTotalMs ?: Double.MAX_VALUE }
        }
        val failureRate = compareBy<Candidate> { 1.0 - (stats.snapshot(it.provider).successRate ?: 0.5) }
        val adaptive = adaptiveOrder(pool, profile, taskRoute, primary, stats)
        val order: Comparator<Candidate> = when (strategy) {
            Strategy.ADAPTIVE -> adaptive
            Strategy.MANUAL, Strategy.QUALITY, Strategy.FREE_ONLY ->
                if (strategy == Strategy.FREE_ONLY) byPrimary.thenComparing(latency) else byPrimary
            Strategy.SPEED -> compareBy<Candidate> { if (it.provider == taskRoute) 0 else 1 }.then(latency).then(byPrimary)
            Strategy.COST -> compareBy<Candidate> { if (it.provider == taskRoute) 0 else 1 }
                .thenBy { c -> if (c.declaredFree || c.info?.isFree == true) 0 else 1 }
                .thenBy { c -> c.info?.pricePerMillion ?: Double.MAX_VALUE }
                .then(byPrimary)
            Strategy.AUTO -> when (profile.type) {
                TaskType.COMMAND, TaskType.CHAT -> compareBy<Candidate> { if (it.provider == taskRoute) 0 else 1 }.then(latency).then(byPrimary)
                else -> byPrimary.then(failureRate).then(latency)
            }
        }
        val healthy = pool.filter { !stats.isCoolingDown(it.provider) }.sortedWith(order)
        val cooling = pool.filter { stats.isCoolingDown(it.provider) }.sortedBy { stats.snapshot(it.provider).cooldownUntil }
        val all = healthy + cooling
        return all.filter { fits(it) } + all.filter { !fits(it) }
    }

    /**
     * Evidence-based routing. It measures operational fit, not model intelligence: observed reliability
     * and latency are combined with provider-published pricing and declared context capacity.
     * Unknown measurements get a neutral prior rather than a fabricated benchmark.
     */
    private fun adaptiveOrder(
        candidates: List<Candidate>, profile: TaskProfile, taskRoute: Provider?, primary: Provider?, stats: ProviderStats
    ): Comparator<Candidate> {
        val measuredLatency = candidates.mapNotNull {
            stats.snapshot(it.provider).avgFirstTokenMs ?: stats.snapshot(it.provider).avgTotalMs
        }.sorted()
        val knownPrices = candidates.mapNotNull { it.info?.pricePerMillion }.sorted()
        val latencyBaseline = measuredLatency.getOrNull(measuredLatency.size / 2) ?: 2_500.0
        val priceBaseline = knownPrices.getOrNull(knownPrices.size / 2) ?: 1.0
        val weights = when (profile.type) {
            TaskType.COMMAND, TaskType.CHAT -> Triple(0.40, 0.45, 0.15)
            TaskType.CODE, TaskType.REASONING -> Triple(0.55, 0.25, 0.20)
            TaskType.LIVE_INFO -> Triple(0.40, 0.45, 0.15)
        }
        fun score(c: Candidate): Double {
            val snapshot = stats.snapshot(c.provider)
            val reliabilityPenalty = 1.0 - (snapshot.successRate ?: 0.85)
            val measured = snapshot.avgFirstTokenMs ?: snapshot.avgTotalMs
            val latencyPenalty = if (measured == null) 0.55 else (measured / (latencyBaseline * 2.0)).coerceIn(0.0, 1.5)
            val price = c.info?.pricePerMillion
            val costPenalty = when {
                c.declaredFree || c.info?.isFree == true -> 0.0
                price == null -> 0.55
                priceBaseline <= 0.0 -> if (price <= 0.0) 0.0 else 0.75
                else -> (price / (priceBaseline * 2.0)).coerceIn(0.0, 1.5)
            }
            val contextPenalty = c.info?.contextLength?.let { capacity ->
                val ratio = profile.approxTokens.toDouble() / capacity.coerceAtLeast(1)
                if (ratio > 0.75) (ratio - 0.75) * 2.0 else 0.0
            } ?: 0.0
            val routeBonus = if (c.provider == taskRoute) -0.12 else 0.0
            val primaryBonus = if (c.provider == primary) -0.04 else 0.0
            return reliabilityPenalty * weights.first + latencyPenalty * weights.second +
                costPenalty * weights.third + contextPenalty + routeBonus + primaryBonus
        }
        return compareBy<Candidate> { score(it) }.thenBy { it.provider.ordinal }
    }
}
