package app.xion.data

import android.content.Context
import app.xion.security.Json

/** Small encrypted, bounded memory of completed analysis tasks. No API keys or chat transcript are stored. */
data class TaskCapsule(
    val id: Long,
    val goal: String,
    val summary: String,
    val completedSteps: Int,
    val totalSteps: Int,
    val complete: Boolean,
    val createdAt: Long
)

class TaskCapsuleStore(context: Context) {
    private val secure = SecureStore(context.applicationContext)

    @Synchronized fun all(): List<TaskCapsule> {
        val raw = secure.get(KEY)
        if (raw.isBlank()) return emptyList()
        val root = Json.parseObject(raw, JsonLimits) ?: return emptyList()
        val entries = root["items"] as? List<*> ?: return emptyList()
        return entries.mapNotNull { item ->
            val m = item as? Map<*, *> ?: return@mapNotNull null
            val id = (m["id"] as? Number)?.toLong() ?: return@mapNotNull null
            val goal = (m["goal"] as? String)?.take(4000) ?: return@mapNotNull null
            val summary = (m["summary"] as? String)?.take(12000) ?: return@mapNotNull null
            TaskCapsule(id, goal, summary, (m["done"] as? Number)?.toInt() ?: 0,
                (m["total"] as? Number)?.toInt() ?: 0, m["complete"] == true,
                (m["created"] as? Number)?.toLong() ?: id)
        }.sortedByDescending { it.createdAt }.take(MAX_ITEMS)
    }

    @Synchronized fun save(capsule: TaskCapsule): Boolean {
        val items = (listOf(capsule) + all().filterNot { it.id == capsule.id }).take(MAX_ITEMS)
        val payload = mapOf("items" to items.map { c -> mapOf(
            "id" to c.id, "goal" to c.goal.take(4000), "summary" to c.summary.take(12000),
            "done" to c.completedSteps, "total" to c.totalSteps, "complete" to c.complete, "created" to c.createdAt
        ) })
        return secure.put(KEY, Json.stringify(payload))
    }

    @Synchronized fun delete(id: Long): Boolean = secure.put(KEY, Json.stringify(mapOf("items" to all().filterNot { it.id == id }.map { c ->
        mapOf("id" to c.id, "goal" to c.goal, "summary" to c.summary, "done" to c.completedSteps,
            "total" to c.totalSteps, "complete" to c.complete, "created" to c.createdAt)
    })))

    fun clear(): Boolean = secure.put(KEY, "")

    private companion object {
        const val KEY = "task_capsules_v1"
        const val MAX_ITEMS = 10
        val JsonLimits = app.xion.security.JsonLimits(160_000, 8, 64, 32)
    }
}
