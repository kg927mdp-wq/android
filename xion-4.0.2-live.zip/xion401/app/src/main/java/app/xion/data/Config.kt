package app.xion.data

import android.content.Context
import android.content.SharedPreferences
import app.xion.ai.orchestrator.Strategy
import app.xion.ai.orchestrator.TaskType
import app.xion.ai.provider.ModelInfo
import app.xion.ai.provider.Provider
import app.xion.security.Json

class Config(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    /** API keys and the search key live only here, encrypted with the Android Keystore. */
    private val secure = SecureStore(context)

    fun key(p: Provider): String = secure.get("key_" + p.name).trim()

    /** Returns false when the key could not be stored securely (nothing is written in that case). */
    fun setKey(p: Provider, v: String): Boolean = secure.put("key_" + p.name, v.trim())

    fun model(p: Provider): String {
        val m = (sp.getString("model_" + p.name, "") ?: "").trim()
        return if (m.isEmpty()) p.defaultModel else m
    }

    fun setModel(p: Provider, v: String) {
        sp.edit().putString("model_" + p.name, v.trim()).apply()
    }

    /** instant = stream the answer and fact-check in the background,
     *  careful = check before speaking, fast = stream with no check */
    var mode: String
        get() {
            val m = sp.getString("mode2", "instant") ?: "instant"
            return if (m == "careful" || m == "fast") m else "instant"
        }
        set(v) {
            sp.edit().putString("mode2", v).apply()
        }

    /** which provider answers first */
    var primary: String
        get() = sp.getString("primary", "DEEPSEEK") ?: "DEEPSEEK"
        set(v) {
            sp.edit().putString("primary", v).apply()
        }

    var searchEnabled: Boolean
        get() = sp.getBoolean("search", true)
        set(v) {
            sp.edit().putBoolean("search", v).apply()
        }

    /** optional Tavily key; empty = Tavily keyless mode */
    val tavilyKey: String
        get() = secure.get("tavily").trim()

    fun setTavilyKey(v: String): Boolean = secure.put("tavily", v.trim())

    /** speech recognition language, empty = device default */
    var lang: String
        get() = sp.getString("lang", "ar-IQ") ?: "ar-IQ"
        set(v) {
            sp.edit().putString("lang", v).apply()
        }

    var countryCode: String
        get() = sp.getString("country", "964") ?: "964"
        set(v) {
            sp.edit().putString("country", v.filter { it.isDigit() }).apply()
        }

    /** When on, a call starts immediately after the user approves it. Every call still needs approval. */
    var directCall: Boolean
        get() = sp.getBoolean("direct_call", false)
        set(v) {
            sp.edit().putBoolean("direct_call", v).apply()
        }

    // ------------------------------------------------------------------ routing and providers (Xion 3.0)

    /** How requests are routed between providers. */
    var strategy: Strategy
        get() = Strategy.values().firstOrNull { it.name == sp.getString("strategy", "AUTO") } ?: Strategy.AUTO
        set(v) {
            sp.edit().putString("strategy", v.name).apply()
        }

    /** Providers are on by default; switching one off keeps its key but Xion never calls it. */
    fun enabled(p: Provider): Boolean = sp.getBoolean("enabled_" + p.name, true)

    fun setEnabled(p: Provider, v: Boolean) {
        sp.edit().putBoolean("enabled_" + p.name, v).apply()
    }

    /** The user's own statement that a provider is on a free plan. Xion never assumes it. */
    fun declaredFree(p: Provider): Boolean = sp.getBoolean("free_" + p.name, false)

    fun setDeclaredFree(p: Provider, v: Boolean) {
        sp.edit().putBoolean("free_" + p.name, v).apply()
    }

    fun taskRoute(t: TaskType): Provider? = Provider.fromName(sp.getString("route_" + t.name, null))

    fun setTaskRoute(t: TaskType, p: Provider?) {
        sp.edit().putString("route_" + t.name, p?.name ?: "").apply()
    }

    /** In the text chat, also read answers aloud. Spoken questions are always answered aloud. */
    var speakReplies: Boolean
        get() = sp.getBoolean("speak_replies", false)
        set(v) {
            sp.edit().putBoolean("speak_replies", v).apply()
        }

    /** Keep a hands-free conversational session active after each spoken reply. */
    var continuousVoice: Boolean
        get() = sp.getBoolean("continuous_voice", false)
        set(v) {
            sp.edit().putBoolean("continuous_voice", v).apply()
        }

    /** Measured provider statistics (see ProviderStats), kept between launches. */
    var statsJson: String
        get() = sp.getString("stats", "") ?: ""
        set(v) {
            sp.edit().putString("stats", v).apply()
        }

    /** Privacy-preserving model flight trace; never contains prompts, completions, or credentials. */
    var flightJson: String
        get() = sp.getString("flight_trace", "") ?: ""
        set(v) { sp.edit().putString("flight_trace", v.take(48_000)).apply() }

    /** The last model list each provider returned, so the model screen works without a network call. */
    fun savedModels(p: Provider): List<ModelInfo> {
        val root = Json.parse(sp.getString("models_" + p.name, "[]") ?: "[]", Json.API) as? List<*> ?: return emptyList()
        return root.mapNotNull { o ->
            val m = o as? Map<*, *> ?: return@mapNotNull null
            val id = m["id"] as? String ?: return@mapNotNull null
            ModelInfo(
                id, m["n"] as? String, (m["c"] as? Long)?.toInt(),
                (m["pp"] as? Number)?.toDouble(), (m["cp"] as? Number)?.toDouble(),
                m["t"] as? Boolean, m["v"] as? Boolean, m["s"] as? Boolean
            )
        }
    }

    fun saveModels(p: Provider, list: List<ModelInfo>) {
        val out = list.take(1500).map {
            mapOf("id" to it.id, "n" to it.name, "c" to it.contextLength, "pp" to it.promptPrice, "cp" to it.completionPrice,
                "t" to it.supportsTools, "v" to it.supportsVision, "s" to it.supportsStructured)
        }
        sp.edit().putString("models_" + p.name, Json.stringify(out)).apply()
    }

    /** Gemini Live model id. Keep editable because Live model availability changes by account/region. */
    var geminiLiveModel: String
        get() = (sp.getString("gemini_live_model", "gemini-3.1-flash-live-preview") ?: "gemini-3.1-flash-live-preview").trim()
        set(v) { if (v.matches(Regex("[A-Za-z0-9._-]{3,120}"))) sp.edit().putString("gemini_live_model", v).apply() }

    fun hasKey(p: Provider): Boolean = key(p).isNotEmpty()

    fun anyKey(): Boolean = Provider.values().any { hasKey(it) }

    // ------------------------------------------------------------------ backup

    /** Complete portable settings snapshot. The caller must encrypt it with BackupCodec before saving/sharing. */
    fun exportJson(): String {
        val keys = LinkedHashMap<String, Any?>()
        val models = LinkedHashMap<String, Any?>()
        val enabled = LinkedHashMap<String, Any?>()
        val free = LinkedHashMap<String, Any?>()
        val routes = LinkedHashMap<String, Any?>()
        for (p in Provider.values()) {
            keys[p.name] = key(p)
            models[p.name] = model(p)
            enabled[p.name] = enabled(p)
            free[p.name] = declaredFree(p)
        }
        for (t in TaskType.values()) routes[t.name] = taskRoute(t)?.name ?: ""
        return Json.stringify(
            mapOf(
                "v" to 2,
                "keys" to keys,
                "models" to models,
                "enabled" to enabled,
                "free" to free,
                "routes" to routes,
                "strategy" to strategy.name,
                "tavily" to tavilyKey,
                "mode" to mode,
                "primary" to primary,
                "search" to searchEnabled,
                "lang" to lang,
                "country" to countryCode,
                "directCall" to directCall,
                "speakReplies" to speakReplies,
                "continuousVoice" to continuousVoice,
                "geminiLiveModel" to geminiLiveModel
            )
        )
    }

    /** Restores both legacy v1 and complete v2 backups. Returns false if any secret could not be stored. */
    fun importJson(text: String): Boolean {
        val m = Json.parseObject(text) ?: return false
        val version = (m["v"] as? Number)?.toInt() ?: return false
        if (version !in 1..2) return false
        @Suppress("UNCHECKED_CAST")
        val keys = m["keys"] as? Map<String, Any?> ?: return false
        @Suppress("UNCHECKED_CAST")
        val models = m["models"] as? Map<String, Any?> ?: emptyMap()
        var ok = true
        for (p in Provider.values()) {
            val k = (keys[p.name] as? String)?.trim() ?: continue
            if (k.length > 500 || !setKey(p, k)) ok = false
            val mod = (models[p.name] as? String)?.trim() ?: ""
            if (mod.length in 1..120) setModel(p, mod)
        }
        (m["tavily"] as? String)?.let { if (it.length > 500 || !setTavilyKey(it)) ok = false }
        (m["mode"] as? String)?.let { if (it == "instant" || it == "careful" || it == "fast") mode = it }
        (m["primary"] as? String)?.let { n -> if (Provider.values().any { it.name == n }) primary = n }
        (m["search"] as? Boolean)?.let { searchEnabled = it }
        (m["lang"] as? String)?.let { if (it.length in 1..12) lang = it }
        (m["country"] as? String)?.let { if (it.length in 1..4 && it.all { ch -> ch.isDigit() }) countryCode = it }
        (m["directCall"] as? Boolean)?.let { directCall = it }
        (m["geminiLiveModel"] as? String)?.let { geminiLiveModel = it }

        if (version >= 2) {
            (m["strategy"] as? String)?.let { n ->
                Strategy.values().firstOrNull { it.name == n }?.let { strategy = it }
            }
            @Suppress("UNCHECKED_CAST")
            val enabledMap = m["enabled"] as? Map<String, Any?> ?: emptyMap()
            @Suppress("UNCHECKED_CAST")
            val freeMap = m["free"] as? Map<String, Any?> ?: emptyMap()
            for (p in Provider.values()) {
                (enabledMap[p.name] as? Boolean)?.let { setEnabled(p, it) }
                (freeMap[p.name] as? Boolean)?.let { setDeclaredFree(p, it) }
            }
            @Suppress("UNCHECKED_CAST")
            val routes = m["routes"] as? Map<String, Any?> ?: emptyMap()
            for (t in TaskType.values()) {
                val name = routes[t.name] as? String ?: continue
                setTaskRoute(t, Provider.fromName(name))
            }
            (m["speakReplies"] as? Boolean)?.let { speakReplies = it }
            (m["continuousVoice"] as? Boolean)?.let { continuousVoice = it }
        }
        return ok
    }

}

/** Lets the orchestrator read the user's setup from [Config]. */
class ConfigRouting(private val cfg: Config) : app.xion.ai.orchestrator.RoutingSettings {
    private var cacheProvider: Provider? = null
    private var cacheList: List<ModelInfo> = emptyList()

    override fun key(p: Provider) = cfg.key(p)
    override fun model(p: Provider) = cfg.model(p)
    override fun enabled(p: Provider) = cfg.enabled(p)
    override fun declaredFree(p: Provider) = cfg.declaredFree(p)
    override var strategy: Strategy
        get() = cfg.strategy
        set(v) {
            cfg.strategy = v
        }
    override val primary: Provider?
        get() = Provider.fromName(cfg.primary)

    override fun taskRoute(t: TaskType) = cfg.taskRoute(t)

    @Synchronized
    override fun modelInfo(p: Provider, model: String): ModelInfo? {
        if (cacheProvider != p) {
            cacheList = cfg.savedModels(p)
            cacheProvider = p
        }
        return cacheList.firstOrNull { it.id == model }
    }

    /** Forget the cached list after a new discovery. */
    @Synchronized
    fun invalidate() {
        cacheProvider = null
    }
}
