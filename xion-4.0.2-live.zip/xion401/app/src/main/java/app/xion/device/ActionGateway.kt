package app.xion.device

import android.content.Context
import app.xion.security.Action
import app.xion.security.ActionPolicy
import app.xion.security.AuditLog
import app.xion.security.Decision
import java.io.File

/**
 * The security boundary between the AI reasoning layer and the device.
 * A model can only hand over a proposal (plain data). Nothing reaches [DeviceActions] unless it passed
 * [ActionPolicy] here, and everything that happens (or is refused) is written to the audit log.
 * Create one gateway per user turn: the policy counts actions per turn.
 */
class ActionGateway(private val ctx: Context, private val audit: AuditLog = auditFor(ctx)) {

    private val policy = ActionPolicy()
    private val authorization = ActionAuthorization()

    fun propose(raw: Map<String, Any?>, tainted: Boolean): Decision {
        val d = policy.evaluate(raw, tainted, DeviceActions.directCallArmed(ctx))
        authorization.register(d)
        when (d) {
            is Decision.Reject -> audit.record(d.type, AuditLog.REJECTED, d.reason)
            is Decision.Confirm -> audit.record(d.action.type, AuditLog.ASKED, d.action.auditNote())
            is Decision.Allow -> Unit
        }
        return d
    }

    /** Runs an action that was allowed, or that the user approved ([confirmed] = true). */
    fun execute(action: Action, confirmed: Boolean): ActionResult {
        if (!authorization.consume(action, confirmed)) {
            audit.record(action.type, AuditLog.REJECTED, "execution without matching policy ticket")
            return ActionResult(false, "هذا الإجراء لم يحصل على تصريح صالح.", false)
        }
        val direct = action is Action.Call && DeviceActions.directCallArmed(ctx)
        val r = DeviceActions.run(ctx, action, direct)
        val outcome = when {
            !r.ok -> AuditLog.FAILED
            confirmed -> AuditLog.CONFIRMED
            else -> AuditLog.EXECUTED
        }
        audit.record(action.type, outcome, action.auditNote() + if (!r.ok) " | " + r.message else "")
        return r
    }

    fun deny(action: Action) {
        authorization.deny(action)
        audit.record(action.type, AuditLog.DENIED, action.auditNote())
    }

    companion object {
        fun auditFor(ctx: Context): AuditLog =
            AuditLog(File(ctx.applicationContext.filesDir, "audit.log"))
    }
}
