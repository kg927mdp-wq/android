package app.xion.ui.compose

import java.io.File
import android.Manifest
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import app.xion.data.Config
import app.xion.voice.live.GeminiLiveSession
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.ui.window.Dialog
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executor
import kotlin.coroutines.resume

/** Foreground-only camera session; uses 1 FPS for Gemini Live and 8-second samples for fallback vision. */
@Composable
fun LiveCameraDialog(c: app.xion.ui.ChatController, onDismiss: () -> Unit, onFrame: suspend (ByteArray) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var previewView by remember { mutableStateOf<PreviewView?>(null) }
    var capture by remember { mutableStateOf<ImageCapture?>(null) }
    var ready by remember { mutableStateOf(false) }
    var observing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("جارٍ تشغيل الكاميرا…") }
    val liveConnected = c.liveReady.value
    val shownStatus = if (c.liveOn.value) (c.liveStatus.value ?: status) else status
    val executor = remember(context) { ContextCompat.getMainExecutor(context) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                observing = false
                status = "توقفت المشاهدة عند انتقال التطبيق للخلفية."
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    DisposableEffect(context, lifecycleOwner, previewView) {
        val view = previewView
        if (view == null) return@DisposableEffect onDispose { }
        val providerFuture = ProcessCameraProvider.getInstance(context)
        val listener = Runnable {
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder().setTargetResolution(Size(1280, 720)).build().also { it.setSurfaceProvider(view.surfaceProvider) }
                val imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).setTargetResolution(Size(1280, 720)).build()
                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                capture = imageCapture
                ready = true
                status = "الكاميرا جاهزة · فعّل Gemini Live للفيديو المستمر"
            } catch (e: Exception) { status = "تعذر تشغيل الكاميرا: ${e.message ?: "خطأ"}" }
        }
        providerFuture.addListener(listener, executor)
        onDispose {
            observing = false
            try { if (providerFuture.isDone) providerFuture.get().unbindAll() } catch (_: Exception) { }
            capture = null
        }
    }

    LaunchedEffect(observing, capture) {
        val activeCapture = capture
        if (observing && activeCapture != null) {
            while (observing) {
                val bytes = captureJpeg(context, activeCapture, executor)
                if (bytes != null) {
                    if (c.liveReady.value) {
                        if (!c.sendLiveVideo(bytes)) status = "تعذر إرسال إطار الفيديو إلى Gemini Live."
                        delay(1_000)
                    } else {
                        status = "أحلّل الإطار الحالي…"
                        onFrame(bytes)
                        status = "المشاهدة تعمل · فعّل Gemini Live للصوت والفيديو المتزامنين"
                        delay(8_000)
                    }
                } else {
                    status = "تعذر التقاط الإطار؛ سأحاول مجدداً."
                    delay(1_000)
                }
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Glass(Modifier.fillMaxWidth(), 22.dp, strong = true) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                XText("رؤية Xion المباشرة", 18, weight = androidx.compose.ui.text.font.FontWeight.Bold)
                AndroidView(
                    factory = { ctx -> PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER; previewView = this } },
                    modifier = Modifier.fillMaxWidth().height(300.dp)
                )
                XText(shownStatus, 12, X.cyan)
                XText(if (liveConnected) "جلسة Gemini Live: صوت ثنائي الاتجاه وفيديو مباشر حتى إطار واحد بالثانية." else "يمكنك تشغيل تحليل الإطارات المنفصل، أو ربط Gemini Live للصوت والفيديو المتزامنين.", 12, X.muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton(if (c.liveOn.value) "إيقاف Gemini Live" else "تشغيل Gemini Live", Modifier.weight(1f), accent = true, enabled = true) {
                        if (c.liveOn.value) { c.stopLive(); status = "تم إيقاف Gemini Live" } else c.startLive()
                    }
                    GlassButton(if (observing) "إيقاف الكاميرا" else "بدء الكاميرا", Modifier.weight(1f), accent = !observing, enabled = ready) {
                        observing = !observing
                        status = if (observing) "المشاهدة تعمل…" else "المشاهدة متوقفة"
                    }
                }
                GlassButton("إغلاق", Modifier.fillMaxWidth(), onClick = onDismiss)
            }
        }
    }
}

private suspend fun captureJpeg(context: android.content.Context, capture: ImageCapture, executor: Executor): ByteArray? =
    suspendCancellableCoroutine { continuation ->
        val file = File.createTempFile("xion-frame-", ".jpg", context.cacheDir)
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(options, executor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                val bytes = try { file.readBytes() } catch (_: Exception) { null }
                file.delete()
                if (continuation.isActive) continuation.resume(bytes)
            }
            override fun onError(exception: ImageCaptureException) {
                file.delete()
                if (continuation.isActive) continuation.resume(null)
            }
        })
    }
