package app.xion.device

import app.xion.security.Action
import app.xion.security.Decision

/**
 * One-use execution tickets issued only by ActionPolicy decisions.
 * This prevents callers from constructing an Action and invoking execute(..., confirmed=true)
 * without a matching proposal and explicit confirmation.
 */
internal class ActionAuthorization {
    private val allowed = LinkedHashSet<Action>()
    private val pending = LinkedHashSet<Action>()

    @Synchronized
    fun register(decision: Decision) {
        when (decision) {
            is Decision.Allow -> allowed.add(decision.action)
            is Decision.Confirm -> pending.add(decision.action)
            is Decision.Reject -> Unit
        }
    }

    /** A confirmation ticket is consumed only by the matching user-approved action. */
    @Synchronized
    fun consume(action: Action, confirmed: Boolean): Boolean =
        if (confirmed) pending.remove(action) else allowed.remove(action)

    @Synchronized
    fun deny(action: Action) {
        pending.remove(action)
        allowed.remove(action)
    }
}
