package app.xion.ai.orchestrator

import app.xion.ai.provider.Provider
import org.junit.Assert.*
import org.junit.Test

class TaskWorkflowTest {
    @Test fun workflowPlansExecutesAndSynthesizesAcrossDistinctProviders() {
        val settings = FakeSettings().setup(Provider.DEEPSEEK, Provider.GEMINI, Provider.GROK, Provider.GROQ)
        settings.primary = Provider.DEEPSEEK
        val h = Harness(settings)
        h.a(Provider.DEEPSEEK).script.add(FakeAdapter.Act.Say(listOf("1. اجمع المتطلبات\n2. قيّم الخيارات")))
        h.a(Provider.GEMINI).script.add(FakeAdapter.Act.Say(listOf("المتطلبات واضحة")))
        h.a(Provider.GROK).script.add(FakeAdapter.Act.Say(listOf("الخيار الأول أنسب")))
        h.a(Provider.GROQ).script.add(FakeAdapter.Act.Say(listOf("الخلاصة النهائية")))

        val progress = arrayListOf<WorkflowStep>()
        val result = TaskWorkflow(h.orch).run("خطط لبناء نظام", onProgress = { progress.add(it) })!!
        assertEquals(2, result.steps.size)
        assertEquals(2, progress.size)
        assertEquals("الخلاصة النهائية", result.finalText)
        assertTrue(result.complete)
        assertEquals(Provider.DEEPSEEK, result.planner)
        assertEquals(Provider.GEMINI, result.steps[0].provider)
        assertEquals(Provider.GROK, result.steps[1].provider)
        assertEquals(Provider.GROQ, result.synthesisProvider)
    }

    @Test fun workflowReturnsPartialResultWhenOneStepCannotRun() {
        val settings = FakeSettings().setup(Provider.DEEPSEEK, Provider.GEMINI)
        settings.primary = Provider.DEEPSEEK
        val h = Harness(settings)
        h.a(Provider.DEEPSEEK).script.add(FakeAdapter.Act.Say(listOf("1. حلل المتطلبات\n2. قارن البدائل")))
        h.a(Provider.GEMINI).script.add(FakeAdapter.Act.Say(listOf("تحليل مكتمل")))
        // Planner and first step consume the only two providers; no independent model remains for step 2.
        val result = TaskWorkflow(h.orch).run("مهمة تحليلية")!!
        assertFalse(result.complete)
        assertEquals("تحليل مكتمل", result.steps[0].result)
        assertNotNull(result.steps[1].error)
        assertTrue(result.finalText.contains("تحليل مكتمل"))
    }

    @Test fun workflowHonorsCancellationBeforeAnyProviderCall() {
        val h = Harness(FakeSettings().setup(Provider.GROQ))
        assertNull(TaskWorkflow(h.orch).run("هدف", cancelled = { true }))
        assertEquals(0, h.a(Provider.GROQ).calls)
    }
}
