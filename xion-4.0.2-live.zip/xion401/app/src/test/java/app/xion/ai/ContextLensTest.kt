package app.xion.ai

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ContextLensTest {
    @Test fun preservesOlderContextAsClearlyLabelledExcerpts() {
        val result = ContextLens.fold("", "I am building Xion 4.0", "The router now uses measured latency.")
        assertTrue(result.contains("طلب سابق"))
        assertTrue(result.contains("مقتطف جواب"))
        assertTrue(ContextLens.systemContext(result)!!.contains("مقتطفة"))
    }

    @Test fun redactsApiKeyLikeTextAndBoundsMemory() {
        val secret = "sk-1234567890abcdefghijklmnop"
        var result = ""
        repeat(20) { result = ContextLens.fold(result, "سؤال $it $secret", "إجابة طويلة ".repeat(80)) }
        assertFalse(result.contains(secret))
        assertTrue(result.length <= 1800)
    }
}
