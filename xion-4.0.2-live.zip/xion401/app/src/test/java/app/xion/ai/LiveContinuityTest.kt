package app.xion.ai

import app.xion.ai.orchestrator.FakeAdapter
import app.xion.ai.orchestrator.FakeSettings
import app.xion.ai.orchestrator.Harness
import app.xion.ai.provider.Provider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.Executor

class LiveContinuityTest {
    private class Settings(override var mode: String = "fast", override var searchEnabled: Boolean = false) : EngineSettings
    private val direct = Executor { it.run() }

    private fun env(): Pair<ConversationEngine, Harness> {
        val fs = FakeSettings().setup(Provider.GROQ)
        fs.primary = Provider.GROQ
        val h = Harness(fs)
        return Pair(ConversationEngine(h.orch, Settings(), { "" }, direct, direct, { 7L }), h)
    }

    @Test fun liveExchangeAppearsOnScreenAndInTheNextTypedTurnsContext() {
        val (e, h) = env()
        e.recordLiveTurn("اسمي علي", "أهلاً علي")
        val m = e.snapshot().messages
        assertEquals(listOf(Role.USER, Role.ASSISTANT), m.map { it.role })
        assertEquals(listOf(Source.VOICE, Source.VOICE), m.map { it.source })
        assertEquals("Gemini Live", m[1].provider)

        h.a(Provider.GROQ).script.add(FakeAdapter.Act.Say(listOf("اسمك علي.")))
        e.submit("شنو اسمي", Source.TEXT)
        val sent = h.a(Provider.GROQ).allCalls[0]
        assertTrue(sent.any { it.role == "user" && it.content.contains("اسمي علي") })
        assertTrue(sent.any { it.role == "assistant" && it.content.contains("أهلاً علي") })
    }

    @Test fun typedTurnsAreAvailableToSeedTheLiveSession() {
        val (e, h) = env()
        h.a(Provider.GROQ).script.add(FakeAdapter.Act.Say(listOf("Noted.")))
        e.submit("remember 42", Source.TEXT)
        val turns = e.recentTurns(6)
        assertEquals(1, turns.size)
        assertEquals("remember 42", turns[0].first)
    }

    @Test fun emptyLiveExchangeIsIgnoredAndHistoryStaysBounded() {
        val (e, _) = env()
        e.recordLiveTurn("  ", "")
        assertTrue(e.snapshot().messages.isEmpty())
        repeat(40) { e.recordLiveTurn("q$it", "a$it") }
        assertTrue(e.recentTurns(100).size <= 12)
    }

    @Test fun clearForgetsLiveExchangesToo() {
        val (e, _) = env()
        e.recordLiveTurn("x", "y")
        e.clear()
        assertTrue(e.snapshot().messages.isEmpty() && e.recentTurns(6).isEmpty())
    }
}
