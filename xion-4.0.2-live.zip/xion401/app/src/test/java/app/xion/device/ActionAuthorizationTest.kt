package app.xion.device

import app.xion.security.Action
import app.xion.security.Decision
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ActionAuthorizationTest {
    @Test fun allowTicketCanBeUsedOnlyOnce() {
        val auth = ActionAuthorization()
        val action = Action.Flashlight(true)
        auth.register(Decision.Allow(action))
        assertTrue(auth.consume(action, confirmed = false))
        assertFalse(auth.consume(action, confirmed = false))
    }

    @Test fun confirmationTicketRequiresExplicitConfirmedFlag() {
        val auth = ActionAuthorization()
        val action = Action.Sms("12345", "hello")
        auth.register(Decision.Confirm(action, "external effect"))
        assertFalse(auth.consume(action, confirmed = false))
        assertTrue(auth.consume(action, confirmed = true))
        assertFalse(auth.consume(action, confirmed = true))
    }

    @Test fun cannotExecuteAnUnproposedAction() {
        val auth = ActionAuthorization()
        assertFalse(auth.consume(Action.Camera, confirmed = false))
        assertFalse(auth.consume(Action.Camera, confirmed = true))
    }

    @Test fun deniedActionCannotBeExecutedLater() {
        val auth = ActionAuthorization()
        val action = Action.OpenUrl("https://example.com")
        auth.register(Decision.Confirm(action, "tainted"))
        auth.deny(action)
        assertFalse(auth.consume(action, confirmed = true))
    }

    @Test fun rejectedDecisionNeverIssuesATicket() {
        val auth = ActionAuthorization()
        auth.register(Decision.Reject("shell", "not allowed"))
        assertFalse(auth.consume(Action.Camera, confirmed = false))
    }
}
