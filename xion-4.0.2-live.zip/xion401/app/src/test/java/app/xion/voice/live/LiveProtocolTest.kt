package app.xion.voice.live

import app.xion.security.ActionPolicy
import app.xion.security.Decision
import app.xion.security.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LiveProtocolTest {

    @Suppress("UNCHECKED_CAST")
    private fun obj(s: String) = Json.parseObject(s, Json.API)!!

    @Test fun setupDeclaresTheToolTranscriptionAndAudio() {
        val setup = obj(LiveProtocol.setup("some-model"))["setup"] as Map<String, Any?>
        assertEquals("models/some-model", setup["model"])
        assertEquals(listOf("AUDIO"), (setup["generationConfig"] as Map<*, *>)["responseModalities"])
        assertTrue(setup.containsKey("inputAudioTranscription") && setup.containsKey("outputAudioTranscription"))
        val decl = ((setup["tools"] as List<*>)[0] as Map<*, *>)["functionDeclarations"] as List<*>
        assertEquals("phone_action", (decl[0] as Map<*, *>)["name"])
    }

    @Test fun setupWithoutToolsHasNoToolsField() {
        assertFalse((obj(LiveProtocol.setup("m", withTools = false))["setup"] as Map<*, *>).containsKey("tools"))
    }

    @Test fun parsesEventsInHandlingOrder() {
        val raw = """{"serverContent":{"interrupted":true,"inputTranscription":{"text":"hi"},
            "modelTurn":{"parts":[{"inlineData":{"data":"QUJD"}}]},"outputTranscription":{"text":"hello"},"turnComplete":true}}"""
        val e = LiveProtocol.parse(raw)
        assertEquals(
            listOf(LiveEvent.Interrupted, LiveEvent.UserText("hi"), LiveEvent.Audio("QUJD"), LiveEvent.ModelText("hello"), LiveEvent.TurnComplete),
            e
        )
    }

    @Test fun parsesSetupGoAwayAndToolCancel() {
        assertEquals(listOf(LiveEvent.SetupComplete), LiveProtocol.parse("""{"setupComplete":{}}"""))
        assertEquals(listOf(LiveEvent.GoAway), LiveProtocol.parse("""{"goAway":{"timeLeft":"5s"}}"""))
        assertEquals(listOf(LiveEvent.ToolCancelled(listOf("a", "b"))), LiveProtocol.parse("""{"toolCallCancellation":{"ids":["a",3,"b"]}}"""))
    }

    @Test fun garbageIsIgnoredNotThrown() {
        assertTrue(LiveProtocol.parse("not json").isEmpty())
        assertTrue(LiveProtocol.parse("[]").isEmpty())
        assertTrue(LiveProtocol.parse("""{"serverContent":"x"}""").isEmpty())
        assertTrue(LiveProtocol.parse("""{"toolCall":{"functionCalls":[{"name":"x"},5]}}""").isEmpty())
    }

    @Test fun toolCallsAreCappedPerMessage() {
        val calls = (1..9).joinToString(",") { """{"id":"c$it","name":"phone_action","args":{"type":"camera"}}""" }
        val e = LiveProtocol.parse("""{"toolCall":{"functionCalls":[$calls]}}""")
        assertEquals(LiveProtocol.MAX_TOOL_CALLS_PER_MESSAGE, e.size)
    }

    @Test fun toolResponseCarriesIdNameAndOutcome() {
        val r = obj(LiveProtocol.toolResponse("c1", "phone_action", false, "refused"))
        val f = ((r["toolResponse"] as Map<*, *>)["functionResponses"] as List<*>)[0] as Map<*, *>
        assertEquals("c1", f["id"]); assertEquals("phone_action", f["name"])
        assertEquals(false, (f["response"] as Map<*, *>)["ok"])
    }

    @Test fun historyIsBoundedAndDropsActionLines() {
        val turns = (1..10).map { "question $it" to "answer $it @@ACT: {\"type\":\"call\",\"to\":\"x\"}\n" + "z".repeat(2000) }
        val h = obj(LiveProtocol.history(turns)!!)["clientContent"] as Map<*, *>
        val list = h["turns"] as List<*>
        assertEquals(LiveProtocol.MAX_HISTORY_TURNS * 2, list.size)
        assertEquals(false, h["turnComplete"])
        for (t in list) {
            val text = (((t as Map<*, *>)["parts"] as List<*>)[0] as Map<*, *>)["text"] as String
            assertTrue(text.length <= LiveProtocol.MAX_HISTORY_CHARS)
            assertFalse(text.contains("@@"))
        }
        assertNull(LiveProtocol.history(emptyList()))
    }

    // ---- exchange assembly

    @Test fun assemblerJoinsChunksAndFinishesOnTurnComplete() {
        val a = LiveTurnAssembler()
        assertNull(a.feed(LiveEvent.UserText("افتح ")))
        assertNull(a.feed(LiveEvent.UserText("الكاميرا")))
        assertNull(a.feed(LiveEvent.ModelText("حاضر ")))
        assertNull(a.feed(LiveEvent.ModelText("أفتحها.")))
        val t = a.feed(LiveEvent.TurnComplete)!!
        assertEquals("افتح الكاميرا", t.user); assertEquals("حاضر أفتحها.", t.model); assertFalse(t.interrupted)
        assertNull(a.feed(LiveEvent.TurnComplete))
    }

    @Test fun assemblerKeepsWhatWasSaidWhenInterrupted() {
        val a = LiveTurnAssembler()
        a.feed(LiveEvent.UserText("question"))
        a.feed(LiveEvent.ModelText("half an ans"))
        val t = a.feed(LiveEvent.Interrupted)!!
        assertEquals("half an ans", t.model); assertTrue(t.interrupted)
    }

    @Test fun userSpeakingAgainClosesTheOldExchange() {
        val a = LiveTurnAssembler()
        a.feed(LiveEvent.UserText("one")); a.feed(LiveEvent.ModelText("reply one"))
        val old = a.feed(LiveEvent.UserText("two"))!!
        assertEquals("one", old.user); assertEquals("reply one", old.model)
        assertEquals("two", a.flush()!!.user)
    }

    @Test fun assemblerBuffersAreBounded() {
        val a = LiveTurnAssembler()
        repeat(100) { a.feed(LiveEvent.ModelText("x".repeat(500))) }
        assertTrue(a.flush()!!.model.length <= 4000)
    }

    // ---- the security boundary: what the model asks for is only ever a proposal for the policy

    private fun decide(args: String): Decision {
        val call = LiveProtocol.parse("""{"toolCall":{"functionCalls":[{"id":"1","name":"phone_action","args":$args}]}}""")
            .single() as LiveEvent.ToolCall
        return ActionPolicy().evaluate(call.args, tainted = false, directCallArmed = false)
    }

    @Test fun validToolCallPassesThroughThePolicy() {
        assertTrue(decide("""{"type":"alarm","hour":7,"minute":30}""") is Decision.Allow)
    }

    @Test fun unknownOrMalformedToolCallsAreRejected() {
        assertTrue(decide("""{"type":"delete_everything"}""") is Decision.Reject)
        assertTrue(decide("""{"hour":7}""") is Decision.Reject)
        assertTrue(decide("""{"type":"call","to":"x; rm -rf"}""") is Decision.Reject)
        assertTrue(decide("""{"type":"alarm","hour":99}""") is Decision.Reject)
        assertTrue(decide("""{"type":"open_url","url":"javascript:alert(1)"}""") is Decision.Reject)
    }

    @Test fun policyStillCapsActionsPerTurnForLiveCalls() {
        val policy = ActionPolicy()
        val results = (1..6).map {
            val c = LiveProtocol.parse("""{"toolCall":{"functionCalls":[{"id":"$it","name":"phone_action","args":{"type":"flashlight","on":true}}]}}""").single() as LiveEvent.ToolCall
            policy.evaluate(c.args, false, false)
        }
        assertTrue(results.drop(ActionPolicy.MAX_PER_TURN).all { it is Decision.Reject })
    }
}
