# Xion 4.0.0

Xion is an Android assistant built around a provider-agnostic conversation engine, explicit routing policy, encrypted local task memory, and a permission-gated device-action gateway.

## 4.0 highlights

- Adaptive provider routing based on measured reliability and latency, provider-reported pricing, model context capacity, task category, and user-selected task routes.
- Extractive Context Lens that retains bounded, redacted excerpts from older turns while keeping recent conversation turns verbatim.
- User-invoked Model Council: one draft, up to two independent provider reviews, and a distinct synthesis provider when available.
- Task workflows preserve completed results in an encrypted Task Capsule when cancelled; later steps receive bounded evidence from earlier steps.
- Privacy-preserving Model Flight Recorder exposes recent provider/model/task/latency/outcome metadata without retaining prompt or response text.
- Existing text/voice shared conversation path and policy-gated Android actions are retained.

## Important capability boundary

Xion 4.0 does **not** yet provide Gemini Live parity. Its current voice path is turn-based speech recognition and text-to-speech, not a continuous bidirectional audio/video stream. A production realtime implementation needs a streaming transport, explicit lifecycle and interruption handling, audio chunk processing, permission-gated visual input, and short-lived credentials. See `docs/COMPETITIVE-BENCHMARK.md` and `docs/VOICE-ROADMAP.md`.

## Build

Open the `xion` directory in Android Studio and let Gradle sync. The project targets Android SDK 34 and Java 17. A complete Android build requires the Android SDK and dependency repositories available in Android Studio.

## Security principles

- API keys remain in the app's encrypted secure store; never commit real keys.
- Device actions pass through the policy/authorization gateway.
- Consequential actions require explicit user confirmation.
- Task Capsules contain bounded summaries, not API keys or full transcripts.


## Camera and voice status

The chat composer includes an explicit camera-session action. After camera permission and the user presses Start, Xion shows a foreground preview and samples one still frame every 8 seconds for analysis by the selected vision-capable OpenAI-compatible model. Sampling stops when the dialog closes or the app leaves the foreground; frames are not saved by this feature. This is periodic frame sampling, not continuous video-token streaming. Voice uses Android SpeechRecognizer and TextToSpeech with hands-free turn-taking and interruption by tapping the mic; it is not full-duplex realtime audio and does not claim Gemini Live parity.


### 4.0.0 integration note
The camera dialog now awaits each frame's vision result before beginning the next sample cycle. The multi-provider workflow supports up to six specialist analysis steps. Voice remains SpeechRecognizer + TextToSpeech turn-taking; native full-duplex provider audio is not included in this source handoff. See `docs/RELEASE-STATUS.md` and `docs/KNOWN-LIMITATIONS.md` for exact boundaries.


## Gemini Live

See [GEMINI-LIVE.md](docs/GEMINI-LIVE.md) for the native bidirectional audio/video session, setup, credential-security notes, and verification status.
