# Model Council (3.2.5)

`Orchestrator.council(messages, profile, reviewers)` is an explicit opt-in workflow for tasks where a second opinion is worth the extra provider calls.

1. The normal router selects a provider to create the draft.
2. Up to three reviewers are selected from different providers. Each receives the original conversation, the draft, and a request to identify factual errors, unsupported assumptions, and corrections.
3. If at least one review succeeds and another unused provider is available, a distinct provider synthesizes the final response.
4. `CouncilResult.finalText` returns the synthesis when available, otherwise the original draft. `reviews` and `synthesis` expose provenance to a future UI.

The workflow is sequential, not speculative or parallel. It never calls the same provider twice in one council run. It does not silently activate for normal chat, because it can consume substantially more tokens. With one configured provider, the draft is returned and no review is claimed.

## UI integration still required

The current chat screen does not yet expose a council toggle or show per-model review provenance. Do not describe the council as a user-facing feature until that UI is implemented and tested.
