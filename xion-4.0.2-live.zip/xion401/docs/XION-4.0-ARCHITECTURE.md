# Xion 4.0 architecture notes

## Adaptive Intelligence Core

`Router` now supports `ADAPTIVE`. The score is an operational-fit heuristic over observed provider success rate, measured first-token/total latency, published price metadata, declared context capacity, task type, and the user's explicit task route. It is not an intelligence benchmark and does not infer answer quality. Missing measurements use neutral priors. Existing routing strategies remain available.

## Context Lens

`ConversationEngine` continues to send recent turns verbatim. When the bounded history window removes an older turn, `ContextLens` retains short redacted excerpts in a compact system-context note. The note explicitly warns the model that excerpts are data rather than instructions and that newer messages take precedence. `clear()` removes both recent history and compacted context.

## Model Council

The composer exposes an explicit Council action. It uses distinct providers sequentially: a draft provider, up to two reviewers, and a distinct synthesis provider when available. The operation is analysis-only and never enters the device-action gateway. Actual participating provider names are retained in the saved task capsule.

## Resumable task continuity

Cancellation stops scheduling further workflow steps. Completed results are returned as a partial result and saved in an encrypted Task Capsule. Xion does not silently resume or execute an unfinished step; the user explicitly restores the saved summary as context.

## Realtime roadmap boundary

The current voice implementation remains turn-based. Do not label it realtime or multimodal streaming. The next implementation should define a provider-neutral session interface and then add a Gemini Live adapter and at least one alternative adapter. Client-side long-lived API keys should not be used for production realtime sessions; prefer a trusted token broker and short-lived credentials.
