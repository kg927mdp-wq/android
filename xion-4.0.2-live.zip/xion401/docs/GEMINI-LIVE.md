# Gemini Live audio and video

Xion includes a native Android WebSocket transport for Gemini Live. It uses the documented Live API protocol:

- Microphone input: mono PCM16, 16 kHz, sent as `realtimeInput.audio`.
- Model output: mono PCM16, 24 kHz, played through `AudioTrack`.
- Interruption: server `serverContent.interrupted` flushes queued playback so user barge-in is respected.
- Vision: JPEG frames are sent as `realtimeInput.video` to the same stateful session, at a maximum target rate of one frame per second.
- Text can be sent to the same session through `sendText`.
- The camera/audio session is explicitly user-started and closed when the dialog is dismissed or the app goes to the background.

## Setup

1. Add a Gemini API key in Xion's existing Gemini provider settings.
2. Open the camera dialog, grant microphone permission, and start Gemini Live.
3. Start the camera stream separately. The same live session then receives both microphone audio and JPEG frames.
4. Stop the live session or close the dialog to release microphone, playback, and socket resources.

The Live model is configurable through `Config.geminiLiveModel`; its default is `gemini-3.1-flash-live-preview`. Model access is controlled by Google and can vary by account, region, and availability. A failed model handshake is surfaced in the dialog rather than silently falling back.

## Credential security

The existing Gemini key is stored using Xion's encrypted secure store. The direct WebSocket API requires the key in the connection query string. Google recommends short-lived ephemeral tokens for production client-to-server apps; Xion's present direct-client implementation does not include a token-issuing backend. Do not distribute a personal APK containing a personal API key. A production release should add a trusted backend that issues short-lived Live tokens.

## Multi-agent workflow

The task workflow remains bounded and user-initiated: one planner, up to six specialist analysis agents routed across distinct configured providers where available, then a synthesis agent. It records per-step provider/results and supports cancellation. It does not autonomously execute device actions or external side effects; device actions continue through Xion's separate authorization gateway and confirmation policy.

## Verification status

Source-level integration is present. This workspace has no Android SDK/Gradle wrapper installation, so a full Android build, hardware microphone/speaker test, API handshake, and device camera test have not been performed here. Those are release gates, not claimed successes.
