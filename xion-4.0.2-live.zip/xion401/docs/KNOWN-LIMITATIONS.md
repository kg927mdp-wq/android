# Known limitations — Xion 4.0.0 source handoff

This archive is a source release candidate, not a verified production APK. Do not treat a feature brief, prompt instruction, or roadmap item as an implemented capability.

## Build and verification
- Android/Compose sources have not been compiled with the Android Gradle Plugin in this environment; no APK or AAB was produced here.
- No emulator or physical-device run was available. Microphone, TTS, launcher icon rendering, Android Keystore, R8, and device actions still require device verification.
- The archive does not include a Gradle wrapper. Open the `xion` directory in Android Studio or generate a wrapper using a compatible Gradle 8.x installation.

## Voice and visual context
- Current voice mode uses Android `SpeechRecognizer` plus Android `TextToSpeech`, with optional continuous turn-taking. It is not full-duplex neural realtime audio and does not yet match Gemini Live's native streaming/interruption experience.
- Acoustic barge-in detection is not implemented. The user can stop the current audio session using the UI control.
- Gemini Live uses a direct WebSocket with the user's own encrypted Gemini key (sent as a `?key=` query parameter). No ephemeral-token backend is included; a shared/production build should add one. Live message field names follow Google's documented protocol as known during development and have not been checked against a live server.
- Camera support is foreground preview plus sequential still-frame sampling every 8 seconds. It is not continuous video transport, and Android MediaProjection screen sharing is not implemented.

## Advanced intelligence features
- The Task Workflow is sequential model-assisted analysis of up to six steps, not autonomous agents. It cannot use tools, browse independently, create files, or perform external side effects. Specialist roles are prompt-level reasoning guidance; no autonomous multi-agent workbench is implemented.
- Task Capsule, Context Lens and Model Flight Recorder are implemented (see their docs); Personal Command Studio is not. The Model Council has a UI control ("مجلس").
- Provider routing, measured statistics, and task-specific provider preferences are configurable. Task preferences still depend on the selected provider being enabled, configured with a valid key, and having an available model.
- Search is a provider-backed feature; it is not guaranteed to work without valid provider/search configuration and network access.

## Providers
- Provider adapters and model availability depend on each provider's current API, account, region, and key. Free-tier status, quotas, and prices are not guaranteed by Xion.
- Some provider integrations listed in the UI are OpenAI-compatible adapters; native-only APIs are not implemented. See `PROVIDERS.md`.

## UI and accessibility
- The glass effect is translucent layered drawing, not a true backdrop blur.
- Some advanced backup/settings flows still open the legacy Views activity.
- Dynamic type, TalkBack semantics, and small-screen layouts need a dedicated accessibility/device pass.

### 3.2.3 backup compatibility
The encrypted settings export now writes payload version 2 and includes provider routing and voice preferences. The importer still accepts payload version 1. Provider model-discovery metadata and measured latency statistics are intentionally not included; they can be refreshed locally and are not required to restore a working configuration.

## Task Workflow (3.2.6)
- The workflow control appears for drafts of at least 12 characters and may make several sequential model requests, consuming additional quota.
- It requires multiple configured providers to complete all stages; with insufficient provider capacity it returns a partial result. Cancellation is checked between calls and cannot forcibly interrupt an in-flight provider HTTP request.

## Task Capsules (3.3.0)
- Task Capsules retain up to ten encrypted workflow summaries on-device. They restore as context notes only; they do not resume an interrupted workflow or perform background execution.
- Android Keystore persistence, deletion behavior, and migration from existing installs require device verification.

## Xion Live (4.0.2)
- Phone actions asked for by the live model go through the same policy gateway, approvals and audit log as the text path, but **approval in Live mode is by on-screen button only** (the live microphone audio goes to Gemini, so Xion has no local, checkable transcript to confirm a sensitive action by voice).
- A pending approval times out after 60 seconds and is denied.
- Live runs as its own session; typing a message ends the Live session and continues the same conversation as text. Earlier turns are sent to Live once at connection (best effort, unverified against the real server), and Live exchanges are written back into the shared conversation from the transcripts Gemini returns.
- Live stops when the app goes to the background. Reconnect is manual: after an unexpected stop Xion falls back to the ordinary voice/text path and says so.
- Nothing in Live has been run against the real service, a microphone or a speaker in this environment.
