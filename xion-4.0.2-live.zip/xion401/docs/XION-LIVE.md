# Xion Live (4.0.2)

Xion Live is Xion's layer on top of Gemini Live. The voice, language understanding and speech quality come from Gemini; Xion adds
conversation continuity, gated phone control, and graceful fallback. It does **not** claim to beat Gemini Live at voice quality.

## What Xion adds
1. **Shared conversation.** Exchanges (from Gemini's input/output transcripts) are written into the same engine as typed and
   spoken turns (`ConversationEngine.recordLiveTurn`). Recent turns are sent to Live at connection. Typing ends Live and continues in text.
2. **Gated phone actions.** One tool, `phone_action`, with the same fields as the text path. Every call is untrusted data and goes through
   `ActionGateway.propose` -> `ActionPolicy` -> approval card -> `DeviceActions` -> audit log. Per-turn limit, duplicate guard and
   validation apply unchanged. Approval is by button; unanswered approvals are denied after 60 s. The model is told the real outcome (`ok` true/false) and
   is instructed never to claim success before it.
3. **Fallback.** Connection failure/close -> Live is stopped, the reason (passed through `Redactor`) is shown, and the normal mic/text path continues.
4. **Safer errors.** All Live error text is redacted; the key is only in the socket URL and never logged.

## Code map
- `voice/live/LiveProtocol.kt` - pure message building/parsing, tool declaration, `LiveTurnAssembler` (unit tested)
- `voice/live/GeminiLiveSession.kt` - audio capture/playback and the WebSocket (Android, not unit tested)
- `ui/ChatController.kt` - `startLive/stopLive`, `onLiveTool`, approval wiring
- `ui/compose/ChatScreen.kt` - "Live" button and mode chip; `LiveCameraDialog` shares the same session for video frames

## Verification status
Unit tests (JVM, pure layer): protocol, assembler, policy-through-protocol, shared-context. Not verified: real Gemini handshake, field names against the live
server, audio hardware, camera, Compose UI, Android build.
