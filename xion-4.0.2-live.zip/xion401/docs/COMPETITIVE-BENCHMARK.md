# Xion 4.0 — Competitive engineering benchmark

This is a capability-gap benchmark, not a claim that Xion is already superior to another product.

| Capability | Gemini Live documented capability | Xion 4.0 status / product direction |
|---|---|---|
| Bidirectional real-time audio | Native low-latency audio input/output over a stateful streaming session | Existing voice path is turn-based speech recognition + TTS; a true streaming session transport is not yet integrated. |
| Video and image context | Live API accepts image/video frames alongside audio/text | No continuous camera/video pipeline is integrated yet. |
| Barge-in / interruption | Voice activity detection can interrupt generation | Xion supports turn interruption at the conversation-engine level; streaming audio barge-in is not yet equivalent. |
| Tool use | Live API supports function calling | Xion has a separate policy-gated Android action gateway; this separation is a deliberate safety boundary. |
| Provider choice | Gemini Live is a Google model/API path | Xion's differentiator is provider-agnostic routing across configured services, with measured health/latency and transparent user-selected routes. |
| Cross-model review | Not the core Live interaction primitive | Xion has an opt-in sequential model council and bounded multi-provider task workflow. |
| Cost/health awareness | Provider/API-specific usage metadata | Xion combines observed reliability, latency, provider-published price, and context fit for adaptive routing. |
| Task continuity | Session context is retained within API session limits | Xion stores bounded encrypted task capsules and now preserves completed work when a workflow is cancelled. |

## What Xion should build next

1. A provider-neutral realtime session interface with explicit lifecycle states, audio chunk queues, transcript events, cancellation, and back-pressure.
2. Gemini Live adapter using short-lived credentials rather than shipping long-lived provider secrets in the Android client.
3. OpenAI Realtime or another documented realtime adapter behind the same interface, so provider choice is not coupled to UI.
4. A permission-gated visual context pipeline: user-triggered still images first, then explicit opt-in video frames.
5. Latency and interruption benchmarks measured on real devices and networks.

## Reference benchmark sources

- Google Gemini Live API overview: https://ai.google.dev/gemini-api/docs/live-api
- Google Live API capabilities guide: https://ai.google.dev/gemini-api/docs/live-api/capabilities

The Google documentation describes low-latency bidirectional audio/vision, tool use, transcription, VAD/barge-in, and streaming session behavior. These are the reference capabilities Xion must match before claiming realtime parity.
