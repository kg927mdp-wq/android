# Task Capsules — 3.3.0

Task Capsules are encrypted local summaries of explicit multi-provider workflows.

## Stored fields
- User's task goal (maximum 4,000 characters)
- Final workflow summary (maximum 12,000 characters)
- Completed/total step counts and completion flag
- Creation timestamp

The store retains at most ten capsules. It uses the same Android Keystore-backed AES-GCM `SecureStore` as provider secrets. If encryption/decryption fails, the feature does not fall back to plaintext. No provider keys, full chat transcript, or device-action authorization tickets are stored.

## User controls
- The latest capsule is shown in the chat screen.
- **Restore context** appends the saved goal and summary to the current conversation context. It does not silently call a provider, resume a workflow, or execute a device action.
- **Delete** removes the selected capsule.
- Clearing the chat does not delete capsules; they are separate saved task records.

## Scope
This is persistent task memory, not autonomous background execution. It does not monitor tasks or run while the app is closed.
