# Xion 4.0.0 — unified project handoff

## Included in this project
- Android app module with the shared text/voice conversation path, provider adapters, model discovery, adaptive routing, and encrypted API-key storage.
- User-invoked Model Council: one draft, up to two independent reviews, and a distinct synthesis provider when available.
- Bounded sequential Task Workflow. Each step receives prior-step evidence; completed results can be saved as an encrypted Task Capsule if the workflow is stopped.
- Encrypted local Task Capsules with explicit restore-context and delete controls.
- Context Lens: bounded, redacted excerpts from older turns, labelled as historical context rather than instructions.
- Privacy-preserving Model Flight Recorder: provider, model, task class, elapsed time, outcome, estimated token counts, and error category only. It never stores prompts, answers, or credentials. Recent trace is bounded and user-clearable.
- Device action whitelist, fresh one-use authorization, explicit confirmation for consequential actions, and audit logging.
- Adaptive launcher icon, vector UI glyphs, Arabic-first glass UI, typed input and speech input/output.
- Foreground camera preview with an explicit start/stop control. While enabled, Xion samples a still frame every 8 seconds and awaits each vision analysis before sampling the next frame, preventing overlapping requests and dropped frames due to an in-flight camera analysis. Frames are sent to the selected OpenAI-compatible vision model and are not saved by this feature. Sampling stops when the dialog closes or the app leaves the foreground.
- Multi-provider Task Workflow expanded to as many as six sequential specialist analysis steps. Each step receives bounded prior evidence and a role-specific review lens; a final synthesis stage consolidates results and reports gaps. This is orchestrated model reasoning, not autonomous tool-using agents.

## Deliberately not claimed as implemented
- Gemini Live-grade full-duplex realtime audio, simultaneous microphone capture/playback, natural acoustic barge-in, or provider-native audio streaming. Current voice remains turn-based SpeechRecognizer + TextToSpeech with hands-free turn-taking.
- Native continuous video-token streaming into a realtime multimodal session. The camera feature is periodic frame sampling (one still frame every 8 seconds), not a continuous video stream. Screen sharing is not implemented.
- Independent background agents with tool execution, cross-app automation, or durable autonomous task execution. Specialist lenses are bounded prompt roles, not independent agent processes.
- Cross-device synchronized memory or an editable persistent personal-preference memory system. Existing encrypted Task Capsules store only explicit workflow summaries.

## Handoff state
This is a source project intended for Android Studio import and user-side testing. Build and device verification are intentionally left to the project owner in Android Studio. Do not describe this ZIP as a verified APK or production release until those checks pass.

## Build requirements
- Android Studio with Android Gradle Plugin 8.5.2 support
- JDK 17
- Android SDK 34
- Network access to Google Maven and Maven Central during Gradle sync
- User-supplied provider API keys for live model calls

## Release precautions
- Keep real API keys out of source control and screenshots.
- Export an encrypted settings backup before reinstalling or changing application signing identity.
- The debug build uses Android's generated debug keystore. A Play/release build still needs the owner's own release keystore and signing configuration.
- Review all requested Android permissions on the target device. Voice input is optional; text chat remains available without microphone permission.


## 4.0.1 source update — Gemini Live integration

- Native Gemini Live WebSocket transport has been added for bidirectional PCM audio, barge-in playback interruption, text, and JPEG video frames.
- Live camera dialog can send video into the same audio session, targeting no more than 1 FPS. The previous periodic vision path remains as fallback when Live is not connected.
- The existing multi-agent workflow is a bounded planner → specialist agents → synthesis pipeline using distinct configured providers where possible. It is analysis/orchestration only; it does not autonomously execute device actions.
- Android build, real API handshake, audio hardware, and camera hardware remain unverified in this environment. Do not mark this source as a signed production APK.


## 4.0.2 source update
Xion Live layer added (see XION-LIVE.md). Same rule as before: unverified on device; not an APK.
