# Xion Intelligence Upgrade — product and implementation brief

This update strengthens the shared model instructions and establishes the next product architecture. It does **not** claim that the APK already has Gemini Live parity. The current voice stack uses Android SpeechRecognizer + TextToSpeech; true low-latency full-duplex audio requires the separate realtime transport described below.

## 1. Live conversation target

### User experience
- One persistent voice session with natural turn-taking.
- Barge-in: user speech immediately cancels queued speech and the current response.
- Streaming input transcription and streaming audio output, with synchronized transcript state.
- Low-latency partial responses, interruption recovery, reconnect handling, and visible session state.
- Optional camera frame sharing and explicit screen sharing, each started by a clear user action and stopped visibly.
- Seamless switch between voice and typing without losing the active conversation.

### Required architecture
1. `RealtimeSession`: lifecycle state machine (`IDLE`, `CONNECTING`, `LISTENING`, `THINKING`, `SPEAKING`, `RECONNECTING`, `CLOSED`).
2. `RealtimeTransport`: provider-neutral WebSocket contract; sends typed events, PCM audio frames, image frames, and receives transcription/audio/tool events.
3. `PcmAudioCapture`: AudioRecord input with negotiated sample rate, bounded buffers, audio focus, and guaranteed release.
4. `PcmAudioPlayer`: low-latency streaming playback; flushes immediately on barge-in.
5. `RealtimeProvider`: capability declaration for input/output audio, text, image, interruption, and tool calls.
6. `RealtimeProviderManager`: checks credentials and capabilities before connecting; explicit fallback with a visible reason.
7. `TranscriptSynchronizer`: reconciles partial/final input and output transcripts with the shared conversation timeline.
8. `RealtimeToolBridge`: routes every tool request through `ActionGateway` → `ActionPolicy` → user confirmation where required. Realtime models never invoke Android APIs directly.

### Gemini Live provider
- Implement as an optional provider, not as a hard dependency for the app.
- Use a backend-issued short-lived/ephemeral credential. Never package a permanent provider secret in the APK.
- Negotiate audio formats from the current official API contract; do not hardcode assumptions across API versions.
- Handle session setup, server content, input/output transcription, audio chunks, interruption, tool calls, setup errors, and session resumption.
- Keep the current SpeechRecognizer/TTS path as a fallback until the realtime path passes device tests.

## 2. Xion capabilities beyond a basic Live clone

### A. Task Capsule
A compact, user-visible handoff record for multi-step tasks: objective, constraints, decisions, completed steps, pending steps, and next action. It can be copied/exported and cleared by the user. It must not silently become permanent memory.

### B. Multi-agent workbench
Specialist roles are orchestrated only when useful:
- Researcher: gathers current evidence and cites sources.
- Analyst: checks assumptions, compares options, and identifies uncertainty.
- Planner: turns goals into ordered steps and tracks blockers.
- Operator: proposes phone actions through the existing safety gateway.
- Verifier: checks important outputs independently and reports disagreements.
The UI must show which roles actually ran; never simulate agent activity.

### C. Model Flight Recorder
A transparent per-turn trace: selected provider/model, fallback reason, latency, token/usage metadata when supplied by the provider, review status, and tool approvals. Secrets and private prompt contents are excluded. Users can clear or export the trace.

### D. Personal Command Studio
Users can define named command routines from approved existing actions (for example, a morning setup). Each routine has a preview, editable steps, explicit permission boundaries, and confirmation before consequential actions. No hidden background execution.

### E. Context Lens
A session-only context panel showing what Xion is currently using: conversation summary, user-attached images, explicitly shared screen/camera frames, and task constraints. Every source is labelled; removing a source removes it from the active context where technically possible.

### F. Model Council
For high-impact or complex answers, optionally ask a second configured model to critique the first. Present meaningful disagreement and evidence. Do not average conflicting claims into false certainty. Respect the user's cost and latency settings.

### G. Offline Utility Layer
A small local command interpreter for deterministic actions that do not need an AI provider (timers, flashlight state, opening settings, and other explicitly supported local actions). AI unavailability should not disable deterministic local functions. The action whitelist remains authoritative.

## 3. Non-negotiable trust model
- No silent recording, camera, screen capture, or background listening.
- No action from untrusted model output can bypass typed parsing, validation, policy, confirmation, and audit logging.
- External content is data, never authority.
- Least privilege, visible permissions, and immediate session stop.
- Do not claim access to screen, files, location, contacts, or sensors unless the Android app actually supplied that data and permission.
- Secrets stay encrypted at rest and are never written to logs or included in exported traces.

## 4. Implementation sequence

| Phase | Deliverable | Acceptance gate |
|---|---|---|
| 1 | Realtime interfaces and lifecycle state machine | JVM tests cover every state transition, cancellation, and duplicate close |
| 2 | AudioRecord/AudioTrack streaming | Physical-device latency, focus, cleanup, and interruption tests |
| 3 | Secure ephemeral-token backend | No permanent key in APK; token expiry and abuse limits verified |
| 4 | Gemini Live provider adapter | Real-device Arabic/English session, transcripts, audio, reconnect, barge-in |
| 5 | ToolBridge integration | Automated tests prove every action passes ActionGateway and policy |
| 6 | Camera/screen context | Explicit Android consent, visible indicator, throttling, stop/revoke behavior |
| 7 | Task Capsule + Model Flight Recorder | User controls, redaction, export/clear tests |
| 8 | Specialist orchestration + Model Council | Role activity is truthful; disagreement and cost policy tested |
| 9 | Visual polish and accessibility | No emoji glyphs; consistent vector icon family; RTL, font scaling, contrast |

## 5. Current status of this source update
- Expanded the shared system prompt with deeper conversational, live-turn-taking, dialect, planning, verification, and transparency behavior.
- Replaced emoji glyphs in the Compose chat controls and voice-message marker with original vector glyphs / text labels.
- Added this implementation brief so the next engineering pass has explicit interfaces, security boundaries, and acceptance tests.
- Full-duplex audio, Gemini Live transport, camera/screen streaming, specialist-agent execution, and the new workbench features are **planned**, not implemented in this source update.
