# Xion Task Workflow (3.2.6)

The chat composer exposes a workflow control when the draft is at least 12 characters long. It is an explicit opt-in action; normal chat remains unchanged.

## Execution model

1. One configured provider plans up to four short analysis steps.
2. Steps run sequentially. Each successful step uses a different provider where possible; the planner and already-used providers are excluded.
3. A final, unused provider consolidates results. If capacity runs out, Xion returns a clearly partial result instead of claiming completion.
4. Progress is surfaced in the chat screen. The user can request cancellation; cancellation is checked between provider calls.

## Safety and cost boundaries

- Workflow output is analysis only. It cannot call Android device actions, change settings, or perform external side effects.
- Every request passes through the existing orchestrator, provider fallback and cooldown logic.
- No speculative parallel calls are made. Maximum planned steps: four.
- A multi-provider workflow may use several model requests. The user must explicitly tap the workflow control; normal messages do not trigger it.
- Provider diversity is best-effort. If fewer providers are configured, Xion reports partial completion.

## Limitations

This is a bounded sequential workflow, not an autonomous background agent. It does not browse independently, create files, or execute code. Those capabilities require separate, permissioned tools and explicit user approval.
