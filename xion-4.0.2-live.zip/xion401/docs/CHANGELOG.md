# 4.0.2 (source)
- Xion Live: shared conversation, policy-gated `phone_action` tool with button approval and timeout, redacted errors, automatic fallback, Live button.
- Live setup now requests transcription and uses `generationConfig.responseModalities` (transcripts were not requested before).
- Docs: known-limitations corrected (Task Capsule/Context Lens/Flight Recorder exist).

# Xion 4.0.0 — unified source release candidate

## 3.2.1 — engineering pass
- Bumped Android version metadata to `3.2.1` / versionCode `321`.
- Replaced the legacy single-layer launcher drawable reference with Android adaptive launcher resources (`mipmap-anydpi-v26`) plus a pre-26 vector fallback. Both `android:icon` and `android:roundIcon` now resolve through the mipmap resource.
- Added an original Xion mark using the purple/cyan split arms and central light node; no text or emoji is used in the launcher artwork.
- Replaced the chat notice close glyph and jump-to-latest arrow glyph with the app's own vector-drawn `XIcon` family.
- Replaced the settings back-navigation text arrow with the same vector icon family.
- Preserved the `app.xion` application ID so this remains an update path for the existing 3.x install.
- Retained the expanded Xion system prompt and the existing security/action-policy path.

## 3.2 intelligence foundation
- Expanded shared model instructions for conversational context, Iraqi/Gulf Arabic, planning, verification, transparency, and safe live turn-taking.
- Added the engineering brief for realtime voice, task handoff, model trace, multi-agent workbench, context lens, model council, and offline utilities.

## 3.1 voice foundation
- Added opt-in continuous turn-taking using Android SpeechRecognizer and TextToSpeech.
- Added bounded recovery for no-match, speech timeout, and recognizer-busy errors.

## 3.0 foundation
- Compose chat/settings/providers/usage/security/about screens.
- Shared typed/voice conversation engine, provider routing, encrypted API-key storage, action policy, and audit log.


## 3.2.2 — completion pass
- Added task-specific provider preference controls to Settings, backed by the existing routing configuration.
- Added explicit status text in About to distinguish implemented capabilities from roadmap-only features.
- Updated release notes and known limitations to reflect the actual UI.

## 3.2.3 — Complete encrypted settings backup
- Upgraded the encrypted settings payload to v2.
- Backups now preserve provider enable/disable switches, user-declared free-plan flags, per-task provider routes, routing strategy, and voice reply/continuous-session preferences.
- Import remains backward-compatible with v1 backups from earlier Xion 3.x builds.
- API keys and the optional search key remain inside the passphrase-encrypted BackupCodec envelope; no plaintext backup format was added.

## 3.2.4 — one-use action authorization
- Added a one-use authorization ledger at the device gateway. An action must match a fresh `Allow` policy decision or a matching `Confirm` decision before it can reach `DeviceActions`.
- Confirmation tickets are consumed only when the caller marks the exact proposed action as user-confirmed; denied tickets are invalidated.
- Unproposed, replayed, mismatched, or incorrectly-confirmed actions are rejected and recorded in the audit log.
- Added focused unit tests for one-use tickets, explicit confirmation, denied proposals, and rejected decisions.

## 3.2.5 — Opt-in Model Council API
- Added a sequential multi-provider council workflow to the orchestration layer: one draft, up to three independent reviews from distinct providers, and a final synthesis from another provider when available.
- Council calls are explicit and opt-in at the API boundary; ordinary chat routing and token spend are unchanged.
- Providers are never reused within a single council run. If only one provider is configured, Xion safely returns the draft without pretending a review occurred.
- Added unit tests for distinct-provider flow and single-provider graceful fallback.

## 3.2.6 — Task Workflow
- Added an explicit opt-in multi-provider task workflow from the chat composer.
- Added bounded planning (maximum four steps), sequential step execution, provider diversity, progress updates, cancellation checks, and final synthesis.
- Partial results are retained and labelled when provider capacity is insufficient.
- Workflow is analysis-only and cannot invoke Android device actions.
- Added unit coverage for successful orchestration, partial completion, and early cancellation.

## 3.3.0 — Task Capsules
- Added an encrypted, bounded local memory for the latest ten task-workflow summaries. Capsules contain the task goal, final summary, completion counts and timestamp; they never contain API keys or the full conversation transcript.
- Added a chat card to restore a saved capsule as explicit context or delete it. Restoring a capsule only adds context notes; it does not resume network calls or execute actions.
- Added a dedicated vector archive glyph and advanced the app version to 3.3.0.


## Xion 4.0.0 — Adaptive Intelligence Core

- Added **Adaptive routing**: provider ordering now balances measured success rate, first-token/total latency, provider-reported pricing, context-window fit, task type, and the user's explicit task route. This is an operational-fit score, not a claim that Xion has measured model intelligence. Unknown measurements use neutral priors.
- Preserved manual, speed, cost, free-only, auto, and quality routing modes.
- Exposed the Model Council in the composer: one draft, up to two independent reviews, and a distinct synthesis provider when available; the result records actual participating providers and gracefully reports partial council capacity.
- Added **Context Lens**: when the rolling conversation window is trimmed, Xion keeps short redacted excerpts of older turns as explicitly labelled context; recent turns remain verbatim. Clearing the conversation clears this compacted context.
- Workflow cancellation now returns and saves completed step results as a partial Task Capsule instead of discarding all progress. The user can restore the saved summary later; no step is silently resumed or externally executed.
- Version metadata updated to 4.0.0.

## Xion 4.0.0 — completion engineering pass
- Added a bounded Model Flight Recorder that stores only operational metadata (provider/model/task/outcome/duration/estimated token counts/error class); prompts, responses, and credentials are excluded.
- Added a user-facing Flight Recorder timeline under Usage, with refresh and clear controls.
- Persisted telemetry after ordinary turns and explicit multi-model workflows/council runs.
- Added independent-review difference counts to provider telemetry; the UI describes them as differences from the draft, not verified corrections.
- Task Workflow steps now receive bounded evidence from earlier completed steps, allowing sequential dependency-aware analysis instead of isolated prompts.
- Corrected the QUALITY strategy help text to describe its actual behavior and point to the explicit Model Council control.
- Corrected the About screen to report Xion 4.0.0 and the implemented/unfinished capability boundary.


## 4.0.0 — camera pipeline and workflow hardening
- Camera frame analysis is now sequential and awaited: the next frame is not captured for analysis until the prior model request completes, avoiding overlapping vision requests.
- Added explicit frame-level status and clearer visual-analysis prompting that distinguishes visible evidence from uncertainty.
- Expanded Task Workflow from four to six bounded steps and added specialist reasoning lenses (security, verification, UX, engineering, research, and general analysis) with bounded evidence handoff.
- No claim of full-duplex realtime audio or autonomous tool-using agents; these require separate provider-native transports, lifecycle/security design, and device validation.

## Xion 4.0.1 — Live multimodal integration (source update)
- Added Gemini Live WebSocket transport for bidirectional PCM audio, model audio playback, interruption handling, text input, and JPEG video frames.
- Connected the live transport to the foreground camera dialog; camera frames can now share the same live session as microphone audio (target maximum 1 FPS).
- Live session is explicitly started by the user and stopped on dialog dismissal or app backgrounding.
- Added configurable Gemini Live model selection defaulting to the model shown in Google's current WebSocket getting-started guide.
- Documented ephemeral-token production requirement and outstanding Android/device verification gates.
- Retained the bounded specialist-agent workflow and its no-autonomous-device-action boundary.
