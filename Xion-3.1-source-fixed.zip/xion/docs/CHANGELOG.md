# 3.0.0-dev
- New package `app.xion`; Compose UI (chat, settings, providers, usage, security center, about); legacy Views settings kept.
- Text chat + voice sharing one conversation engine.
- Provider layer + orchestrator (fallback, measured stats, strategies); OpenRouter, Groq, Mistral, Cerebras, Together added.
- Action policy gateway, audit log, Keystore-encrypted keys, encrypted backups, voice confirmation for sensitive actions.


## Xion 3.1 voice foundation (working source changes)
- Added opt-in continuous voice conversation mode to the main chat. Xion resumes listening after spoken output completes, rather than cutting off its own TTS.
- Added bounded retry for no-match, speech-timeout, and recognizer-busy conditions while continuous mode is enabled.
- Added a visible continuous-mode control; it is off by default and can be disabled at any time.
- Preserved the shared text/voice conversation engine and existing ActionGateway authorization path.
