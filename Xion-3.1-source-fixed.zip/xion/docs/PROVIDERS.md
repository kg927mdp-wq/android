# Providers

All providers go through `OpenAiCompatAdapter` (OpenAI-style `/chat/completions`, SSE streaming, `/models` discovery).
Billing is shown as **unverified** for every provider; Xion never assumes free = unlimited.

| Provider | Status in code | Docs checked | Default model |
|---|---|---|---|
| DeepSeek, Gemini, Grok | kept from 2.1 | no (behaviour unchanged from 2.1) | as in 2.1 |
| OpenRouter | new | chat endpoint only | none (pick from discovered list) |
| Groq, Mistral, Cerebras, Together | new | **no** (blocked in dev environment) | none |
| Anthropic, Cohere, Cloudflare Workers AI | **not implemented** (need native adapter) | - | - |
| SambaNova, NVIDIA NIM, Hugging Face, DeepInfra, Z.ai, Fireworks, Novita, OVHcloud | **not implemented** | - | - |

Adding an OpenAI-compatible provider = one enum entry in `Provider.kt` (url, modelsUrl). No model ids are hardcoded for new providers;
the list comes from the provider (“اكتشاف الموديلات”). "Free" is shown only when the provider's own listing prices are 0, or when you tick it yourself.
Keys are stored with Android Keystore AES-256-GCM; paid providers are only called if you entered a key and enabled them.
Routing strategies: manual, auto, speed, cost, free-only, quality — ranked from measured latency/failures (`ProviderStats`), not claims.
