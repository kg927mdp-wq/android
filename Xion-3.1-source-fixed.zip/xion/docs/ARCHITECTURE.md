# Xion 3.0 — architecture (phases 1–3)

Xion 3.0 is a separate app (`app.xion`) evolved from Masaedi 2.1 (`app.masaedi`). 2.1 is untouched:
the pristine source is tagged `v2.1-baseline` in this repository and zipped in `backup/` next to it.

## Packages

| Package | Responsibility | Android-free? |
|---|---|---|
| `ai` | Streaming, provider fallback, cross-model review, web search (`Brain`, `ReplyParser`, `WebSearch`) | `ReplyParser` yes |
| `data` | Settings (`Config`), encrypted secret storage (`SecureStore`, Keystore key) | no |
| `security` | Strict JSON, typed `Action`s, `ActionPolicy`, `AuditLog`, `EnvelopeCipher`, `BackupCodec`, `Redactor` | **yes** (unit tested on a plain JVM) |
| `device` | `ActionGateway` (security boundary) and `DeviceActions` (Android intents/hardware) | no |
| `voice` | Default-assistant services, recogniser proxy | no |
| `ui` | Views-based screens (unchanged look in phases 1–3; Compose arrives in phase 6) | no |

## The AI ↔ device boundary

```
model text ──► ReplyParser ──► raw proposal (Map, untrusted)
                                   │
                         ActionGateway.propose()
                                   │  ActionPolicy: whitelist, types, limits, per-turn budget,
                                   │  duplicate guard, taint rules
                 ┌─────────────────┼──────────────────┐
              Reject             Confirm              Allow
           (audit, refuse)   (user taps "نفّذ")          │
                                   └────────► ActionGateway.execute() ──► DeviceActions (typed Action only)
                                                         │
                                                    AuditLog
```

* `DeviceActions.run` accepts only a validated `Action`. There is no code path from model text to an intent.
* **Taint:** if the answer used web search results, the turn is "tainted" and every action with an external effect
  (call, SMS, WhatsApp, open link, copy, share, calendar, accessibility settings) needs the user's approval.
* A direct call (when the user enabled it) always needs approval, even without web content.
* Limits: 4 actions per turn; external actions are never repeated within a turn.
* Search text is stripped of the `@@` command marker and control characters, labelled untrusted in the prompt,
  and — more importantly — cannot reach the device without the checks above.

## Secrets

* API keys and the Tavily key are AES-256-GCM encrypted with a non-exportable Android Keystore key
  (`xion_master_v1`); each value is bound to its setting name. No plain-text fallback exists: if the Keystore
  fails, the save fails and the UI says so.
* Errors shown to the user or written to the audit log pass through `Redactor.scrub`.
* Encrypted backup/restore (`BackupCodec`): PBKDF2-HMAC-SHA256 (210 000 iterations) + AES-256-GCM, passphrase ≥ 8 chars,
  never stored. Used to move settings between installs.
* `allowBackup=false`, cleartext HTTP blocked app-wide (`network_security_config.xml`), R8 enabled for release.

## Behaviour changes versus 2.1 (intentional)

1. "Call directly" now starts the call only after the user approves it on screen.
2. After a web search, actions with an external effect ask for approval first.
3. Fields are validated: contact names/numbers accept letters, digits, spaces and `.'’-_()+` only;
   URLs must be http(s) without embedded credentials; unknown action types are refused (and logged).
4. Everything visible says Xion.

## Not done yet (honest status)

* No Android SDK/Gradle dependency access in the build environment used so far: the Android layer
  (`data`, `device`, `voice`, `ui`) has been reviewed but **not compiled or run on a device**. Build it with Android Studio
  or `./gradlew assembleDebug` after `gradle wrapper --gradle-version 8.9`.
* Voice confirmation ("yes/no" spoken) is not implemented; approval is by tapping.
* Provider ecosystem, routing, Provider Intelligence, Compose UI, workflows: phases 4–8.
