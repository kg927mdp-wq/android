# Xion 3.1 source update — delivery report

## Included changes

- Added an opt-in continuous voice conversation control in the main chat header.
- Persisted the preference in app settings (`continuous_voice`, default off).
- After a voice reply, the chat waits for Android TTS to finish before reopening the microphone, avoiding the previous risk of cutting off the assistant's own speech.
- Added bounded recovery for no-match, speech timeout, and recognizer-busy errors while continuous mode is active.
- Added a pure Kotlin `VoiceSessionPolicy` and unit tests for turn resumption and retry rules.
- Kept typed and spoken requests on the same `ConversationEngine` path and kept device actions behind the existing `ActionGateway`.
- Added the voice roadmap and updated known limitations/changelog.

## Verification performed in this environment

- Compiled the pure Kotlin `VoiceSessionPolicy` with `kotlinc` and ran 7 smoke assertions: passed.
- Checked balanced delimiters in the edited controller, Compose screen, and config files: passed.
- Inspected the changed controller/UI integration manually.

## Not verified

- Android/Compose compilation and Gradle tests were not run: this environment has no Gradle executable, Android SDK/platform `android.jar`, or Gradle wrapper in the supplied archive.
- No APK was built.
- No emulator or physical Android device was available for microphone, TTS, audio focus, or UI testing.
- No real-time WebSocket audio provider, Gemini Live adapter, camera streaming, or screen capture was added. The supplied app has no secure backend for ephemeral Live API tokens; embedding a permanent provider key in the APK would be unsafe.

## Required device-side verification

Open the project in Android Studio with JDK 17 and Android SDK 34. Generate the Gradle wrapper if needed, then run:

```bash
gradle wrapper --gradle-version 8.7
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

Install the debug build, grant microphone permission, test one-shot voice mode, enable `∞` continuous mode, speak several turns, interrupt/stop it, then disable continuous mode. Also test text chat and confirmation-required device actions to confirm they still follow the existing policy gateway.
