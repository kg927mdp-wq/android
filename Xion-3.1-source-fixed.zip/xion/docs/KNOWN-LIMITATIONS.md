# Known limitations
- Android/Compose layer never compiled or run; expect first-build fixes.
- Gradle wrapper not included (could not be generated offline); no APK produced; release signing not configured.
- New providers' docs/pricing/limits unverified (except OpenRouter chat endpoint); several requested providers and native adapters not implemented.
- Compose "glass" is translucent layering, not real backdrop blur.
- No accessibility-based device control, no workflows/custom commands (deliberately out of this build).
- Per-task provider routing exists in `Config`/router but has no UI.
- Backup import/export UI is still the legacy Views screen.
- Task analysis is keyword heuristics; provider ranking needs real usage to become meaningful.


## Xion 3.1 voice work in this source update
- Continuous conversation is implemented on top of Android SpeechRecognizer + Android TextToSpeech. It is NOT a full-duplex neural realtime audio session and does not provide Gemini Live-equivalent audio streaming.
- Recognition availability, latency, Arabic dialect accuracy, and TTS voice quality depend on the device's installed speech services and network.
- Barge-in during assistant playback is not implemented as acoustic speech detection; the user can stop playback/listening with the UI control.
- Provider-native realtime audio adapters, selectable cloud voices, camera input, and screen understanding remain future work and require provider-specific API integration and credentials.
