# Moving from Masaedi 2.1 to Xion 3.0

* Xion installs **next to** 2.1 (different package id `app.xion`). Nothing of 2.1 is removed or modified.
* Android keeps each app's data private, so Xion cannot read 2.1's settings. Enter the API keys once in Xion
  (they are stored encrypted at once).
* After that, use **نسخة احتياطية مشفّرة** to move Xion's settings to another phone: the export is encrypted with a
  passphrase you choose; **استعادة نسخة احتياطية** restores it.
* To make Xion the default assistant, choose it in the phone's default assistant setting
  (2.1 and Xion can both be listed; only one is active).
* To go back, uninstall Xion or switch the default assistant to 2.1. `git checkout v2.1-baseline` restores the source.

## Testing the logic without a phone

`app/src/test` holds JUnit 4 tests for the Android-free layers (policy, JSON, crypto, audit log, parser).
Run `./gradlew testDebugUnitTest`.
