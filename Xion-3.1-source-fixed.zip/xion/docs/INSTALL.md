# Install / build
Xion 3.0 installs **separately** from Masaedi 2.1 (`app.xion`); the old app and its data are untouched.
1. Open the project in Android Studio (JDK 17), let it sync. If `gradlew` is missing: `gradle wrapper --gradle-version 8.7`.
2. `./gradlew testDebugUnitTest` then `./gradlew assembleDebug`.
3. Release: create your own keystore and signing config locally; never commit it.
4. To move settings from 2.1, export an encrypted backup there and import it in Xion (legacy settings screen).
