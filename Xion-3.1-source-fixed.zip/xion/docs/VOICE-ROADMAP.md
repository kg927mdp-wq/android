# Xion voice architecture roadmap

## Current implementation in this source update

- Android `SpeechRecognizer` captures a spoken turn and returns partial/final text.
- The existing shared `ConversationEngine` processes voice and typed input through the same provider orchestration and action policy.
- Android `TextToSpeech` reads streamed answer sentences.
- Optional continuous-turn mode reopens recognition after spoken output finishes. It is disabled by default and can be stopped from the chat UI.
- Recoverable no-match, speech-timeout, and recognizer-busy errors receive a bounded retry delay while continuous mode is active.

This is continuous turn-taking, not full-duplex neural audio streaming. Recognition and synthesis are still separate Android services.

## Target real-time architecture

1. `VoiceSessionController`: owns the session lifecycle, cancellation, audio focus, permissions, and UI state.
2. `AudioCapture`: records mono PCM16 at the exact sample rate requested by the selected provider; applies bounded buffering and lifecycle-safe cleanup.
3. `VoiceProvider`: provider contract for capabilities, session setup, streaming input, text/audio output, interruption, and session close.
4. `VoiceProviderManager`: selects a provider only when its declared capabilities and credentials are available; supports explicit fallback and reports why fallback occurred.
5. `AudioPlayback`: plays streamed PCM with low latency and flushes queued audio immediately on interruption.
6. `TranscriptBridge`: synchronizes interim/final input and output transcription with the shared conversation history.
7. `ToolBridge`: converts provider tool requests into existing Xion actions and sends them through `ActionGateway` and `ActionPolicy`. No realtime provider may execute a phone action directly.

## Gemini Live integration notes

Google's current Gemini Live API uses a stateful WebSocket session. Its documented raw audio input is PCM16 at 16 kHz and output audio is PCM16 at 24 kHz. It supports audio, text, image/video input, transcription events, and interruption signals. The production client-to-server flow should use short-lived/ephemeral tokens rather than embedding a long-lived API key in the APK.

Official documentation:
- https://ai.google.dev/gemini-api/docs/live-api
- https://ai.google.dev/api/live

The current Xion ZIP does not contain a backend capable of issuing ephemeral tokens, nor a configured Firebase project. A direct APK integration that embeds a permanent Gemini key would expose that key to extraction, so it is intentionally not added as a production implementation.

## Camera and screen understanding

- Camera frames must be captured only after an explicit user action and clear active-session indicator.
- Screen capture must use Android's user-visible MediaProjection consent flow; it must never run invisibly.
- Image frames should be throttled and resized before upload. Do not stream a continuous screen recording by default.
- Visual observations and tool calls remain untrusted model output and must not bypass action policy.

## Acceptance tests before calling this production-ready

- Verify PCM format, buffer sizing, audio focus, and playback lifecycle on physical devices.
- Measure time-to-first-audio, interruption latency, reconnect time, and memory use.
- Test Arabic (including Iraqi dialect), English, noisy environments, silence, and network loss.
- Verify provider fallback and cancellation do not leave the microphone or WebSocket active.
- Verify a tool request cannot bypass `ActionGateway`, even when returned during a live session.
- Verify API secrets are never embedded in the APK or written to logs.
