# Testing report (honest)

**Ran and passed:** 160 JVM unit tests (0 failed) on the pure-Kotlin layer: action policy, JSON limits, redaction, envelope cipher,
backup codec, audit log, reply parser, conversation engine (text+voice shared context, busy guard, retry, clear, bounded history),
OpenAI-compatible adapter (fake transport + local HTTP server), orchestrator/router/stats, confirmation matcher.
These were compiled with a standalone Kotlin compiler and a minimal JUnit shim, not with Gradle.

**Not compiled:** everything that touches Android or Compose (`ui/`, `voice/`, `device/`, `data/Config`, `XionApp`). No Gradle build,
no Debug/Release APK, no emulator or device run. Compile errors there are possible.

**Not tested:** real provider calls, mic/TTS, device actions, Keystore on a device, Compose UI, R8 release rules.
Run `./gradlew testDebugUnitTest assembleDebug` after adding the Gradle wrapper (see INSTALL.md).
