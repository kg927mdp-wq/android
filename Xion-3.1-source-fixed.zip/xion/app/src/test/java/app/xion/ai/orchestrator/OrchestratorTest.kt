package app.xion.ai.orchestrator

import app.xion.ai.provider.ChatMsg
import app.xion.ai.provider.ErrorKind
import app.xion.ai.provider.ModelInfo
import app.xion.ai.provider.Provider
import app.xion.ai.provider.ProviderError
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OrchestratorTest {
    private val msgs = listOf(ChatMsg("user", "hello"))
    private val chat = TaskProfile(TaskType.CHAT, 10, false)

    private fun run(h: Harness, live: Boolean = true, cancelled: () -> Boolean = { false }): Triple<StreamResult?, RecordingSink, List<ProviderError>> {
        val sink = RecordingSink()
        val errs = ArrayList<ProviderError>()
        val r = h.orch.stream(msgs, chat, live, cancelled, sink, errs)
        return Triple(r, sink, errs)
    }

    @Test fun usesPrimaryFirstAndOnlyOneProvider() {
        val s = FakeSettings().setup(Provider.DEEPSEEK, Provider.GEMINI, Provider.GROK); s.primary = Provider.GEMINI
        val h = Harness(s)
        val (r, sink, _) = run(h)
        assertEquals(Provider.GEMINI, r!!.provider)
        assertEquals(1, h.a(Provider.GEMINI).calls)
        assertEquals(0, h.a(Provider.DEEPSEEK).calls)   // no parallel or speculative requests
        assertEquals(listOf(Provider.GEMINI), sink.attempts)
    }

    @Test fun fallsBackWhenProviderFailsAndRecordsIt() {
        val s = FakeSettings().setup(Provider.DEEPSEEK, Provider.GEMINI); s.primary = Provider.DEEPSEEK
        val h = Harness(s)
        h.a(Provider.DEEPSEEK).script.add(FakeAdapter.Act.Err(ErrorKind.SERVER, 503))
        h.a(Provider.GEMINI).script.add(FakeAdapter.Act.Say(listOf("hi")))
        val (r, sink, errs) = run(h)
        assertEquals("hi", r!!.text); assertEquals(Provider.GEMINI, r.provider)
        assertEquals(listOf(Provider.DEEPSEEK, Provider.GEMINI), sink.attempts)
        assertEquals(1, errs.size)
        assertEquals(1, h.stats.snapshot(Provider.DEEPSEEK).fail)
        assertEquals(1, h.stats.snapshot(Provider.GEMINI).ok)
    }

    @Test fun failedProviderIsDemotedForNextRequest() {
        val s = FakeSettings().setup(Provider.DEEPSEEK, Provider.GEMINI); s.primary = Provider.DEEPSEEK
        val h = Harness(s)
        h.a(Provider.DEEPSEEK).script.add(FakeAdapter.Act.Err(ErrorKind.SERVER, 503))
        run(h)
        run(h)
        assertEquals(1, h.a(Provider.DEEPSEEK).calls)    // cooling down: not tried again right away
        h.clock += 60_000                                 // cool-down over
        run(h)
        assertEquals(2, h.a(Provider.DEEPSEEK).calls)
    }

    @Test fun authFailureCoolsDownUntilKeyChanges() {
        val s = FakeSettings().setup(Provider.DEEPSEEK, Provider.GEMINI); s.primary = Provider.DEEPSEEK
        val h = Harness(s)
        h.a(Provider.DEEPSEEK).script.add(FakeAdapter.Act.Err(ErrorKind.AUTH, 401))
        run(h)
        h.clock += 120_000
        run(h)
        assertEquals(1, h.a(Provider.DEEPSEEK).calls)
        h.stats.resetHealth(Provider.DEEPSEEK)
        run(h)
        assertEquals(2, h.a(Provider.DEEPSEEK).calls)
    }

    @Test fun liveAnswerIsKeptWhenFailureComesAfterOutput() {
        val s = FakeSettings().setup(Provider.DEEPSEEK, Provider.GEMINI); s.primary = Provider.DEEPSEEK
        val h = Harness(s)
        h.a(Provider.DEEPSEEK).script.add(FakeAdapter.Act.Err(ErrorKind.NETWORK, -1, after = listOf("Half an ", "answer")))
        val (r, _, _) = run(h, live = true)
        assertEquals("Half an answer", r!!.text); assertTrue(r.truncated)
        assertEquals(0, h.a(Provider.GEMINI).calls)       // nothing already spoken is replayed elsewhere
    }

    @Test fun silentModeRestartsOnNextProviderAndResetsSink() {
        val s = FakeSettings().setup(Provider.DEEPSEEK, Provider.GEMINI); s.primary = Provider.DEEPSEEK
        val h = Harness(s)
        h.a(Provider.DEEPSEEK).script.add(FakeAdapter.Act.Err(ErrorKind.NETWORK, -1, after = listOf("junk")))
        h.a(Provider.GEMINI).script.add(FakeAdapter.Act.Say(listOf("clean")))
        val (r, sink, _) = run(h, live = false)
        assertEquals("clean", r!!.text); assertFalse(r.truncated)
        assertEquals("clean", sink.text.toString())
    }

    @Test fun singleProviderGetsOneRetryForTransientErrorsOnly() {
        val s = FakeSettings().setup(Provider.GROQ)
        val h = Harness(s)
        h.a(Provider.GROQ).script.add(FakeAdapter.Act.Err(ErrorKind.TIMEOUT))
        h.a(Provider.GROQ).script.add(FakeAdapter.Act.Say(listOf("ok")))
        assertEquals("ok", run(h).first!!.text)
        assertEquals(listOf(800L), h.sleeps)

        val h2 = Harness(FakeSettings().setup(Provider.GROQ))
        h2.a(Provider.GROQ).script.add(FakeAdapter.Act.Err(ErrorKind.AUTH, 401))
        assertNull(run(h2).first)
        assertEquals(1, h2.a(Provider.GROQ).calls)
        assertTrue(h2.sleeps.isEmpty())
    }

    @Test fun everyProviderFailingReturnsNullWithAllErrors() {
        val h = Harness(FakeSettings().setup(Provider.DEEPSEEK, Provider.GEMINI))
        h.a(Provider.DEEPSEEK).script.add(FakeAdapter.Act.Err(ErrorKind.SERVER, 500))
        h.a(Provider.GEMINI).script.add(FakeAdapter.Act.Err(ErrorKind.RATE_LIMIT, 429))
        val (r, _, errs) = run(h)
        assertNull(r)
        assertEquals(listOf(ErrorKind.SERVER, ErrorKind.RATE_LIMIT), errs.map { it.kind })
    }

    @Test fun cancellationReturnsNullAndIsNotCountedAsProviderFailure() {
        val h = Harness(FakeSettings().setup(Provider.DEEPSEEK))
        h.a(Provider.DEEPSEEK).script.add(FakeAdapter.Act.Err(ErrorKind.NETWORK))
        val (r, _, _) = run(h, cancelled = { true })
        assertNull(r)
        assertEquals(0, h.stats.snapshot(Provider.DEEPSEEK).fail)
    }

    @Test fun providersWithoutKeyModelOrSwitchAreSkipped() {
        val s = FakeSettings().setup(Provider.DEEPSEEK, Provider.GEMINI, Provider.GROQ)
        s.keys.remove(Provider.DEEPSEEK); s.models.remove(Provider.GEMINI); s.off.add(Provider.GROQ)
        assertTrue(Harness(s).orch.available().isEmpty())
        s.off.clear()
        assertEquals(listOf(Provider.GROQ), Harness(s).orch.available().map { it.provider })
    }

    @Test fun problemExplainsWhatIsMissing() {
        assertTrue(Harness(FakeSettings()).orch.problem()!!.contains("مفتاح"))
        val s = FakeSettings(); s.keys[Provider.GROQ] = "k"
        assertTrue(Harness(s).orch.problem()!!.contains("موديل"))
        assertNull(Harness(FakeSettings().setup(Provider.GROQ)).orch.problem())
    }

    @Test fun completeSkipsExcludedProviderAndFallsThrough() {
        val s = FakeSettings().setup(Provider.DEEPSEEK, Provider.GEMINI, Provider.GROK); s.primary = Provider.DEEPSEEK
        val h = Harness(s)
        h.a(Provider.GEMINI).script.add(FakeAdapter.Act.Err(ErrorKind.SERVER))
        h.a(Provider.GROK).script.add(FakeAdapter.Act.Say(listOf("OK")))
        val r = h.orch.complete(msgs, chat, setOf(Provider.DEEPSEEK), ArrayList())!!
        assertEquals(Provider.GROK, r.provider)
        assertEquals(0, h.a(Provider.DEEPSEEK).calls)
    }

    @Test fun pingRecordsLatencyAsMeasurement() {
        val h = Harness(FakeSettings().setup(Provider.GROQ))
        h.a(Provider.GROQ).script.add(FakeAdapter.Act.Say(listOf("OK"), totalMs = 420))
        assertTrue(h.orch.ping(Provider.GROQ).startsWith("يشتغل"))
        assertEquals(420.0, h.stats.snapshot(Provider.GROQ).avgTotalMs!!, 0.001)
        h.a(Provider.GROQ).script.add(FakeAdapter.Act.Err(ErrorKind.AUTH, 401))
        assertTrue(h.orch.ping(Provider.GROQ).endsWith("✗"))
    }

    @Test fun conversationContextReachesTheProviderUnchanged() {
        val h = Harness(FakeSettings().setup(Provider.GROQ))
        val ctx = listOf(ChatMsg("system", "s"), ChatMsg("user", "q1"), ChatMsg("assistant", "a1"), ChatMsg("user", "q2"))
        h.orch.stream(ctx, chat, true, { false }, RecordingSink(), ArrayList())
        assertEquals(ctx, h.a(Provider.GROQ).lastMessages)
    }
}
