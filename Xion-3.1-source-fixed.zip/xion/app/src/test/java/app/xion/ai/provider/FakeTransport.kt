package app.xion.ai.provider

/** Scripted network for tests. Each call consumes the next scripted step. */
class FakeTransport : Transport {
    sealed class Step {
        class Reply(val code: Int, val body: String = "", val headers: Map<String, String> = emptyMap()) : Step()
        class Sse(val lines: List<String>, val code: Int = 200) : Step()
        class Fail(val kind: ErrorKind) : Step()
    }

    class Call(val method: String, val url: String, val headers: Map<String, String>, val body: String?)

    val steps = ArrayDeque<Step>()
    val calls = ArrayList<Call>()

    override fun request(method: String, url: String, headers: Map<String, String>, body: String?, timeouts: Timeouts): HttpResult {
        calls.add(Call(method, url, headers, body))
        return when (val s = steps.removeFirst()) {
            is Step.Reply -> HttpResult(s.code, s.body, s.headers)
            is Step.Fail -> throw TransportException(s.kind, "fake")
            is Step.Sse -> HttpResult(s.code, s.lines.joinToString("\n"), emptyMap())
        }
    }

    override fun stream(
        url: String, headers: Map<String, String>, body: String, timeouts: Timeouts,
        cancelled: () -> Boolean, onLine: (String) -> Unit
    ): HttpResult {
        calls.add(Call("POST", url, headers, body))
        return when (val s = steps.removeFirst()) {
            is Step.Sse -> {
                for (l in s.lines) {
                    if (cancelled()) break
                    onLine(l)
                }
                HttpResult(s.code, "", emptyMap())
            }
            is Step.Reply -> HttpResult(s.code, s.body, s.headers)
            is Step.Fail -> throw TransportException(s.kind, "fake")
        }
    }
}

fun sse(vararg pieces: String): List<String> =
    pieces.flatMap { listOf("data: {\"choices\":[{\"delta\":{\"content\":\"$it\"}}]}", "") } + listOf("data: [DONE]")
