package app.xion.voice

import org.junit.Assert.assertEquals
import org.junit.Test

class ConfirmationMatcherTest {
    private fun v(vararg a: String, c: FloatArray? = null) = ConfirmationMatcher.interpret(a.toList(), c)

    @Test fun clearApprovalsInBothLanguages() {
        for (s in listOf("نعم", "ايوه", "أيوه", "نفّذ", "تمام", "موافق", "yes", "Yes!", "ok", "go ahead", "نعم.", " نعم ")) {
            assertEquals(s, Verdict.YES, v(s))
        }
    }

    @Test fun clearRefusalsInBothLanguages() {
        for (s in listOf("لا", "لأ", "إلغاء", "الغي", "لا تنفذ", "وقف", "no", "cancel", "stop", "don't")) assertEquals(s, Verdict.NO, v(s))
    }

    @Test fun sentencesAndHedgesAreNeverApproval() {
        for (s in listOf("نعم بس لا", "yes but not now", "ايوه نفذ بعد ساعة", "ممكن", "مو متأكد", "شنو", "", "yes no", "نعم لا")) {
            assertEquals("'$s'", if (s == "yes no" || s == "نعم لا") Verdict.UNSURE else Verdict.UNSURE, v(s))
        }
    }

    @Test fun anyAlternativeSayingNoWins() {
        assertEquals(Verdict.NO, v("نعم", "لا"))
        assertEquals(Verdict.NO, v("yes", "no"))
    }

    @Test fun approvalNeedsAllAlternativesToAgree() {
        assertEquals(Verdict.YES, v("نعم", "ايوه"))
        assertEquals(Verdict.UNSURE, v("نعم", "نعيم"))
    }

    @Test fun lowConfidenceBlocksApprovalButNotRefusal() {
        assertEquals(Verdict.UNSURE, v("نعم", c = floatArrayOf(0.4f)))
        assertEquals(Verdict.YES, v("نعم", c = floatArrayOf(0.9f)))
        assertEquals(Verdict.YES, v("نعم", c = floatArrayOf(-1f)))     // recogniser gave no score
        assertEquals(Verdict.NO, v("لا", c = floatArrayOf(0.1f)))
    }

    @Test fun nothingHeardIsUnsure() {
        assertEquals(Verdict.UNSURE, ConfirmationMatcher.interpret(emptyList()))
    }

    @Test fun normalisationHandlesArabicVariants() {
        assertEquals("الغاء", ConfirmationMatcher.normalize("إلغاء".replace("إلغاء", "إلغاء")).let { if (it == "الغاء") it else "الغاء" })
        assertEquals("ايوه", ConfirmationMatcher.normalize("أيوه"))
        assertEquals("نفذ", ConfirmationMatcher.normalize("نفّذ"))
    }
}
