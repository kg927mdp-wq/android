package app.xion.ai.orchestrator

import app.xion.ai.provider.ChatMsg
import app.xion.ai.provider.Completion
import app.xion.ai.provider.ErrorKind
import app.xion.ai.provider.ModelInfo
import app.xion.ai.provider.Provider
import app.xion.ai.provider.ProviderAdapter
import app.xion.ai.provider.ProviderError
import app.xion.ai.provider.StreamOutcome
import app.xion.ai.provider.Timeouts

class FakeSettings : RoutingSettings {
    val keys = HashMap<Provider, String>()
    val models = HashMap<Provider, String>()
    val off = HashSet<Provider>()
    val free = HashSet<Provider>()
    val infos = HashMap<Provider, ModelInfo>()
    val routes = HashMap<TaskType, Provider>()
    override var strategy: Strategy = Strategy.MANUAL
    override var primary: Provider? = null
    override fun key(p: Provider) = keys[p] ?: ""
    override fun model(p: Provider) = models[p] ?: ""
    override fun enabled(p: Provider) = p !in off
    override fun declaredFree(p: Provider) = p in free
    override fun taskRoute(t: TaskType) = routes[t]
    override fun modelInfo(p: Provider, model: String) = infos[p]

    fun setup(vararg ps: Provider): FakeSettings {
        for (p in ps) { keys[p] = "key-${p.name}"; models[p] = "model-${p.name}" }
        return this
    }
}

/** An adapter whose behaviour per call is scripted. A step is either text pieces or an error. */
class FakeAdapter(override val provider: Provider) : ProviderAdapter {
    sealed class Act {
        class Say(val pieces: List<String>, val firstMs: Long = 100, val totalMs: Long = 300) : Act()
        class Err(val kind: ErrorKind, val code: Int = 500, val after: List<String> = emptyList()) : Act()
    }

    val script = ArrayDeque<Act>()
    var calls = 0
    var lastMessages: List<ChatMsg> = emptyList()
    var onCall: (() -> Unit)? = null
    val allCalls = ArrayList<List<ChatMsg>>()

    private fun next(): Act = script.removeFirstOrNull() ?: Act.Say(listOf("default"))

    override fun stream(
        apiKey: String, model: String, messages: List<ChatMsg>, timeouts: Timeouts,
        cancelled: () -> Boolean, onDelta: (String) -> Unit
    ): StreamOutcome {
        calls++
        lastMessages = messages
        allCalls.add(messages)
        onCall?.invoke()
        when (val a = next()) {
            is Act.Say -> { a.pieces.forEach(onDelta); return StreamOutcome(a.pieces.joinToString(""), a.firstMs, a.totalMs) }
            is Act.Err -> { a.after.forEach(onDelta); throw ProviderError(provider, a.kind, a.code, "scripted") }
        }
    }

    override fun complete(apiKey: String, model: String, messages: List<ChatMsg>, timeouts: Timeouts): Completion {
        calls++
        lastMessages = messages
        when (val a = next()) {
            is Act.Say -> return Completion(a.pieces.joinToString(""), null, a.totalMs)
            is Act.Err -> throw ProviderError(provider, a.kind, a.code, "scripted")
        }
    }

    override fun listModels(apiKey: String, timeouts: Timeouts): List<ModelInfo> = listOf(ModelInfo("m1"))
}

class Harness(val settings: FakeSettings = FakeSettings()) {
    var clock = 1_000_000L
    val sleeps = ArrayList<Long>()
    val adapters = HashMap<Provider, FakeAdapter>()
    val stats = ProviderStats { clock }
    val orch = Orchestrator(
        app.xion.ai.provider.UrlTransport(), settings, stats, Timeouts(), { sleeps.add(it) },
        { adapters.getOrPut(it) { FakeAdapter(it) } }
    )
    fun a(p: Provider): FakeAdapter = adapters.getOrPut(p) { FakeAdapter(p) }
}

class RecordingSink : StreamSink {
    val attempts = ArrayList<Provider>()
    val text = StringBuilder()
    override fun onAttempt(provider: Provider, model: String) { attempts.add(provider); text.setLength(0) }
    override fun onDelta(text: String) { this.text.append(text) }
}
