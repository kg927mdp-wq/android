package app.xion.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ActionPolicyTest {

    private fun eval(
        json: String,
        tainted: Boolean = false,
        direct: Boolean = false,
        policy: ActionPolicy = ActionPolicy()
    ): Decision = policy.evaluate(Json.parseObject(json)!!, tainted, direct)

    private fun allowed(d: Decision): Action {
        assertTrue("expected Allow but got $d", d is Decision.Allow)
        return (d as Decision.Allow).action
    }

    // ---- valid actions keep working (nothing from 2.1 is lost)

    @Test fun alarmAllowed() {
        assertEquals(Action.SetAlarm(7, 0, ""), allowed(eval("""{"type":"alarm","hour":7,"minute":0}""")))
    }

    @Test fun alarmAcceptsNumbersAsStringsLike21() {
        assertEquals(Action.SetAlarm(7, 30, "x"), allowed(eval("""{"type":"alarm","hour":"7","minute":30.0,"label":"x"}""")))
    }

    @Test fun openAppAllowed() {
        assertEquals(Action.OpenApp("WhatsApp"), allowed(eval("""{"type":"open_app","name":"WhatsApp"}""")))
    }

    @Test fun typeIsCaseAndSpaceInsensitive() {
        allowed(eval("""{"type":" CAMERA "}"""))
    }

    @Test fun smsToNumberAllowedWhenNotTainted() {
        assertEquals(Action.Sms("+9647701234567", "hi"), allowed(eval("""{"type":"sms","to":"+9647701234567","text":"hi"}""")))
    }

    @Test fun arabicContactNameAllowed() {
        allowed(eval("""{"type":"call","to":"أحمد علي"}"""))
    }

    @Test fun flashlightDefaultsOn() {
        assertEquals(Action.Flashlight(true), allowed(eval("""{"type":"flashlight"}""")))
    }

    @Test fun volumeLevelIsClamped() {
        assertEquals(Action.Volume(100, null), allowed(eval("""{"type":"volume","level":250}""")))
        assertEquals(Action.Volume(null, "up"), allowed(eval("""{"type":"volume","change":"up"}""")))
    }

    @Test fun unknownSettingsPageFallsBackToMain() {
        assertEquals(Action.OpenSettings("main"), allowed(eval("""{"type":"settings","page":"developer-secret"}""")))
    }

    @Test fun calendarEndBeforeStartBecomesOneHour() {
        val a = allowed(eval("""{"type":"calendar","title":"t","start":"2026-11-02T10:00","end":"2026-11-02T09:00"}""")) as Action.Calendar
        assertEquals(a.start.plusHours(1), a.end)
    }

    // ---- rejections

    private fun assertRejected(json: String, tainted: Boolean = false) {
        val d = eval(json, tainted)
        assertTrue("expected Reject but got $d", d is Decision.Reject)
    }

    @Test fun unknownTypesRejected() {
        for (t in listOf("shell", "exec", "install_app", "delete_files", "grant_permission", "")) {
            assertRejected("""{"type":"$t","cmd":"rm -rf /"}""")
        }
    }

    @Test fun missingTypeRejected() = assertRejected("""{"hour":7}""")

    @Test fun alarmOutOfRangeRejected() {
        assertRejected("""{"type":"alarm","hour":25,"minute":0}""")
        assertRejected("""{"type":"alarm","hour":7,"minute":99}""")
        assertRejected("""{"type":"alarm","minute":5}""")
    }

    @Test fun timerBoundsRejected() {
        assertRejected("""{"type":"timer","seconds":0}""")
        assertRejected("""{"type":"timer","seconds":9999999}""")
    }

    @Test fun wrongFieldTypesRejected() {
        assertRejected("""{"type":"copy","text":{"a":1}}""")
        assertRejected("""{"type":"copy","text":["x"]}""")
        assertRejected("""{"type":"alarm","hour":true}""")
    }

    @Test fun emptyRequiredTextRejected() {
        assertRejected("""{"type":"open_app","name":"   "}""")
        assertRejected("""{"type":"web_search"}""")
    }

    @Test fun suspiciousContactTargetRejected() {
        assertRejected("""{"type":"call","to":"1;rm -rf /"}""")
        assertRejected("""{"type":"call","to":"a<script>"}""")
        assertRejected("""{"type":"sms","to":"","text":"x"}""")
    }

    @Test fun dangerousUrlsRejected() {
        for (u in listOf(
            "javascript:alert(1)", "file:///etc/passwd", "intent://x#Intent;end",
            "content://contacts", "https://user:pass@evil.example/", "http://", "not a url", "tel:123"
        )) {
            assertRejected("""{"type":"open_url","url":"$u"}""")
        }
    }

    @Test fun httpsUrlAccepted() {
        assertEquals(Action.OpenUrl("https://example.com/a?b=1"), allowed(eval("""{"type":"open_url","url":"https://example.com/a?b=1"}""")))
    }

    @Test fun badCalendarDateRejected() = assertRejected("""{"type":"calendar","title":"t","start":"tomorrow"}""")

    @Test fun musicCommandWhitelisted() = assertRejected("""{"type":"music","command":"format_disk"}""")

    // ---- sanitising

    @Test fun controlCharactersBecomeSpaces() {
        val a = allowed(eval("""{"type":"copy","text":"a\u0000b\u0007c"}""")) as Action.Copy
        assertEquals("a b c", a.text)
    }

    @Test fun longTextIsCut() {
        val a = allowed(eval("""{"type":"web_search","query":"${"x".repeat(500)}"}""")) as Action.WebSearch
        assertEquals(200, a.query.length)
    }

    // ---- confirmation rules

    @Test fun directCallAlwaysNeedsApproval() {
        val d = eval("""{"type":"call","to":"Ahmed"}""", direct = true)
        assertTrue(d is Decision.Confirm)
    }

    @Test fun dialerCallNeedsNoExtraApproval() {
        allowed(eval("""{"type":"call","to":"Ahmed"}""", direct = false))
    }

    @Test fun webContentEscalatesExternalActions() {
        for (j in listOf(
            """{"type":"sms","to":"123456","text":"x"}""",
            """{"type":"whatsapp","to":"123456","text":"x"}""",
            """{"type":"call","to":"123456"}""",
            """{"type":"open_url","url":"https://example.com"}""",
            """{"type":"copy","text":"x"}""",
            """{"type":"share","text":"x"}""",
            """{"type":"calendar","title":"t","start":"2026-11-02T10:00"}""",
            """{"type":"settings","page":"accessibility"}"""
        )) {
            assertTrue("tainted: $j", eval(j, tainted = true) is Decision.Confirm)
        }
    }

    @Test fun webContentDoesNotBlockHarmlessActions() {
        for (j in listOf(
            """{"type":"alarm","hour":7,"minute":0}""",
            """{"type":"open_app","name":"Maps"}""",
            """{"type":"flashlight","on":true}""",
            """{"type":"web_search","query":"x"}""",
            """{"type":"settings","page":"wifi"}"""
        )) {
            allowed(eval(j, tainted = true))
        }
    }

    // ---- per-turn limits

    @Test fun duplicateExternalActionRejectedInSameTurn() {
        val p = ActionPolicy()
        val j = """{"type":"sms","to":"123456","text":"x"}"""
        allowed(eval(j, policy = p))
        assertTrue(eval(j, policy = p) is Decision.Reject)
    }

    @Test fun newTurnResetsDuplicates() {
        val j = """{"type":"sms","to":"123456","text":"x"}"""
        allowed(eval(j, policy = ActionPolicy()))
        allowed(eval(j, policy = ActionPolicy()))
    }

    @Test fun actionsPerTurnAreLimited() {
        val p = ActionPolicy()
        for (i in 1..ActionPolicy.MAX_PER_TURN) allowed(eval("""{"type":"web_search","query":"q$i"}""", policy = p))
        assertTrue(eval("""{"type":"web_search","query":"one more"}""", policy = p) is Decision.Reject)
    }

    @Test fun rejectedActionsDoNotUseTheBudget() {
        val p = ActionPolicy()
        repeat(10) { eval("""{"type":"nope"}""", policy = p) }
        allowed(eval("""{"type":"camera"}""", policy = p))
    }

    @Test fun auditNotesNeverContainMessageBodyOrFullNumber() {
        val a = allowed(eval("""{"type":"sms","to":"07701234567","text":"my secret message"}"""))
        assertTrue(!a.auditNote().contains("secret"))
        assertTrue(!a.auditNote().contains("0770123"))
        assertTrue(a.auditNote().endsWith("chars=17") || a.auditNote().contains("chars=17"))
    }
}
