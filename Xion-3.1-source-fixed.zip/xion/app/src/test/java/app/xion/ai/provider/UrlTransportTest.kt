package app.xion.ai.provider

import com.sun.net.httpserver.HttpServer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.net.InetSocketAddress

/** Runs the real transport against a local HTTP server (loopback only). */
class UrlTransportTest {

    private fun server(handler: (com.sun.net.httpserver.HttpExchange) -> Unit): Pair<HttpServer, String> {
        val s = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        s.createContext("/") { ex -> try { handler(ex) } finally { ex.close() } }
        s.start()
        return Pair(s, "http://127.0.0.1:" + s.address.port)
    }

    private inline fun <T> withLoopback(block: () -> T): T {
        UrlTransport.ALLOW_LOOPBACK_HTTP = true
        try { return block() } finally { UrlTransport.ALLOW_LOOPBACK_HTTP = false }
    }

    private fun expectKind(kind: ErrorKind, block: () -> Unit) {
        try { block() } catch (e: TransportException) { assertEquals(kind, e.kind); return }
        fail("expected TransportException $kind")
    }

    @Test fun postReturnsBodyAndSendsHeaders() = withLoopback {
        var seenAuth: String? = null
        var seenBody = ""
        val (s, base) = server { ex ->
            seenAuth = ex.requestHeaders.getFirst("Authorization")
            seenBody = ex.requestBody.readBytes().toString(Charsets.UTF_8)
            val b = "{\"ok\":true}".toByteArray(); ex.sendResponseHeaders(200, b.size.toLong()); ex.responseBody.write(b)
        }
        try {
            val r = UrlTransport().request("POST", "$base/x", mapOf("Authorization" to "Bearer k"), "{\"a\":1}", Timeouts(2000, 2000))
            assertEquals(200, r.code); assertEquals("{\"ok\":true}", r.body)
            assertEquals("Bearer k", seenAuth); assertEquals("{\"a\":1}", seenBody)
        } finally { s.stop(0) }
    }

    @Test fun streamDeliversLinesAndErrorBodiesCome() = withLoopback {
        val (s, base) = server { ex ->
            if (ex.requestURI.path == "/err") {
                val b = "{\"error\":\"nope\"}".toByteArray(); ex.sendResponseHeaders(429, b.size.toLong()); ex.responseBody.write(b)
            } else {
                ex.sendResponseHeaders(200, 0)
                ex.responseBody.write("data: one\n\ndata: two\n\n".toByteArray())
            }
        }
        try {
            val lines = ArrayList<String>()
            val ok = UrlTransport().stream("$base/s", emptyMap(), "{}", Timeouts(2000, 2000), { false }) { lines.add(it) }
            assertEquals(200, ok.code); assertEquals(listOf("data: one", "", "data: two", ""), lines)
            val bad = UrlTransport().stream("$base/err", emptyMap(), "{}", Timeouts(2000, 2000), { false }) { lines.add("X") }
            assertEquals(429, bad.code); assertTrue(bad.body.contains("nope")); assertEquals(4, lines.size)
        } finally { s.stop(0) }
    }

    @Test fun redirectsAreNotFollowed() = withLoopback {
        val (s, base) = server { ex ->
            ex.responseHeaders.add("Location", "http://127.0.0.1:1/steal"); ex.sendResponseHeaders(302, -1)
        }
        try {
            assertEquals(302, UrlTransport().request("POST", "$base/x", mapOf("Authorization" to "Bearer k"), "{}", Timeouts(2000, 2000)).code)
        } finally { s.stop(0) }
    }

    @Test fun slowServerIsATimeout() = withLoopback {
        val (s, base) = server { ex -> Thread.sleep(1500); ex.sendResponseHeaders(200, -1) }
        try {
            expectKind(ErrorKind.TIMEOUT) { UrlTransport().request("GET", "$base/x", emptyMap(), null, Timeouts(1000, 300)) }
        } finally { s.stop(0) }
    }

    @Test fun refusedConnectionIsNetworkError() = withLoopback {
        expectKind(ErrorKind.NETWORK) { UrlTransport().request("GET", "http://127.0.0.1:1/x", emptyMap(), null, Timeouts(1000, 1000)) }
    }

    @Test fun plainHttpIsRefusedOutsideTests() {
        expectKind(ErrorKind.BAD_REQUEST) { UrlTransport().request("GET", "http://example.com/x", emptyMap(), null, Timeouts()) }
        expectKind(ErrorKind.BAD_REQUEST) { UrlTransport().request("GET", "http://127.0.0.1/x", emptyMap(), null, Timeouts()) }
        expectKind(ErrorKind.BAD_REQUEST) { UrlTransport().request("GET", "file:///etc/passwd", emptyMap(), null, Timeouts()) }
    }

    @Test fun cancelStopsStreaming() = withLoopback {
        val (s, base) = server { ex ->
            ex.sendResponseHeaders(200, 0)
            for (i in 1..20) { ex.responseBody.write("data: $i\n".toByteArray()); ex.responseBody.flush(); Thread.sleep(20) }
        }
        try {
            val lines = ArrayList<String>()
            UrlTransport().stream("$base/s", emptyMap(), "{}", Timeouts(2000, 2000), { lines.size >= 3 }) { lines.add(it) }
            assertEquals(3, lines.size)
        } finally { s.stop(0) }
    }
}
