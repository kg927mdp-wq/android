package app.xion.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.fail
import org.junit.Test

class BackupCodecTest {
    private val pass = "correct horse battery".toCharArray()

    private fun assertFails(block: () -> Unit) {
        try {
            block()
            fail("expected BackupException")
        } catch (e: BackupException) {
            // expected
        }
    }

    @Test fun roundTrip() {
        val blob = BackupCodec.encrypt("""{"keys":{"GEMINI":"AIza-secret-value"}}""", pass)
        assertFalse(blob.contains("secret"))
        assertEquals("""{"keys":{"GEMINI":"AIza-secret-value"}}""", BackupCodec.decrypt(blob, pass))
    }

    @Test fun unicodeAndSurroundingSpace() {
        val blob = BackupCodec.encrypt("مفتاح", pass)
        assertEquals("مفتاح", BackupCodec.decrypt("  $blob\n", pass))
    }

    @Test fun sameInputGivesDifferentBlobs() {
        assertNotEquals(BackupCodec.encrypt("x", pass), BackupCodec.encrypt("x", pass))
    }

    @Test fun wrongPassphraseFails() {
        val blob = BackupCodec.encrypt("x", pass)
        assertFails { BackupCodec.decrypt(blob, "wrong passphrase".toCharArray()) }
    }

    @Test fun shortPassphraseRefused() {
        assertFails { BackupCodec.encrypt("x", "short".toCharArray()) }
    }

    @Test fun tamperedBlobFails() {
        val blob = BackupCodec.encrypt("x", pass)
        val p = blob.split('.').toMutableList()
        p[4] = p[4].dropLast(2) + (if (p[4].endsWith("AA")) "BB" else "AA")
        assertFails { BackupCodec.decrypt(p.joinToString("."), pass) }
    }

    @Test fun garbageFailsCleanly() {
        for (s in listOf("", "hello", "XIONBK1", "XIONBK1.a.b.c.d", "XIONBK0.a.100000.b.c", "x".repeat(70_000))) {
            assertFails { BackupCodec.decrypt(s, pass) }
        }
    }

    @Test fun craftedIterationCountIsRefusedWithoutWork() {
        val blob = BackupCodec.encrypt("x", pass)
        val p = blob.split('.').toMutableList()
        p[2] = "2000000000"
        val t0 = System.nanoTime()
        assertFails { BackupCodec.decrypt(p.joinToString("."), pass) }
        assertFalse("must reject before running PBKDF2", (System.nanoTime() - t0) > 2_000_000_000L)
    }
}
