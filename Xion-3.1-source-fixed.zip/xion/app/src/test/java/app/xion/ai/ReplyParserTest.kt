package app.xion.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReplyParserTest {

    private fun run(vararg chunks: String): Pair<ReplyParser, List<String>> {
        val sentences = ArrayList<String>()
        val p = ReplyParser { sentences.add(it) }
        for (c in chunks) p.feed(c)
        p.finish()
        return Pair(p, sentences)
    }

    @Test fun splitsSentencesAsTheyStream() {
        val (p, s) = run("تمام، ضبطت المنبه. ", "وبعدين شي ثاني؟ ", "اخر جملة")
        assertEquals(listOf("تمام، ضبطت المنبه.", "وبعدين شي ثاني؟", "اخر جملة"), s)
        assertEquals("تمام، ضبطت المنبه. وبعدين شي ثاني؟ اخر جملة", p.spoken.toString())
    }

    @Test fun readsActionLine() {
        val (p, s) = run("تمام.\n@@ACT: {\"type\":\"alarm\",\"hour\":7,\"minute\":0}")
        assertEquals(listOf("تمام."), s)
        assertEquals(1, p.actions.size)
        assertEquals("alarm", p.actions[0]["type"])
        assertEquals(7L, p.actions[0]["hour"])
    }

    @Test fun actionSplitAcrossChunks() {
        val (p, _) = run("حاضر.\n@@AC", "T: {\"type\":\"cam", "era\"}")
        assertEquals("camera", p.actions.single()["type"])
    }

    @Test fun brokenActionJsonIsDropped() {
        val (p, _) = run("تمام.\n@@ACT: {\"type\":\"alarm\",\"hour\":")
        assertTrue(p.actions.isEmpty())
    }

    @Test fun nonObjectActionIsDropped() {
        val (p, _) = run("x.\n@@ACT: [1,2]\n@@ACT: \"call\"")
        assertTrue(p.actions.isEmpty())
    }

    @Test fun askAndSearch() {
        val (a, _) = run("أي أحمد؟\n@@ASK")
        assertTrue(a.follow)
        val (s, spoken) = run("@@SEARCH: سعر الذهب")
        assertEquals("سعر الذهب", s.search)
        assertTrue(spoken.isEmpty())
        assertFalse(s.follow)
    }

    @Test fun multipleActions() {
        val (p, _) = run("تم.\n@@ACT: {\"type\":\"camera\"}\n@@ACT: {\"type\":\"flashlight\",\"on\":true}")
        assertEquals(2, p.actions.size)
    }

    @Test fun markdownSymbolsAreNotSpoken() {
        val (_, s) = run("**مرحبا** بك.")
        assertEquals(listOf("مرحبا بك."), s)
    }

    @Test fun noSearchWhenNotAsked() {
        assertNull(run("جواب عادي.").first.search)
    }
}
