package app.xion.ai

import app.xion.ai.orchestrator.FakeAdapter
import app.xion.ai.orchestrator.FakeSettings
import app.xion.ai.orchestrator.Harness
import app.xion.ai.provider.ErrorKind
import app.xion.ai.provider.Provider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.Executor

class ConversationEngineTest {

    private class Settings(override var mode: String = "fast", override var searchEnabled: Boolean = true) : EngineSettings

    private class Events : BrainListener {
        val sentences = ArrayList<String>()
        val actions = ArrayList<Pair<Map<String, Any?>, Boolean>>()
        var done = 0
        var follow = false
        val failures = ArrayList<String>()
        val corrections = ArrayList<String>()
        val searching = ArrayList<String>()
        var cancelled = false
        override fun isCancelled() = cancelled
        override fun onSearching(query: String) { searching.add(query) }
        override fun onSentence(text: String) { sentences.add(text) }
        override fun onAction(action: Map<String, Any?>, tainted: Boolean) { actions.add(Pair(action, tainted)) }
        override fun onDone(followUp: Boolean) { done++; follow = followUp }
        override fun onCorrection(text: String) { corrections.add(text) }
        override fun onFailure(message: String) { failures.add(message) }
    }

    private val direct = Executor { it.run() }
    private var searchCalls = ArrayList<String>()
    private var searchText = "SEARCH RESULTS: gold 100"

    private fun env(vararg ps: Provider, mode: String = "fast"): Triple<ConversationEngine, Harness, Settings> {
        val fs = FakeSettings().setup(*ps)
        fs.primary = ps.firstOrNull()
        val h = Harness(fs)
        val st = Settings(mode)
        val e = ConversationEngine(h.orch, st, { q -> searchCalls.add(q); searchText }, direct, direct, { 42L })
        return Triple(e, h, st)
    }

    private fun say(h: Harness, p: Provider, vararg pieces: String) = h.a(p).script.add(FakeAdapter.Act.Say(pieces.toList()))

    // ---- the acceptance criteria of the text chat feature

    @Test fun typedMessageGetsATextAnswerWithoutAnyMicrophone() {
        val (e, h, _) = env(Provider.GROQ)
        say(h, Provider.GROQ, "Hello Ali. ", "How can I help?")
        assertTrue(e.submit("hi", Source.TEXT))
        val s = e.snapshot()
        assertEquals(EngineState.IDLE, s.state)
        assertEquals(listOf(Role.USER, Role.ASSISTANT), s.messages.map { it.role })
        assertEquals("hi", s.messages[0].text); assertEquals(Source.TEXT, s.messages[0].source)
        assertEquals("Hello Ali. How can I help?", s.messages[1].text)
        assertEquals(MsgStatus.DONE, s.messages[1].status)
        assertEquals("Groq", s.messages[1].provider)
    }

    @Test fun voiceContinuesTheSameConversationAsText() {
        val (e, h, _) = env(Provider.GROQ)
        say(h, Provider.GROQ, "Nice to meet you Ali.")
        say(h, Provider.GROQ, "Your name is Ali.")
        e.submit("my name is Ali", Source.TEXT)
        e.submit("what is my name", Source.VOICE)
        val second = h.a(Provider.GROQ).allCalls[1]
        assertTrue(second.any { it.role == "user" && it.content.endsWith("my name is Ali") })
        assertTrue(second.any { it.role == "assistant" && it.content.contains("Nice to meet you Ali.") })
        assertTrue(second.last().content.contains("spoken"))           // the model is told this one was spoken
        assertTrue(h.a(Provider.GROQ).allCalls[0].last().content.contains("typed"))
        val s = e.snapshot().messages
        assertEquals(listOf(Source.TEXT, Source.TEXT, Source.VOICE, Source.VOICE), s.map { it.source })
        assertEquals(4, s.size)
    }

    @Test fun emptyAndWhitespaceMessagesAreIgnored() {
        val (e, h, _) = env(Provider.GROQ)
        assertFalse(e.submit("", Source.TEXT)); assertFalse(e.submit("  \n\t ", Source.TEXT))
        assertTrue(e.snapshot().messages.isEmpty()); assertEquals(0, h.a(Provider.GROQ).calls)
    }

    @Test fun doubleSubmitWhileBusyIsRefusedAndSendsOneRequest() {
        val (e, h, _) = env(Provider.GROQ)
        var second: Boolean? = null
        h.a(Provider.GROQ).onCall = { second = e.submit("again", Source.TEXT); h.a(Provider.GROQ).onCall = null }
        e.submit("hello", Source.TEXT)
        assertEquals(false, second)
        assertEquals(1, h.a(Provider.GROQ).calls)
        assertEquals(2, e.snapshot().messages.size)
    }

    @Test fun spokenInterruptionCancelsTheRunningTurn() {
        val (e, h, _) = env(Provider.GROQ)
        // the interrupting turn runs inline inside the first call, so it consumes the first scripted answer
        say(h, Provider.GROQ, "second answer.")
        say(h, Provider.GROQ, "first answer that gets cut")
        val ev1 = Events()
        var inner: Boolean? = null
        var fired = false
        h.a(Provider.GROQ).onCall = { if (!fired) { fired = true; inner = e.submit("new question", Source.VOICE, Events(), interrupt = true) } }
        e.submit("old question", Source.TEXT, ev1)
        assertEquals(true, inner)
        assertEquals(0, ev1.done)                                   // the cancelled turn never completes
        val msgs = e.snapshot().messages
        assertEquals("second answer.", msgs.last().text)
        assertEquals(1, msgs.count { it.role == Role.ASSISTANT && it.text.isNotBlank() })
        e.submit("third", Source.TEXT)
        val third = h.a(Provider.GROQ).allCalls.last()
        assertFalse(third.any { it.content.contains("first answer") }) // an interrupted answer never enters the context
    }

    @Test fun errorStateThenRetrySucceeds() {
        val (e, h, _) = env(Provider.GROQ)
        h.a(Provider.GROQ).script.add(FakeAdapter.Act.Err(ErrorKind.AUTH, 401))
        val ev = Events()
        e.submit("hello", Source.TEXT, ev)
        val s = e.snapshot()
        assertEquals(MsgStatus.ERROR, s.messages.last().status)
        assertTrue(s.messages.last().error!!.contains("المفتاح"))
        assertEquals(1, ev.failures.size)
        assertEquals(EngineState.IDLE, s.state)
        h.stats.resetHealth(Provider.GROQ)
        say(h, Provider.GROQ, "Recovered.")
        assertTrue(e.retry())
        val after = e.snapshot().messages
        assertEquals(listOf("hello", "Recovered."), after.map { it.text })      // no duplicate user bubble
        assertFalse(e.retry())                                                  // nothing left to retry
    }

    @Test fun failedTurnIsNotRememberedAsContext() {
        val (e, h, _) = env(Provider.GROQ)
        h.a(Provider.GROQ).script.add(FakeAdapter.Act.Err(ErrorKind.BAD_REQUEST, 400))
        h.a(Provider.GROQ).script.add(FakeAdapter.Act.Err(ErrorKind.BAD_REQUEST, 400))
        e.submit("lost message", Source.TEXT)
        say(h, Provider.GROQ, "ok")
        e.submit("next", Source.TEXT)
        assertFalse(h.a(Provider.GROQ).lastMessages.any { it.content.contains("lost message") })
    }

    @Test fun missingKeyExplainsInsteadOfCallingAnything() {
        val (e, h, _) = env()
        e.submit("hello", Source.TEXT)
        val m = e.snapshot().messages.last()
        assertEquals(MsgStatus.ERROR, m.status); assertTrue(m.error!!.contains("مفتاح"))
    }

    @Test fun clearRemovesScreenAndModelContext() {
        val (e, h, _) = env(Provider.GROQ)
        e.submit("secret plan", Source.TEXT)
        e.clear()
        assertTrue(e.snapshot().messages.isEmpty())
        e.submit("hello", Source.TEXT)
        assertFalse(h.a(Provider.GROQ).lastMessages.any { it.content.contains("secret plan") })
    }

    @Test fun contextIsBounded() {
        val (e, h, _) = env(Provider.GROQ)
        repeat(30) { e.submit("question $it " + "x".repeat(900), Source.TEXT) }
        val sent = h.a(Provider.GROQ).lastMessages
        assertTrue(sent.sumOf { it.content.length } < ConversationEngine.MAX_HISTORY_CHARS + 20_000)
        assertTrue(sent.count { it.role == "user" } <= ConversationEngine.MAX_TURNS + 1)
        assertEquals(60, e.snapshot().messages.size)                              // the screen keeps everything
    }

    @Test fun veryLongInputIsCut() {
        val (e, _, _) = env(Provider.GROQ)
        e.submit("y".repeat(20_000), Source.TEXT)
        assertEquals(ConversationEngine.MAX_INPUT, e.snapshot().messages[0].text.length)
    }

    @Test fun bubbleGrowsWhileStreaming() {
        val (e, h, _) = env(Provider.GROQ)
        say(h, Provider.GROQ, "Hel", "lo wor", "ld. Bye")
        val seen = ArrayList<String>()
        h.a(Provider.GROQ).onCall = null
        e.subscribe { seen.add(e.snapshot().messages.lastOrNull { it.role == Role.ASSISTANT }?.text ?: "") }
        e.submit("x", Source.TEXT)
        assertTrue(seen.contains("Hel")); assertTrue(seen.contains("Hello wor")); assertEquals("Hello world. Bye", seen.last())
    }

    // ---- security: the same pipeline for both inputs

    @Test fun actionsAreOnlyProposalsAndCarryTheTaintFlag() {
        val (e, h, _) = env(Provider.GROQ)
        say(h, Provider.GROQ, "تمام.\n@@ACT: {\"type\":\"alarm\",\"hour\":7,\"minute\":0}")
        val ev = Events()
        e.submit("نبهني الساعة سبعة", Source.TEXT, ev)
        assertEquals(1, ev.actions.size)
        assertEquals("alarm", ev.actions[0].first["type"]); assertFalse(ev.actions[0].second)
    }

    @Test fun actionAfterWebSearchIsMarkedTainted() {
        val (e, h, _) = env(Provider.GROQ)
        say(h, Provider.GROQ, "@@SEARCH: gold price")
        say(h, Provider.GROQ, "Gold is 100.\n@@ACT: {\"type\":\"call\",\"to\":\"123456\"}")
        val ev = Events()
        e.submit("gold price", Source.TEXT, ev)
        assertEquals(listOf("gold price"), searchCalls); assertEquals(listOf("gold price"), ev.searching)
        assertEquals(true, ev.actions.single().second)
        val second = h.a(Provider.GROQ).lastMessages
        assertTrue(second.last().content.contains("untrusted external data"))
        assertTrue(second.last().content.contains("gold 100"))
        assertEquals("Gold is 100.", e.snapshot().messages.last().text)
    }

    @Test fun searchDisabledNeverSearches() {
        val (e, h, st) = env(Provider.GROQ)
        st.searchEnabled = false
        say(h, Provider.GROQ, "@@SEARCH: x")
        e.submit("price?", Source.TEXT, Events())
        assertTrue(searchCalls.isEmpty())
        assertTrue(e.snapshot().messages.last().text.isNotBlank())
    }

    // ---- cross-model review, measured

    @Test fun carefulModeReplacesDraftWithReviewedAnswerFromAnotherProvider() {
        val (e, h, _) = env(Provider.DEEPSEEK, Provider.GEMINI, mode = "careful")
        say(h, Provider.DEEPSEEK, "Paris is in Germany.")
        say(h, Provider.GEMINI, "Paris is in France.")
        val ev = Events()
        e.submit("where is Paris", Source.TEXT, ev)
        assertEquals(listOf("Paris is in France."), ev.sentences)
        assertEquals("Paris is in France.", e.snapshot().messages.last().text)
        assertEquals(1, h.stats.snapshot(Provider.DEEPSEEK).reviews); assertEquals(1, h.stats.snapshot(Provider.DEEPSEEK).reviewFixes)
        assertEquals(1, h.a(Provider.DEEPSEEK).calls)               // the draft model is never asked to review itself
    }

    @Test fun carefulModeKeepsTheDraftWhenNobodyCanReview() {
        val (e, h, _) = env(Provider.DEEPSEEK, mode = "careful")
        say(h, Provider.DEEPSEEK, "Draft answer.")
        e.submit("q", Source.TEXT, Events())
        assertEquals("Draft answer.", e.snapshot().messages.last().text)
    }

    @Test fun instantModeAddsACorrectionNoteOnlyWhenTheCheckerIsSure() {
        val (e, h, _) = env(Provider.DEEPSEEK, Provider.GEMINI, mode = "instant")
        val long = "This is a fairly long answer that is certainly longer than forty characters."
        say(h, Provider.DEEPSEEK, long)
        say(h, Provider.GEMINI, "FIX: Actually it is shorter.")
        val ev = Events()
        e.submit("q", Source.TEXT, ev)
        assertEquals(listOf("Actually it is shorter."), ev.corrections)
        assertTrue(e.snapshot().messages.any { it.role == Role.NOTE && it.text.contains("Actually it is shorter.") })
        e.submit("q2", Source.TEXT, ev)                                     // history keeps the correction for the model
        assertTrue(h.a(Provider.DEEPSEEK).lastMessages.any { it.content.contains("(Correction: Actually it is shorter.)") })

        val (e2, h2, _) = env(Provider.DEEPSEEK, Provider.GEMINI, mode = "instant")
        say(h2, Provider.DEEPSEEK, long); say(h2, Provider.GEMINI, "OK")
        val ev2 = Events(); e2.submit("q", Source.TEXT, ev2)
        assertTrue(ev2.corrections.isEmpty())
        assertEquals(0, h2.stats.snapshot(Provider.DEEPSEEK).reviewFixes)
        assertEquals(1, h2.stats.snapshot(Provider.DEEPSEEK).reviews)
    }

    @Test fun notesAreKeptButNeverSentToTheModel() {
        val (e, h, _) = env(Provider.GROQ)
        e.addNote("تم فتح الكاميرا")
        e.submit("hi", Source.TEXT)
        assertFalse(h.a(Provider.GROQ).lastMessages.any { it.content.contains("تم فتح الكاميرا") })
        assertEquals(Role.NOTE, e.snapshot().messages.first().role)
    }

    @Test fun cutOffAnswerIsKeptAndFlagged() {
        val (e, h, _) = env(Provider.GROQ)
        h.a(Provider.GROQ).script.add(FakeAdapter.Act.Err(ErrorKind.NETWORK, -1, after = listOf("Half an answer")))
        e.submit("q", Source.TEXT, Events())
        val m = e.snapshot().messages.last()
        assertEquals("Half an answer", m.text); assertEquals(MsgStatus.DONE, m.status); assertNotEquals(null, m.error)
    }
}
