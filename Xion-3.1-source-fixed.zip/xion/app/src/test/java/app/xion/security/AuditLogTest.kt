package app.xion.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class AuditLogTest {
    private fun tmp(): File = File.createTempFile("audit", ".log").also { it.delete(); it.deleteOnExit() }

    @Test fun recordsAndReturnsNewestFirst() {
        var t = 1000L
        val log = AuditLog(tmp()) { t++ }
        log.record("call", AuditLog.ASKED, "to=Ahmed")
        log.record("call", AuditLog.CONFIRMED, "to=Ahmed")
        val r = log.recent(10)
        assertEquals(listOf(AuditLog.CONFIRMED, AuditLog.ASKED), r.map { it.outcome })
        assertEquals(1001L, r[0].time)
    }

    @Test fun secretsAreScrubbed() {
        val log = AuditLog(tmp())
        log.record("x", AuditLog.FAILED, "provider said: bad key sk-abcdefghijklmnopqrstuvwxyz1234")
        assertFalse(log.recent(1)[0].note.contains("sk-abcdef"))
    }

    @Test fun missingFileIsEmpty() {
        assertTrue(AuditLog(tmp()).recent(5).isEmpty())
    }

    @Test fun corruptLinesAreSkipped() {
        val f = tmp()
        f.writeText("garbage\n{not json}\n")
        val log = AuditLog(f)
        log.record("camera", AuditLog.EXECUTED, "")
        assertEquals(1, log.recent(10).size)
    }

    @Test fun fileIsCapped() {
        val f = tmp()
        val log = AuditLog(f)
        val note = "n".repeat(150)
        repeat(2000) { log.record("open_app", AuditLog.EXECUTED, note) }
        assertTrue("size=" + f.length(), f.length() < AuditLog.MAX_BYTES + 1000)
        assertTrue(log.recent(5).isNotEmpty())
    }

    @Test fun clearRemovesHistory() {
        val log = AuditLog(tmp())
        log.record("camera", AuditLog.EXECUTED, "")
        log.clear()
        assertTrue(log.recent(5).isEmpty())
    }

    @Test fun unwritableLocationNeverThrows() {
        AuditLog(File("/proc/definitely/not/writable.log")).record("camera", AuditLog.EXECUTED, "")
    }
}
