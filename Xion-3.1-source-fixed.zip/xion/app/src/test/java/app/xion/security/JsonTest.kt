package app.xion.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class JsonTest {
    @Test fun parsesObject() {
        val m = Json.parseObject("""{"a":1,"b":"x","c":[1,2,{"d":true}],"e":null,"f":1.5}""")!!
        assertEquals(1L, m["a"])
        assertEquals("x", m["b"])
        assertEquals(listOf<Any?>(1L, 2L, mapOf("d" to true)), m["c"])
        assertTrue(m.containsKey("e"))
        assertEquals(1.5, m["f"])
    }

    @Test fun escapes() {
        val m = Json.parseObject("""{"a":"q\"\\\n\u0041\u0627"}""")!!
        assertEquals("q\"\\\nAا", m["a"])
    }

    @Test fun malformedReturnsNull() {
        for (s in listOf("", "{", "{\"a\":}", "{\"a\":1,}", "[1,2]x", "{\"a\":1} trailing", "{a:1}", "nope", "{\"a\":\"\\q\"}", "{\"a\":01x}")) {
            assertNull("should fail: $s", Json.parseObject(s))
        }
    }

    @Test fun nonObjectRootIsNotAnObject() {
        assertNull(Json.parseObject("[1,2]"))
        assertNull(Json.parseObject("5"))
    }

    @Test fun depthIsLimited() {
        assertNull(Json.parseObject("""{"a":""" + "[".repeat(50) + "]".repeat(50) + "}"))
    }

    @Test fun sizeIsLimited() {
        assertNull(Json.parseObject("""{"a":"${"x".repeat(Json.MAX_LENGTH)}"}"""))
    }

    @Test fun keyCountIsLimited() {
        val big = (1..100).joinToString(",", "{", "}") { "\"k$it\":1" }
        assertNull(Json.parseObject(big))
    }

    @Test fun stringifyRoundTrip() {
        val src = mapOf("a" to 1, "b" to "x\"y\n", "c" to listOf(1, "z", null), "d" to mapOf("e" to true), "f" to 2L)
        val back = Json.parseObject(Json.stringify(src))!!
        assertEquals(1L, back["a"])
        assertEquals("x\"y\n", back["b"])
        assertEquals(listOf<Any?>(1L, "z", null), back["c"])
        assertEquals(mapOf("e" to true), back["d"])
    }

    @Test fun stringifyEscapesControlCharacters() {
        assertEquals("\"\\u0001\"", Json.stringify("\u0001"))
    }
}
