package app.xion.ai.orchestrator

import app.xion.ai.provider.ErrorKind
import app.xion.ai.provider.ModelInfo
import app.xion.ai.provider.Provider
import app.xion.ai.provider.ProviderError
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RouterTest {
    private var now = 1_000_000L
    private val stats = ProviderStats { now }
    private val chat = TaskProfile(TaskType.CHAT, 100, false)
    private val reasoning = TaskProfile(TaskType.REASONING, 100, false)

    private fun cand(p: Provider, info: ModelInfo? = null, free: Boolean = false) = Candidate(p, "m-" + p.name, info, free)
    private val three = listOf(cand(Provider.DEEPSEEK), cand(Provider.GEMINI), cand(Provider.GROK))
    private fun order(l: List<Candidate>) = l.map { it.provider }
    private fun rank(s: Strategy, p: TaskProfile = chat, list: List<Candidate> = three, primary: Provider? = Provider.GROK, route: Provider? = null) =
        order(Router.rank(p, list, s, primary, route, stats))

    @Test fun manualPutsPrimaryFirstThenEnumOrder() {
        assertEquals(listOf(Provider.GROK, Provider.DEEPSEEK, Provider.GEMINI), rank(Strategy.MANUAL))
    }

    @Test fun speedUsesMeasuredLatencyAndUnmeasuredGoLast() {
        stats.recordSuccess(Provider.DEEPSEEK, 900, 2000, 10, 10)
        stats.recordSuccess(Provider.GEMINI, 200, 1000, 10, 10)
        assertEquals(listOf(Provider.GEMINI, Provider.DEEPSEEK, Provider.GROK), rank(Strategy.SPEED))
    }

    @Test fun autoIsFastestForChatButPrimaryForReasoning() {
        stats.recordSuccess(Provider.DEEPSEEK, 900, 2000, 10, 10)
        stats.recordSuccess(Provider.GEMINI, 200, 1000, 10, 10)
        assertEquals(Provider.GEMINI, rank(Strategy.AUTO, chat).first())
        assertEquals(Provider.GROK, rank(Strategy.AUTO, reasoning).first())
    }

    @Test fun autoReasoningBreaksTiesBySuccessRate() {
        stats.recordSuccess(Provider.DEEPSEEK, 1, 1, 1, 1)
        stats.recordSuccess(Provider.GEMINI, 1, 1, 1, 1)
        stats.recordFailure(Provider.GEMINI, ProviderError(Provider.GEMINI, ErrorKind.BAD_REQUEST, 400, "x")) // no cool-down, but a failure
        assertEquals(listOf(Provider.GROK, Provider.DEEPSEEK, Provider.GEMINI), rank(Strategy.AUTO, reasoning))
    }

    @Test fun costPrefersFreeThenCheapestThenUnknown() {
        val l = listOf(
            cand(Provider.DEEPSEEK, ModelInfo("a", promptPrice = 0.000002, completionPrice = 0.000004)),
            cand(Provider.GEMINI, ModelInfo("b", promptPrice = 0.0, completionPrice = 0.0)),
            cand(Provider.GROK),
            cand(Provider.GROQ, ModelInfo("c", promptPrice = 0.0000005, completionPrice = 0.000001))
        )
        assertEquals(listOf(Provider.GEMINI, Provider.GROQ, Provider.DEEPSEEK, Provider.GROK), rank(Strategy.COST, list = l))
    }

    @Test fun freeOnlyKeepsOnlyWhatIsProvablyOrDeclaredFree() {
        val l = listOf(
            cand(Provider.DEEPSEEK),
            cand(Provider.OPENROUTER, ModelInfo("x:free", promptPrice = 0.0, completionPrice = 0.0)),
            cand(Provider.GROQ, free = true),
            cand(Provider.GROK, ModelInfo("p", promptPrice = 0.1, completionPrice = 0.1))
        )
        assertEquals(setOf(Provider.OPENROUTER, Provider.GROQ), rank(Strategy.FREE_ONLY, list = l).toSet())
        assertTrue(rank(Strategy.FREE_ONLY, list = three).isEmpty())
    }

    @Test fun taskRouteOverridesStrategy() {
        stats.recordSuccess(Provider.GEMINI, 100, 100, 1, 1)
        for (s in listOf(Strategy.MANUAL, Strategy.SPEED, Strategy.AUTO, Strategy.COST)) {
            assertEquals("$s", Provider.DEEPSEEK, rank(s, route = Provider.DEEPSEEK).first())
        }
    }

    @Test fun coolingProvidersGoLastButStayAvailable() {
        stats.recordFailure(Provider.GROK, ProviderError(Provider.GROK, ErrorKind.SERVER, 500, "x"))
        assertEquals(listOf(Provider.DEEPSEEK, Provider.GEMINI, Provider.GROK), rank(Strategy.MANUAL))
        assertEquals(3, rank(Strategy.MANUAL).size)
    }

    @Test fun modelsTooSmallForTheRequestGoLast() {
        val big = TaskProfile(TaskType.CHAT, 9000, true)
        val l = listOf(cand(Provider.DEEPSEEK, ModelInfo("a", contextLength = 8000)), cand(Provider.GEMINI, ModelInfo("b", contextLength = 128000)))
        assertEquals(listOf(Provider.GEMINI, Provider.DEEPSEEK), rank(Strategy.MANUAL, big, l, Provider.DEEPSEEK))
    }
}
