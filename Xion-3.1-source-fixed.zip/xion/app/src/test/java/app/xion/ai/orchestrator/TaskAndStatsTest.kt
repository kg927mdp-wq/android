package app.xion.ai.orchestrator

import app.xion.ai.provider.ErrorKind
import app.xion.ai.provider.Provider
import app.xion.ai.provider.ProviderError
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TaskAndStatsTest {
    private fun type(s: String, hist: Int = 0) = TaskAnalyzer.analyze(s, hist).type

    @Test fun classifiesArabicAndEnglish() {
        assertEquals(TaskType.COMMAND, type("افتح الكاميرا"))
        assertEquals(TaskType.COMMAND, type("نبهني الساعة سبعة"))
        assertEquals(TaskType.COMMAND, type("open youtube"))
        assertEquals(TaskType.LIVE_INFO, type("شكد سعر الذهب اليوم"))
        assertEquals(TaskType.LIVE_INFO, type("what is the weather in Baghdad"))
        assertEquals(TaskType.CODE, type("اكتب كود بايثون يقرأ ملف"))
        assertEquals(TaskType.CODE, type("fix this kotlin function"))
        assertEquals(TaskType.REASONING, type("قارن بين الخيارين وحلل المزايا"))
        assertEquals(TaskType.REASONING, type("x".repeat(400)))
        assertEquals(TaskType.CHAT, type("شلونك"))
    }

    @Test fun longContextIsFlaggedFromHistorySize() {
        assertFalse(TaskAnalyzer.analyze("hi", 100).longContext)
        assertTrue(TaskAnalyzer.analyze("hi", 40_000).longContext)
    }

    private val now = longArrayOf(0)
    private fun err(k: ErrorKind, retry: Int? = null) = ProviderError(Provider.GROQ, k, 0, "x", retry)

    @Test fun latencyIsSmoothed() {
        val s = ProviderStats { now[0] }
        s.recordSuccess(Provider.GROQ, 100, 1000, 40, 80)
        s.recordSuccess(Provider.GROQ, 200, 2000, 40, 80)
        val snap = s.snapshot(Provider.GROQ)
        assertEquals(130.0, snap.avgFirstTokenMs!!, 0.001)
        assertEquals(1300.0, snap.avgTotalMs!!, 0.001)
        assertEquals(20L, snap.estTokensIn); assertEquals(40L, snap.estTokensOut)
        assertEquals(1.0, snap.successRate!!, 0.0)
    }

    @Test fun cooldownGrowsWithRepeatedFailuresAndClearsOnSuccess() {
        val s = ProviderStats { now[0] }
        now[0] = 1000
        s.recordFailure(Provider.GROQ, err(ErrorKind.SERVER))
        assertEquals(1000 + 15_000L, s.snapshot(Provider.GROQ).cooldownUntil)
        s.recordFailure(Provider.GROQ, err(ErrorKind.SERVER))
        assertEquals(1000 + 30_000L, s.snapshot(Provider.GROQ).cooldownUntil)
        assertTrue(s.isCoolingDown(Provider.GROQ))
        s.recordSuccess(Provider.GROQ, 1, 1, 1, 1)
        assertFalse(s.isCoolingDown(Provider.GROQ))
    }

    @Test fun rateLimitHonoursRetryAfter_badRequestDoesNotCoolDown() {
        val s = ProviderStats { now[0] }
        now[0] = 0
        s.recordFailure(Provider.GROQ, err(ErrorKind.RATE_LIMIT, 42))
        assertEquals(42_000L, s.snapshot(Provider.GROQ).cooldownUntil)
        s.resetHealth(Provider.GROQ)
        s.recordFailure(Provider.GROQ, err(ErrorKind.BAD_REQUEST))
        assertFalse(s.isCoolingDown(Provider.GROQ))
        assertEquals(2, s.snapshot(Provider.GROQ).fail)
    }

    @Test fun persistsMeasurementsAsJson() {
        val s = ProviderStats { now[0] }
        s.recordSuccess(Provider.GEMINI, 150, 900, 40, 40)
        s.recordReview(Provider.GEMINI, true)
        val t = ProviderStats { now[0] }
        t.loadJson(s.toJson())
        val a = t.snapshot(Provider.GEMINI)
        assertEquals(1, a.ok); assertEquals(150.0, a.avgFirstTokenMs!!, 0.001); assertEquals(1, a.reviewFixes)
        t.loadJson("garbage")
        assertNull(t.snapshot(Provider.GROK).avgTotalMs)
    }
}
