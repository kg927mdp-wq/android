package app.xion.ai.provider

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class OpenAiCompatAdapterTest {
    private val ft = FakeTransport()
    private var now = 0L
    private fun adapter(p: Provider = Provider.GROQ) = OpenAiCompatAdapter(p, ft) { now.also { now += 100 } }
    private val msgs = listOf(ChatMsg("system", "s"), ChatMsg("user", "hi"))
    private val to = Timeouts()

    private fun expectError(kind: ErrorKind, block: () -> Unit): ProviderError {
        try {
            block()
        } catch (e: ProviderError) {
            assertEquals(kind, e.kind)
            return e
        }
        fail("expected ProviderError $kind")
        throw IllegalStateException()
    }

    @Test fun streamsDeltasAndIgnoresCommentsAndDone() {
        ft.steps.add(FakeTransport.Step.Sse(listOf(": keep-alive") + sse("Hel", "lo") ))
        val got = ArrayList<String>()
        val out = adapter().stream("k", "m", msgs, to, { false }) { got.add(it) }
        assertEquals(listOf("Hel", "lo"), got)
        assertEquals("Hello", out.text)
        assertTrue(out.firstTokenMs > 0)
    }

    @Test fun requestCarriesKeyInHeaderOnly() {
        ft.steps.add(FakeTransport.Step.Sse(sse("ok")))
        adapter().stream("SECRET-KEY-123", "model-x", msgs, to, { false }) {}
        val c = ft.calls.single()
        assertEquals("Bearer SECRET-KEY-123", c.headers["Authorization"])
        assertFalse(c.body!!.contains("SECRET-KEY-123"))
        assertTrue(c.body!!.contains("\"model\":\"model-x\""))
        assertTrue(c.body!!.contains("\"stream\":true"))
        assertEquals(Provider.GROQ.url, c.url)
    }

    @Test fun deepseekKeepsItsTwoPointOneParameters() {
        ft.steps.add(FakeTransport.Step.Sse(sse("ok")))
        adapter(Provider.DEEPSEEK).stream("k", "deepseek-chat", msgs, to, { false }) {}
        assertTrue(ft.calls.single().body!!.contains("\"temperature\":0.3"))
        assertTrue(ft.calls.single().body!!.contains("\"max_tokens\":2000"))
        ft.steps.add(FakeTransport.Step.Sse(sse("ok")))
        adapter(Provider.GROQ).stream("k", "m", msgs, to, { false }) {}
        assertFalse(ft.calls.last().body!!.contains("temperature"))
    }

    @Test fun openRouterSendsAppTitle() {
        ft.steps.add(FakeTransport.Step.Sse(sse("ok")))
        adapter(Provider.OPENROUTER).stream("k", "m", msgs, to, { false }) {}
        assertEquals("Xion", ft.calls.single().headers["X-Title"])
        assertEquals("https://openrouter.ai/api/v1/chat/completions", ft.calls.single().url)
    }

    @Test fun httpErrorsAreNormalised() {
        val table = mapOf(401 to ErrorKind.AUTH, 403 to ErrorKind.AUTH, 402 to ErrorKind.QUOTA, 404 to ErrorKind.MODEL_NOT_FOUND,
            429 to ErrorKind.RATE_LIMIT, 400 to ErrorKind.BAD_REQUEST, 500 to ErrorKind.SERVER, 503 to ErrorKind.SERVER, 418 to ErrorKind.UNKNOWN)
        for ((code, kind) in table) {
            ft.steps.add(FakeTransport.Step.Reply(code, "{\"error\":{\"message\":\"boom\"}}"))
            expectError(kind) { adapter().stream("k", "m", msgs, to, { false }) {} }
        }
    }

    @Test fun retryAfterIsRead() {
        ft.steps.add(FakeTransport.Step.Reply(429, "{}", mapOf("retry-after" to "7")))
        val e = expectError(ErrorKind.RATE_LIMIT) { adapter().stream("k", "m", msgs, to, { false }) {} }
        assertEquals(7, e.retryAfterSec)
        assertTrue(e.transient)
    }

    @Test fun errorTextNeverLeaksKeys() {
        ft.steps.add(FakeTransport.Step.Reply(401, "{\"error\":{\"message\":\"Incorrect API key provided: sk-abcdefghijklmnopqrstuvwxyz123456\"}}"))
        val e = expectError(ErrorKind.AUTH) { adapter().stream("k", "m", msgs, to, { false }) {} }
        assertFalse(e.message!!.contains("sk-abcdef"))
        assertFalse(e.describe().contains("sk-abcdef"))
    }

    @Test fun networkAndTimeoutBecomeProviderErrors() {
        ft.steps.add(FakeTransport.Step.Fail(ErrorKind.NETWORK))
        expectError(ErrorKind.NETWORK) { adapter().stream("k", "m", msgs, to, { false }) {} }
        ft.steps.add(FakeTransport.Step.Fail(ErrorKind.TIMEOUT))
        expectError(ErrorKind.TIMEOUT) { adapter().complete("k", "m", msgs, to) }
    }

    @Test fun emptyStreamIsAnError() {
        ft.steps.add(FakeTransport.Step.Sse(listOf("data: [DONE]")))
        expectError(ErrorKind.EMPTY) { adapter().stream("k", "m", msgs, to, { false }) {} }
    }

    @Test fun midStreamErrorBeforeAnyTextFails_afterTextKeepsText() {
        ft.steps.add(FakeTransport.Step.Sse(listOf("data: {\"error\":{\"message\":\"upstream\"}}")))
        expectError(ErrorKind.SERVER) { adapter().stream("k", "m", msgs, to, { false }) {} }
        ft.steps.add(FakeTransport.Step.Sse(sse("part") + listOf("data: {\"error\":{\"message\":\"upstream\"}}")))
        assertEquals("part", adapter().stream("k", "m", msgs, to, { false }) {}.text)
    }

    @Test fun malformedChunksAreSkipped() {
        ft.steps.add(FakeTransport.Step.Sse(listOf("data: {not json", "data: {\"choices\":[]}") + sse("fine")))
        assertEquals("fine", adapter().stream("k", "m", msgs, to, { false }) {}.text)
    }

    @Test fun reasoningTokensAreNotSpoken() {
        ft.steps.add(FakeTransport.Step.Sse(listOf(
            "data: {\"choices\":[{\"delta\":{\"reasoning_content\":\"thinking...\"}}]}",
            "data: {\"choices\":[{\"delta\":{\"content\":\"answer\"}}]}")))
        assertEquals("answer", adapter().stream("k", "m", msgs, to, { false }) {}.text)
    }

    @Test fun cancelledStreamStopsReading() {
        ft.steps.add(FakeTransport.Step.Sse(sse("a", "b", "c")))
        val got = ArrayList<String>()
        var n = 0
        adapter().stream("k", "m", msgs, to, { n++ > 2 }) { got.add(it) }
        assertTrue(got.size < 3)
    }

    @Test fun completeParsesTextAndUsage() {
        ft.steps.add(FakeTransport.Step.Reply(200, "{\"choices\":[{\"message\":{\"content\":\"OK\"}}],\"usage\":{\"prompt_tokens\":12,\"completion_tokens\":3}}"))
        val c = adapter().complete("k", "m", msgs, to)
        assertEquals("OK", c.text)
        assertEquals(Usage(12, 3), c.usage)
        assertFalse(ft.calls.single().body!!.contains("\"stream\":true"))
    }

    @Test fun completeWithoutContentIsEmptyError() {
        ft.steps.add(FakeTransport.Step.Reply(200, "{\"choices\":[{\"message\":{\"content\":null}}]}"))
        expectError(ErrorKind.EMPTY) { adapter().complete("k", "m", msgs, to) }
    }

    @Test fun listModelsReadsOpenRouterMetadata() {
        ft.steps.add(FakeTransport.Step.Reply(200, """{"data":[
          {"id":"a/free-model:free","name":"Free","context_length":32768,"pricing":{"prompt":"0","completion":"0"},
           "supported_parameters":["tools","temperature"],"architecture":{"input_modalities":["text","image"]}},
          {"id":"b/paid","context_length":8000,"pricing":{"prompt":"0.000001","completion":"0.000002"},"supported_parameters":["temperature"]},
          {"id":"c/nometa"},
          {"name":"no id"}, 5
        ]}"""))
        val l = adapter(Provider.OPENROUTER).listModels("k", to)
        assertEquals(listOf("a/free-model:free", "b/paid", "c/nometa"), l.map { it.id })
        val free = l[0]
        assertTrue(free.isFree); assertEquals(true, free.supportsTools); assertEquals(true, free.supportsVision); assertEquals(32768, free.contextLength)
        val paid = l[1]
        assertFalse(paid.isFree); assertEquals(false, paid.supportsTools); assertEquals(3.0, paid.pricePerMillion!!, 1e-9)
        val none = l[2]
        assertNull(none.supportsTools); assertNull(none.contextLength); assertFalse(none.isFree)
        assertEquals("GET", ft.calls.single().method)
        assertEquals("https://openrouter.ai/api/v1/models", ft.calls.single().url)
    }

    @Test fun listModelsAcceptsTopLevelArrayAndContextWindow() {
        ft.steps.add(FakeTransport.Step.Reply(200, """[{"id":"x","context_window":131072}]"""))
        val l = adapter(Provider.TOGETHER).listModels("k", to)
        assertEquals(131072, l.single().contextLength)
    }

    @Test fun listModelsFailuresAreReported() {
        ft.steps.add(FakeTransport.Step.Reply(401, "{}"))
        expectError(ErrorKind.AUTH) { adapter().listModels("k", to) }
        ft.steps.add(FakeTransport.Step.Reply(200, "not json"))
        expectError(ErrorKind.EMPTY) { adapter().listModels("k", to) }
    }

    @Test fun onlyOpenRouterIsMarkedAsDocsChecked() {
        assertEquals(listOf(Provider.OPENROUTER), Provider.values().filter { it.docsChecked })
        for (p in Provider.values()) assertTrue(p.url.startsWith("https://"))
    }

    @Test fun newProvidersHaveNoHardcodedModel() {
        for (p in listOf(Provider.OPENROUTER, Provider.GROQ, Provider.MISTRAL, Provider.CEREBRAS, Provider.TOGETHER)) assertEquals("", p.defaultModel)
        assertEquals("deepseek-chat", Provider.DEEPSEEK.defaultModel)
    }
}
