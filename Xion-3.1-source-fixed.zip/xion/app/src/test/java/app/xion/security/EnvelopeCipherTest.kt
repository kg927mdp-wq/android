package app.xion.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Test
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

class EnvelopeCipherTest {
    private fun newKey(): SecretKey = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()

    @Test fun roundTrip() {
        val c = EnvelopeCipher(newKey().let { k -> { k } })
        val t = c.encrypt("sk-test-key-123", "key_GEMINI")
        assertFalse(t.contains("sk-test"))
        assertEquals("sk-test-key-123", c.decrypt(t, "key_GEMINI"))
    }

    @Test fun unicodeRoundTrip() {
        val c = EnvelopeCipher(newKey().let { k -> { k } })
        assertEquals("مفتاح-ص١", c.decrypt(c.encrypt("مفتاح-ص١", "s"), "s"))
    }

    @Test fun eachEncryptionIsDifferent() {
        val c = EnvelopeCipher(newKey().let { k -> { k } })
        assertNotEquals(c.encrypt("same", "s"), c.encrypt("same", "s"))
    }

    @Test fun valueCannotBeMovedToAnotherSlot() {
        val c = EnvelopeCipher(newKey().let { k -> { k } })
        assertNull(c.decrypt(c.encrypt("secret", "key_DEEPSEEK"), "key_GROK"))
    }

    @Test fun otherKeyCannotDecrypt() {
        val t = EnvelopeCipher(newKey().let { k -> { k } }).encrypt("secret", "s")
        assertNull(EnvelopeCipher(newKey().let { k -> { k } }).decrypt(t, "s"))
    }

    @Test fun tamperedOrBrokenInputGivesNullNotCrash() {
        val c = EnvelopeCipher(newKey().let { k -> { k } })
        val t = c.encrypt("secret", "s")
        val flipped = t.dropLast(2) + (if (t.endsWith("AA")) "BB" else "AA")
        assertNull(c.decrypt(flipped, "s"))
        for (bad in listOf("", "v1", "v1..", "v2.a.b", "plain-text-key", "v1.!!!.???")) assertNull(c.decrypt(bad, "s"))
    }
}
