package app.xion.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RedactorTest {
    @Test fun scrubsKnownKeyShapes() {
        val secrets = listOf(
            "sk-abcdefghijklmnopqrstuvwxyz123456",
            "AIzaSyA1234567890abcdefghijklmnopqrstu",
            "xai-ABCDEFGHIJ1234567890",
            "tvly-abcdef123456",
            "Bearer abc.def.ghi-123456"
        )
        for (s in secrets) {
            val out = Redactor.scrub("error: invalid key $s for request")
            assertFalse("leaked: $out", out.contains(s.substringAfter(' ')))
            assertTrue(out.contains("[redacted]"))
        }
    }

    @Test fun scrubsLongOpaqueTokens() {
        assertFalse(Redactor.scrub("token=" + "A1b2C3d4".repeat(6)).contains("A1b2C3d4A1b2C3d4"))
    }

    @Test fun normalTextUntouched() {
        assertEquals("Rate limit reached, try again later", Redactor.scrub("Rate limit reached, try again later"))
    }

    @Test fun phoneNumbersKeepLastTwoDigits() {
        assertEquals("•••••••••67", Redactor.maskTarget("07701234567"))
        assertFalse(Redactor.maskTarget("+964 770 123 4567").contains("770"))
        assertTrue(Redactor.maskTarget("+964 770 123 4567").endsWith("67"))
    }

    @Test fun namesAndShortNumbersAreNotMasked() {
        assertEquals("Ahmed", Redactor.maskTarget("Ahmed"))
        assertEquals("123", Redactor.maskTarget("123"))
    }
}
