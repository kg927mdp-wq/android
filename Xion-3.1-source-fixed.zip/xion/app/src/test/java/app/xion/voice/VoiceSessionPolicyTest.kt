package app.xion.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceSessionPolicyTest {
    @Test fun continuousModeResumesAfterVoiceReply() {
        assertTrue(VoiceSessionPolicy.shouldResumeAfterReply(true, false, true))
        assertFalse(VoiceSessionPolicy.shouldResumeAfterReply(false, false, true))
        assertFalse(VoiceSessionPolicy.shouldResumeAfterReply(true, false, false))
    }

    @Test fun explicitFollowUpResumesEvenWhenContinuousModeIsOff() {
        assertTrue(VoiceSessionPolicy.shouldResumeAfterReply(true, true, false))
    }

    @Test fun onlyRecoverableListeningErrorsRetryInContinuousMode() {
        assertTrue(VoiceSessionPolicy.shouldRetryListening(true, VoiceFailure.NO_MATCH))
        assertTrue(VoiceSessionPolicy.shouldRetryListening(true, VoiceFailure.SPEECH_TIMEOUT))
        assertTrue(VoiceSessionPolicy.shouldRetryListening(true, VoiceFailure.RECOGNIZER_BUSY))
        assertFalse(VoiceSessionPolicy.shouldRetryListening(false, VoiceFailure.NO_MATCH))
        assertFalse(VoiceSessionPolicy.shouldRetryListening(true, VoiceFailure.NETWORK))
        assertFalse(VoiceSessionPolicy.shouldRetryListening(true, VoiceFailure.PERMISSION))
    }

    @Test fun busyRecognizerGetsLongerBackoff() {
        assertEquals(1_200L, VoiceSessionPolicy.retryDelayMillis(VoiceFailure.RECOGNIZER_BUSY))
        assertEquals(650L, VoiceSessionPolicy.retryDelayMillis(VoiceFailure.NO_MATCH))
    }
}
