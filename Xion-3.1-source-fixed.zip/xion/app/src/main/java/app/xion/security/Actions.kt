package app.xion.security

import java.time.LocalDateTime

/**
 * The only things Xion is able to do on the device. An AI model never produces one of these directly:
 * it proposes JSON, and [ActionPolicy] either turns that JSON into one of these validated objects or rejects it.
 * The device layer accepts nothing else.
 */
sealed class Action(val type: String) {

    /** Actions that send information out of the phone or open content chosen by a third party. */
    open val externalEffect: Boolean get() = false

    /** Short Arabic sentence shown to the user when approval is needed. */
    abstract fun describe(): String

    /** Text for the audit log. Never contains message bodies or full phone numbers. */
    open fun auditNote(): String = type

    data class OpenApp(val name: String) : Action("open_app") {
        override fun describe() = "فتح تطبيق «$name»"
        override fun auditNote() = "app=$name"
    }

    data class Call(val to: String) : Action("call") {
        override val externalEffect get() = true
        override fun describe() = "الاتصال بـ «$to»"
        override fun auditNote() = "to=" + Redactor.maskTarget(to)
    }

    data class Sms(val to: String, val text: String) : Action("sms") {
        override val externalEffect get() = true
        override fun describe() = "تجهيز رسالة نصية إلى «$to»: «${text.take(80)}»"
        override fun auditNote() = "to=" + Redactor.maskTarget(to) + " chars=" + text.length
    }

    data class Whatsapp(val to: String, val text: String) : Action("whatsapp") {
        override val externalEffect get() = true
        override fun describe() = "تجهيز رسالة واتساب إلى «$to»: «${text.take(80)}»"
        override fun auditNote() = "to=" + Redactor.maskTarget(to) + " chars=" + text.length
    }

    data class SetAlarm(val hour: Int, val minute: Int, val label: String) : Action("alarm") {
        override fun describe() = "ضبط منبه الساعة %02d:%02d".format(hour, minute)
        override fun auditNote() = "time=%02d:%02d".format(hour, minute)
    }

    data class SetTimer(val seconds: Int, val label: String) : Action("timer") {
        override fun describe() = "تشغيل مؤقت لمدة $seconds ثانية"
        override fun auditNote() = "seconds=$seconds"
    }

    data class WebSearch(val query: String) : Action("web_search") {
        override fun describe() = "البحث في الإنترنت عن «$query»"
        override fun auditNote() = "chars=" + query.length
    }

    data class OpenUrl(val url: String) : Action("open_url") {
        override val externalEffect get() = true
        override fun describe() = "فتح الرابط $url"
        override fun auditNote() = "host=" + (hostOf(url) ?: "?")
    }

    data class Navigate(val destination: String) : Action("navigate") {
        override fun describe() = "فتح الخرائط إلى «$destination»"
        override fun auditNote() = "chars=" + destination.length
    }

    data class OpenSettings(val page: String) : Action("settings") {
        override fun describe() = "فتح إعدادات الجهاز: $page"
        override fun auditNote() = "page=$page"
    }

    data class Flashlight(val on: Boolean) : Action("flashlight") {
        override fun describe() = if (on) "تشغيل الفلاش" else "إطفاء الفلاش"
        override fun auditNote() = "on=$on"
    }

    /** Either [level] (0..100) or [change] ("up"/"down") is set. */
    data class Volume(val level: Int?, val change: String?) : Action("volume") {
        override fun describe() = if (level != null) "ضبط الصوت على $level%" else "تغيير مستوى الصوت"
        override fun auditNote() = if (level != null) "level=$level" else "change=$change"
    }

    data class Music(val command: String) : Action("music") {
        override fun describe() = "أمر الموسيقى: $command"
        override fun auditNote() = "command=$command"
    }

    object Camera : Action("camera") {
        override fun describe() = "فتح الكاميرا"
    }

    data class Calendar(
        val title: String,
        val start: LocalDateTime,
        val end: LocalDateTime,
        val location: String
    ) : Action("calendar") {
        override val externalEffect get() = true
        override fun describe() = "إضافة موعد «$title» بتاريخ $start"
        override fun auditNote() = "start=$start"
    }

    data class Copy(val text: String) : Action("copy") {
        override val externalEffect get() = true
        override fun describe() = "نسخ نص إلى الحافظة: «${text.take(80)}»"
        override fun auditNote() = "chars=" + text.length
    }

    data class Share(val text: String) : Action("share") {
        override val externalEffect get() = true
        override fun describe() = "مشاركة نص: «${text.take(80)}»"
        override fun auditNote() = "chars=" + text.length
    }

    companion object {
        fun hostOf(url: String): String? = try {
            java.net.URI(url).host
        } catch (e: Exception) {
            null
        }
    }
}
