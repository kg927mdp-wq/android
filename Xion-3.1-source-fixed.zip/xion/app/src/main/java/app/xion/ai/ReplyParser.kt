package app.xion.ai

import app.xion.security.Json
import java.util.Locale

/**
 * Splits streamed model text into spoken sentences and "@@" command lines.
 * Moved unchanged in behaviour from Xion 2.1; the only difference is that an action line is read with the
 * strict [Json] reader and stays an untrusted proposal (a plain map) until the policy layer accepts it.
 */
internal class ReplyParser(private val sink: (String) -> Unit) {
    private val buf = StringBuilder()
    private val cmd = StringBuilder()
    private var inCmd = false
    val spoken = StringBuilder()
    val actions = ArrayList<Map<String, Any?>>()
    var follow = false
    var search: String? = null

    /** Text received but not yet emitted as a sentence (empty once a command line has started). */
    fun partial(): String = if (inCmd) "" else buf.toString().replace(Regex("[*#`~]"), "").trimStart()

    fun feed(d: String) {
        if (inCmd) {
            cmd.append(d)
            return
        }
        buf.append(d)
        val i = buf.indexOf("@@")
        if (i >= 0) {
            cmd.append(buf.substring(i))
            buf.setLength(i)
            inCmd = true
            drain(true)
        } else {
            drain(false)
        }
    }

    private fun cut(): Int {
        val n = buf.length
        for (i in 0 until n) {
            val c = buf[i]
            if (c == '\n') return i
            if (c == '.' || c == '!' || c == '?' || c == '؟' || c == '؛') {
                if (i >= n - 1) return -1
                if (buf[i + 1].isWhitespace()) return i
            }
        }
        if (n > 200) {
            val sp = buf.lastIndexOf(" ", 190)
            if (sp > 60) return sp
        }
        return -1
    }

    private fun drain(all: Boolean) {
        while (true) {
            val i = cut()
            if (i < 0) break
            emit(buf.substring(0, i + 1))
            buf.delete(0, i + 1)
        }
        if (all) {
            if (buf.isNotBlank()) emit(buf.toString())
            buf.setLength(0)
        }
    }

    private fun emit(raw: String) {
        val t = raw.replace(Regex("[*#`~]"), "").trim()
        if (t.isEmpty()) return
        if (spoken.isNotEmpty()) spoken.append(' ')
        spoken.append(t)
        sink(t)
    }

    fun finish() {
        if (!inCmd) drain(true)
        if (cmd.isEmpty()) return
        for (part in cmd.toString().split("@@")) {
            val t = part.trim()
            if (t.isEmpty()) continue
            val head = t.substringBefore(':').trim().uppercase(Locale.ROOT)
            val rest = t.substringAfter(':', "").trim()
            when {
                head.startsWith("SEARCH") -> if (rest.isNotEmpty() && search == null) search = rest
                head.startsWith("ASK") -> follow = true
                head.startsWith("ACT") -> {
                    val obj = Json.parseObject(rest)
                    if (obj != null) actions.add(obj)
                }
            }
        }
    }
}
