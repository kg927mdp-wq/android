package app.xion.security

import java.io.File

data class AuditEntry(val time: Long, val type: String, val outcome: String, val note: String)

/**
 * Append-only history of every action Xion proposed, ran, asked about or refused.
 * Entries are deliberately minimal: no message bodies, no full phone numbers, no keys.
 * The file lives in the app's private storage and is capped in size.
 */
class AuditLog(private val file: File, private val clock: () -> Long = { System.currentTimeMillis() }) {

    @Synchronized
    fun record(type: String, outcome: String, note: String) {
        try {
            val line = Json.stringify(
                mapOf(
                    "t" to clock(),
                    "type" to type.take(20),
                    "outcome" to outcome.take(20),
                    "note" to Redactor.scrub(note).take(160)
                )
            )
            if (file.exists() && file.length() > MAX_BYTES) {
                val keep = file.readLines().takeLast(KEEP_LINES)
                file.writeText(keep.joinToString("\n", postfix = "\n"))
            }
            file.appendText(line + "\n")
        } catch (e: Exception) {
            // The history is best effort: a full disk must never stop an action or crash the app.
        }
    }

    @Synchronized
    fun recent(n: Int): List<AuditEntry> {
        return try {
            if (!file.exists()) return emptyList()
            file.readLines().takeLast(n).mapNotNull { l ->
                val m = Json.parseObject(l) ?: return@mapNotNull null
                AuditEntry(
                    (m["t"] as? Long) ?: 0L,
                    m["type"] as? String ?: "?",
                    m["outcome"] as? String ?: "?",
                    m["note"] as? String ?: ""
                )
            }.reversed()
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun clear() {
        try {
            file.delete()
        } catch (e: Exception) {
            // ignore
        }
    }

    companion object {
        const val MAX_BYTES = 200_000L
        const val KEEP_LINES = 300
        const val EXECUTED = "executed"
        const val CONFIRMED = "confirmed"
        const val DENIED = "denied"
        const val ASKED = "asked"
        const val REJECTED = "rejected"
        const val FAILED = "failed"
    }
}
