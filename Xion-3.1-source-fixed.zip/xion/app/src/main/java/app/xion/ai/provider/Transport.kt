package app.xion.ai.provider

import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL

class HttpResult(val code: Int, val body: String, val headers: Map<String, String>) {
    val ok: Boolean get() = code in 200..299
}

/** A network failure before any HTTP status was received. */
class TransportException(val kind: ErrorKind, message: String) : IOException(message)

/** The only place that touches the network. Replaced by a fake in tests. */
interface Transport {
    fun request(method: String, url: String, headers: Map<String, String>, body: String?, timeouts: Timeouts): HttpResult

    /**
     * POST that delivers each response line to [onLine] while it arrives (only for 2xx answers).
     * For a non-2xx answer the returned [HttpResult.body] holds the (capped) error text instead.
     */
    fun stream(
        url: String, headers: Map<String, String>, body: String, timeouts: Timeouts,
        cancelled: () -> Boolean, onLine: (String) -> Unit
    ): HttpResult
}

/** [Transport] on java.net.HttpURLConnection. HTTPS only: any other scheme is refused. */
class UrlTransport : Transport {

    private fun open(method: String, url: String, headers: Map<String, String>, t: Timeouts): HttpURLConnection {
        val u = URL(url)
        if (u.protocol != "https" && !(ALLOW_LOOPBACK_HTTP && u.protocol == "http" && u.host == "127.0.0.1")) {
            throw TransportException(ErrorKind.BAD_REQUEST, "only https is allowed")
        }
        val c = u.openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = t.connectMs
        c.readTimeout = t.readMs
        c.instanceFollowRedirects = false // a redirect could carry the API key to another host
        for ((k, v) in headers) c.setRequestProperty(k, v)
        return c
    }

    private fun <T> guarded(block: () -> T): T {
        try {
            return block()
        } catch (e: TransportException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw TransportException(ErrorKind.TIMEOUT, "timeout")
        } catch (e: IOException) {
            throw TransportException(ErrorKind.NETWORK, e.javaClass.simpleName)
        }
    }

    private fun readCapped(stream: java.io.InputStream?, max: Int): String {
        if (stream == null) return ""
        val sb = StringBuilder()
        stream.bufferedReader(Charsets.UTF_8).use { r ->
            val buf = CharArray(8192)
            while (sb.length < max) {
                val n = r.read(buf)
                if (n < 0) break
                sb.append(buf, 0, n)
            }
        }
        return sb.toString()
    }

    private fun headersOf(c: HttpURLConnection): Map<String, String> {
        val out = HashMap<String, String>()
        for ((k, v) in c.headerFields) if (k != null && v != null && v.isNotEmpty()) out[k.lowercase()] = v[0]
        return out
    }

    override fun request(method: String, url: String, headers: Map<String, String>, body: String?, timeouts: Timeouts): HttpResult =
        guarded {
            val c = open(method, url, headers, timeouts)
            try {
                if (body != null) {
                    c.doOutput = true
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                }
                val code = c.responseCode
                val text = readCapped(if (code in 200..299) c.inputStream else c.errorStream, MAX_BODY)
                HttpResult(code, text, headersOf(c))
            } finally {
                c.disconnect()
            }
        }

    override fun stream(
        url: String, headers: Map<String, String>, body: String, timeouts: Timeouts,
        cancelled: () -> Boolean, onLine: (String) -> Unit
    ): HttpResult = guarded {
        val c = open("POST", url, headers, timeouts)
        try {
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) {
                return@guarded HttpResult(code, readCapped(c.errorStream, 4000), headersOf(c))
            }
            c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                while (!cancelled()) {
                    val line = r.readLine() ?: break
                    onLine(line)
                }
            }
            HttpResult(code, "", headersOf(c))
        } finally {
            c.disconnect()
        }
    }

    companion object {
        private const val MAX_BODY = 8_000_000

        /** Set by unit tests only, so the transport can be exercised against a local server. */
        @Volatile
        internal var ALLOW_LOOPBACK_HTTP = false
    }
}
