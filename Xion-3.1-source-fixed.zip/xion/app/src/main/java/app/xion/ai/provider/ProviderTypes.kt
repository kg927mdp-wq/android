package app.xion.ai.provider

import app.xion.security.Redactor

data class ChatMsg(val role: String, val content: String)

/** Everything known about a model from the provider's own listing. Null means "the provider did not say". */
data class ModelInfo(
    val id: String,
    val name: String? = null,
    val contextLength: Int? = null,
    val promptPrice: Double? = null,
    val completionPrice: Double? = null,
    val supportsTools: Boolean? = null,
    val supportsVision: Boolean? = null,
    val supportsStructured: Boolean? = null
) {
    /** True only when the provider's own pricing data says both directions cost nothing. */
    val isFree: Boolean get() = promptPrice == 0.0 && completionPrice == 0.0
    val priceKnown: Boolean get() = promptPrice != null && completionPrice != null
    val pricePerMillion: Double? get() = if (priceKnown) (promptPrice!! + completionPrice!!) * 1_000_000 else null
}

data class Usage(val promptTokens: Int, val completionTokens: Int)

data class StreamOutcome(val text: String, val firstTokenMs: Long, val totalMs: Long)

data class Completion(val text: String, val usage: Usage?, val totalMs: Long)

data class Timeouts(val connectMs: Int = 15_000, val readMs: Int = 60_000)

enum class ErrorKind { AUTH, QUOTA, RATE_LIMIT, MODEL_NOT_FOUND, BAD_REQUEST, SERVER, NETWORK, TIMEOUT, EMPTY, UNKNOWN }

/** One error shape for every provider. [detail] has already passed through [Redactor]. */
class ProviderError(
    val provider: Provider,
    val kind: ErrorKind,
    val httpCode: Int,
    detail: String,
    val retryAfterSec: Int? = null
) : Exception(Redactor.scrub(detail).take(200)) {

    /** Worth trying the same request on another provider (or later). */
    val transient: Boolean get() = kind == ErrorKind.RATE_LIMIT || kind == ErrorKind.SERVER ||
        kind == ErrorKind.NETWORK || kind == ErrorKind.TIMEOUT || kind == ErrorKind.EMPTY

    /** Short Arabic explanation for the user. */
    fun describe(): String {
        val why = when (kind) {
            ErrorKind.AUTH -> "المفتاح غير صحيح أو ما عنده صلاحية"
            ErrorKind.QUOTA -> "الرصيد أو الحصة خلصت"
            ErrorKind.RATE_LIMIT -> "طلبات كثيرة، جرّب بعد شوي"
            ErrorKind.MODEL_NOT_FOUND -> "اسم الموديل غلط أو غير متاح"
            ErrorKind.BAD_REQUEST -> "الطلب مرفوض (" + (message ?: "").replace(Regex("\\s+"), " ").take(80) + ")"
            ErrorKind.SERVER -> "خطأ من الخادم ($httpCode)"
            ErrorKind.NETWORK -> "ما في اتصال بالإنترنت"
            ErrorKind.TIMEOUT -> "انتهت المهلة"
            ErrorKind.EMPTY -> "رجّع جواب فاضي"
            ErrorKind.UNKNOWN -> "خطأ " + httpCode + " " + (message ?: "").replace(Regex("\\s+"), " ").take(80)
        }
        return provider.label + ": " + why
    }
}

/**
 * The contract every provider integration fulfils. [OpenAiCompatAdapter] covers all OpenAI-style APIs; an
 * incompatible API (Anthropic Messages, Cohere, Cloudflare Workers AI) gets its own implementation of this
 * interface without touching the orchestrator.
 */
interface ProviderAdapter {
    val provider: Provider

    /** Streams the answer; every text piece goes to [onDelta]. Throws [ProviderError]. */
    fun stream(
        apiKey: String, model: String, messages: List<ChatMsg>, timeouts: Timeouts,
        cancelled: () -> Boolean, onDelta: (String) -> Unit
    ): StreamOutcome

    fun complete(apiKey: String, model: String, messages: List<ChatMsg>, timeouts: Timeouts): Completion

    /** Models the provider reports for this key. Throws [ProviderError] (also when discovery is unsupported). */
    fun listModels(apiKey: String, timeouts: Timeouts): List<ModelInfo>
}
