package app.xion.ui

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateOf
import app.xion.ai.BrainListener
import app.xion.ai.EngineSnapshot
import app.xion.ai.EngineState
import app.xion.ai.Role
import app.xion.ai.Source
import app.xion.ai.XionApp
import app.xion.data.Config
import app.xion.device.ActionGateway
import app.xion.security.Action
import app.xion.security.Decision
import app.xion.voice.ConfirmationMatcher
import app.xion.voice.Verdict
import app.xion.voice.VoiceController
import app.xion.voice.VoiceFailure
import app.xion.voice.VoiceSessionPolicy

/**
 * Glue between the chat screen, the shared [app.xion.ai.ConversationEngine] and the voice controller.
 * Typed and spoken messages take exactly the same path (engine -> orchestrator -> policy gateway); this class only
 * decides whether an answer is also read aloud and runs the approval flow for sensitive device actions.
 * Use from the main thread.
 */
class ChatController(context: Context) : VoiceController.Callback {

    private val app = context.applicationContext
    private val cfg = Config(app)
    val engine = XionApp.engine(app)
    private val main = Handler(Looper.getMainLooper())

    // state observed by the screen
    val snapshot = mutableStateOf(engine.snapshot())
    val listening = mutableStateOf(false)
    val speaking = mutableStateOf(false)
    val continuousVoice = mutableStateOf(cfg.continuousVoice)
    val level = mutableStateOf(0f)
    val partial = mutableStateOf("")
    val confirm = mutableStateOf<Decision.Confirm?>(null)
    val notice = mutableStateOf<String?>(null)
    /** Set when the microphone is wanted but not permitted yet; the screen asks Android and calls [onMicPermissionResult]. */
    val needMicPermission = mutableStateOf(false)

    private var voiceRef: VoiceController? = null
    private var gateway: ActionGateway? = null
    private val queue = ArrayDeque<Decision.Confirm>()
    private var unheard = 0
    private var resumeAfterReply = false
    private val voiceRestart = Runnable {
        if (continuousVoice.value && confirm.value == null && engine.snapshot().state == EngineState.IDLE) startMic()
    }
    private var lastSource = Source.TEXT
    private val unsubscribe: () -> Unit = engine.subscribe { main.post { snapshot.value = engine.snapshot() } }

    private fun voice(): VoiceController = voiceRef ?: VoiceController(app, this).also { voiceRef = it }

    // ------------------------------------------------------------------ sending

    /** Sends a typed message. Returns false when nothing was sent (empty, or an answer is still being produced). */
    fun sendText(text: String): Boolean {
        if (text.isBlank()) return false
        if (engine.snapshot().state != EngineState.IDLE) {
            notice.value = "Xion يجاوب الآن، انتظر لحظة."
            return false
        }
        return submit(text, Source.TEXT)
    }

    private fun submit(text: String, source: Source): Boolean {
        dropConfirmations()
        resumeAfterReply = false
        main.removeCallbacks(voiceRestart)
        voiceRef?.stopSpeaking()
        lastSource = source
        gateway = ActionGateway(app)
        notice.value = null
        return engine.submit(text, source, sink(source), interrupt = source == Source.VOICE)
    }

    fun retry() {
        val lastUser = engine.snapshot().messages.lastOrNull { it.role == Role.USER }
        val src = lastUser?.source ?: Source.TEXT
        gateway = ActionGateway(app)
        engine.retry(sink(src))
    }

    /** Forgets the conversation: screen, model context and any waiting approval. */
    fun clear() {
        resumeAfterReply = false
        main.removeCallbacks(voiceRestart)
        dropConfirmations()
        voiceRef?.stopSpeaking()
        voiceRef?.stopListening()
        engine.clear()
        notice.value = null
    }

    private fun sink(source: Source) = object : BrainListener {
        private val speak = source == Source.VOICE || cfg.speakReplies
        override fun isCancelled() = false
        override fun onSearching(query: String) {}
        override fun onSentence(text: String) {
            if (speak) main.post { voice().speak(text) }
        }

        override fun onAction(action: Map<String, Any?>, tainted: Boolean) {
            main.post { propose(action, tainted) }
        }

        override fun onDone(followUp: Boolean) {
            if (VoiceSessionPolicy.shouldResumeAfterReply(source == Source.VOICE, followUp, continuousVoice.value)) {
                main.post {
                    resumeAfterReply = true
                    if (!speaking.value) resumeVoiceSession()
                }
            }
        }

        override fun onCorrection(text: String) {
            if (speak) main.post { voice().speak("تصحيح: $text") }
        }

        override fun onFailure(message: String) {}
    }

    // ------------------------------------------------------------------ device actions (always through the policy gateway)

    private fun propose(raw: Map<String, Any?>, tainted: Boolean) {
        val gw = gateway ?: return
        when (val d = gw.propose(raw, tainted)) {
            is Decision.Allow -> run(gw, d.action, false)
            is Decision.Confirm -> {
                queue.addLast(d)
                showNext()
            }
            is Decision.Reject -> engine.addNote("ما أقدر أنفذ هذا الأمر.")
        }
    }

    private fun run(gw: ActionGateway, a: Action, confirmed: Boolean) {
        val r = gw.execute(a, confirmed)
        engine.addNote(if (r.ok) "✓ " + a.describe() else "✗ " + r.message)
    }

    private fun showNext() {
        if (confirm.value != null) return
        val d = queue.removeFirstOrNull() ?: return
        confirm.value = d
        unheard = 0
        if (lastSource == Source.VOICE || cfg.speakReplies) {
            voice().speak(if (d.action is Action.OpenUrl) "أحتاج موافقتك لفتح رابط." else "أحتاج موافقتك: " + d.action.describe())
        }
    }

    /** The user pressed "نفّذ" or "إلغاء" (or said yes / no). */
    fun confirmAction(accept: Boolean) {
        val d = confirm.value ?: return
        confirm.value = null
        voiceRef?.stopListening()
        val gw = gateway
        if (accept && gw != null) run(gw, d.action, true) else {
            gw?.deny(d.action)
            engine.addNote("أُلغي: " + d.action.describe())
        }
        showNext()
    }

    private fun dropConfirmations() {
        val gw = gateway
        val cur = confirm.value
        if (gw != null) {
            if (cur != null) gw.deny(cur.action)
            for (d in queue) gw.deny(d.action)
        }
        confirm.value = null
        queue.clear()
    }

    // ------------------------------------------------------------------ microphone

    fun onMicClick() {
        resumeAfterReply = false
        main.removeCallbacks(voiceRestart)
        val v = voice()
        if (listening.value) {
            v.stopListening()
            return
        }
        if (!v.hasMic()) {
            needMicPermission.value = true
            return
        }
        startMic()
    }

    /** Enables/disables hands-free turn-taking. Listening is resumed only after speech output completes. */
    fun setContinuousVoice(enabled: Boolean) {
        continuousVoice.value = enabled
        cfg.continuousVoice = enabled
        main.removeCallbacks(voiceRestart)
        if (!enabled) {
            resumeAfterReply = false
            voiceRef?.stopListening()
        } else if (!voice().hasMic()) {
            needMicPermission.value = true
        } else if (!listening.value && engine.snapshot().state == EngineState.IDLE && !speaking.value) {
            startMic()
        }
    }

    fun onMicPermissionResult(granted: Boolean) {
        needMicPermission.value = false
        if (granted) {
            startMic()
        } else {
            notice.value = "الميكروفون غير مسموح. تقدر تكتب رسائلك، أو فعّل الميكروفون من إعدادات التطبيق."
        }
    }

    private fun startMic() {
        partial.value = ""
        voice().startListening(if (confirm.value != null) 5 else 1)
    }

    // ------------------------------------------------------------------ VoiceController.Callback

    override fun onListeningChanged(listening: Boolean) {
        this.listening.value = listening
        if (!listening) partial.value = ""
    }

    override fun onLevel(level: Float) {
        this.level.value = level
    }

    override fun onPartial(text: String) {
        partial.value = text
    }

    override fun onResult(alternatives: List<String>, confidences: FloatArray?) {
        if (confirm.value != null) {
            when (ConfirmationMatcher.interpret(alternatives, confidences)) {
                Verdict.YES -> confirmAction(true)
                Verdict.NO -> confirmAction(false)
                Verdict.UNSURE -> notUnderstood()
            }
            return
        }
        submit(alternatives.first(), Source.VOICE)
    }

    override fun onRecognitionError(code: Int) {
        if (confirm.value != null) {
            notUnderstood()
            return
        }
        notice.value = when (code) {
            android.speech.SpeechRecognizer.ERROR_NO_MATCH, android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                if (continuousVoice.value) "ما سمعت كلاماً. أستمع من جديد…" else "ما سمعت شي. اضغط الميكروفون وجرّب مرة ثانية."
            android.speech.SpeechRecognizer.ERROR_NETWORK, android.speech.SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "في مشكلة بالإنترنت."
            android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "أحتاج صلاحية الميكروفون."
            android.speech.SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "التعرف على الصوت مشغول، جرّب بعد ثانية."
            else -> "تعذّر التعرف على الصوت (رمز $code)."
        }
        val failure = when (code) {
            android.speech.SpeechRecognizer.ERROR_NO_MATCH -> VoiceFailure.NO_MATCH
            android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> VoiceFailure.SPEECH_TIMEOUT
            android.speech.SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> VoiceFailure.RECOGNIZER_BUSY
            android.speech.SpeechRecognizer.ERROR_NETWORK, android.speech.SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> VoiceFailure.NETWORK
            android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> VoiceFailure.PERMISSION
            else -> VoiceFailure.OTHER
        }
        if (VoiceSessionPolicy.shouldRetryListening(continuousVoice.value, failure)) {
            main.removeCallbacks(voiceRestart)
            main.postDelayed(voiceRestart, VoiceSessionPolicy.retryDelayMillis(failure))
        }
    }

    private fun notUnderstood() {
        unheard++
        if (unheard < 2) {
            notice.value = "ما فهمت. قل نعم أو لا، أو اضغط الزر."
            startMic()
        } else {
            notice.value = "اضغط نفّذ أو إلغاء."
        }
    }

    private fun resumeVoiceSession() {
        if (!resumeAfterReply) return
        resumeAfterReply = false
        if ((continuousVoice.value || lastSource == Source.VOICE) && confirm.value == null && voice().hasMic()) startMic()
    }

    override fun onSpeakingChanged(speaking: Boolean) {
        this.speaking.value = speaking
        // Resume only after TTS finishes; opening the recognizer stops any active speech output.
        if (!speaking && resumeAfterReply) resumeVoiceSession()
        // after Xion asks for approval out loud, listen for the answer once
        if (!speaking && confirm.value != null && unheard == 0 && lastSource == Source.VOICE && voice().hasMic()) startMic()
    }

    fun dispose() {
        unsubscribe()
        main.removeCallbacks(voiceRestart)
        resumeAfterReply = false
        dropConfirmations()
        voiceRef?.shutdown()
        voiceRef = null
    }
}
