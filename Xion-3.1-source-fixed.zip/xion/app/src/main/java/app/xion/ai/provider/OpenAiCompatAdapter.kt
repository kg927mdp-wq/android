package app.xion.ai.provider

import app.xion.security.Json
import app.xion.security.Redactor

/**
 * Adapter for APIs that follow the OpenAI chat-completions format (SSE streaming, `choices[].delta.content`,
 * `GET models`). It normalises requests, responses and errors so the rest of Xion never sees provider details.
 * [clock] is injectable for deterministic latency in tests.
 */
class OpenAiCompatAdapter(
    override val provider: Provider,
    private val transport: Transport,
    private val clock: () -> Long = { System.nanoTime() / 1_000_000 }
) : ProviderAdapter {

    private fun headers(key: String, stream: Boolean): Map<String, String> {
        val h = LinkedHashMap<String, String>()
        h["Authorization"] = "Bearer $key"
        h["Content-Type"] = "application/json"
        h["Accept"] = if (stream) "text/event-stream" else "application/json"
        h.putAll(provider.extraHeaders)
        return h
    }

    internal fun body(model: String, messages: List<ChatMsg>, stream: Boolean): String {
        val b = LinkedHashMap<String, Any?>()
        b["model"] = model
        b["messages"] = messages.map { mapOf("role" to it.role, "content" to it.content) }
        b["stream"] = stream
        b.putAll(provider.bodyDefaults)
        return Json.stringify(b)
    }

    // ------------------------------------------------------------------ errors

    internal fun errorFrom(res: HttpResult): ProviderError {
        val kind = when (res.code) {
            401, 403 -> ErrorKind.AUTH
            402 -> ErrorKind.QUOTA
            404 -> ErrorKind.MODEL_NOT_FOUND
            408 -> ErrorKind.TIMEOUT
            429 -> ErrorKind.RATE_LIMIT
            400, 422 -> ErrorKind.BAD_REQUEST
            in 500..599 -> ErrorKind.SERVER
            else -> ErrorKind.UNKNOWN
        }
        val retry = res.headers["retry-after"]?.trim()?.toIntOrNull()?.coerceIn(0, 3600)
        return ProviderError(provider, kind, res.code, messageOf(res.body), retry)
    }

    @Suppress("UNCHECKED_CAST")
    private fun messageOf(body: String): String {
        val j = Json.parseObject(body, Json.API) ?: return body.take(120)
        val e = j["error"]
        val m = when (e) {
            is Map<*, *> -> e["message"] as? String
            is String -> e
            else -> null
        } ?: (j["message"] as? String)
        return Redactor.scrub(m ?: body).take(160)
    }

    private fun wrap(e: TransportException): ProviderError = ProviderError(provider, e.kind, -1, e.message ?: "")

    // ------------------------------------------------------------------ streaming

    override fun stream(
        apiKey: String, model: String, messages: List<ChatMsg>, timeouts: Timeouts,
        cancelled: () -> Boolean, onDelta: (String) -> Unit
    ): StreamOutcome {
        val start = clock()
        var first = -1L
        val text = StringBuilder()
        var streamError: ProviderError? = null
        val res = try {
            transport.stream(provider.url, headers(apiKey, true), body(model, messages, true), timeouts, cancelled) { line ->
                if (streamError != null || !line.startsWith("data:")) return@stream // comments (": ...") and blanks
                val data = line.substring(5).trim()
                if (data.isEmpty() || data == "[DONE]") return@stream
                val j = Json.parseObject(data, Json.API) ?: return@stream
                val err = j["error"]
                if (err != null) {
                    streamError = ProviderError(provider, ErrorKind.SERVER, 200, messageOf(data))
                    return@stream
                }
                val choices = j["choices"] as? List<*> ?: return@stream
                val delta = (choices.firstOrNull() as? Map<*, *>)?.get("delta") as? Map<*, *> ?: return@stream
                val c = delta["content"] as? String ?: return@stream
                if (c.isNotEmpty()) {
                    if (first < 0) first = clock() - start
                    text.append(c)
                    onDelta(c)
                }
            }
        } catch (e: TransportException) {
            throw wrap(e)
        }
        if (!res.ok) throw errorFrom(res)
        streamError?.let { if (text.isEmpty()) throw it }
        if (text.isBlank() && !cancelled()) throw ProviderError(provider, ErrorKind.EMPTY, res.code, "empty")
        return StreamOutcome(text.toString(), if (first < 0) 0 else first, clock() - start)
    }

    // ------------------------------------------------------------------ one-shot

    override fun complete(apiKey: String, model: String, messages: List<ChatMsg>, timeouts: Timeouts): Completion {
        val start = clock()
        val res = try {
            transport.request("POST", provider.url, headers(apiKey, false), body(model, messages, false), timeouts)
        } catch (e: TransportException) {
            throw wrap(e)
        }
        if (!res.ok) throw errorFrom(res)
        val j = Json.parseObject(res.body, Json.API) ?: throw ProviderError(provider, ErrorKind.EMPTY, res.code, "unreadable answer")
        val choices = j["choices"] as? List<*>
        val msg = (choices?.firstOrNull() as? Map<*, *>)?.get("message") as? Map<*, *>
        val content = msg?.get("content") as? String
        if (content.isNullOrBlank()) throw ProviderError(provider, ErrorKind.EMPTY, res.code, "empty")
        val u = j["usage"] as? Map<*, *>
        val usage = if (u == null) null else Usage(num(u["prompt_tokens"]), num(u["completion_tokens"]))
        return Completion(content, usage, clock() - start)
    }

    private fun num(v: Any?): Int = when (v) {
        is Long -> v.coerceIn(0, Int.MAX_VALUE.toLong()).toInt()
        is Double -> v.coerceIn(0.0, Int.MAX_VALUE.toDouble()).toInt()
        else -> 0
    }

    // ------------------------------------------------------------------ discovery

    override fun listModels(apiKey: String, timeouts: Timeouts): List<ModelInfo> {
        val url = provider.modelsUrl ?: throw ProviderError(provider, ErrorKind.BAD_REQUEST, -1, "model discovery not supported")
        val res = try {
            transport.request("GET", url, headers(apiKey, false) - "Content-Type", null, timeouts)
        } catch (e: TransportException) {
            throw wrap(e)
        }
        if (!res.ok) throw errorFrom(res)
        val root = try {
            Json.parse(res.body, Json.API)
        } catch (e: Exception) {
            throw ProviderError(provider, ErrorKind.EMPTY, res.code, "unreadable model list")
        }
        // OpenAI style is {"data":[...]}; some providers return the array directly.
        val list = (if (root is Map<*, *>) root["data"] else root) as? List<*>
            ?: throw ProviderError(provider, ErrorKind.EMPTY, res.code, "no model list")
        return list.mapNotNull { parseModel(it) }.sortedBy { it.id }
    }

    internal fun parseModel(o: Any?): ModelInfo? {
        val m = o as? Map<*, *> ?: return null
        val id = (m["id"] as? String)?.trim()?.takeIf { it.isNotEmpty() && it.length <= 200 } ?: return null
        val ctx = (m["context_length"] ?: m["context_window"])?.let { num(it) }?.takeIf { it > 0 }
        val pricing = m["pricing"] as? Map<*, *>
        val params = (m["supported_parameters"] as? List<*>)?.map { it.toString() }
        val inputs = ((m["architecture"] as? Map<*, *>)?.get("input_modalities") as? List<*>)?.map { it.toString() }
        return ModelInfo(
            id = id,
            name = (m["name"] as? String)?.take(120),
            contextLength = ctx,
            promptPrice = price(pricing?.get("prompt")),
            completionPrice = price(pricing?.get("completion")),
            supportsTools = params?.contains("tools"),
            supportsVision = inputs?.contains("image"),
            supportsStructured = params?.let { it.contains("structured_outputs") || it.contains("response_format") }
        )
    }

    private fun price(v: Any?): Double? = when (v) {
        is String -> v.trim().toDoubleOrNull()?.takeIf { it >= 0 }
        is Long -> v.toDouble().takeIf { it >= 0 }
        is Double -> v.takeIf { it >= 0 }
        else -> null
    }
}
