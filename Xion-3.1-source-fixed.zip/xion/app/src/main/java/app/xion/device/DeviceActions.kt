package app.xion.device

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import app.xion.data.Config
import app.xion.security.Action
import java.time.ZoneId
import kotlin.math.roundToInt

data class ActionResult(val ok: Boolean, val message: String, val leftApp: Boolean)

object DeviceActions {

    private val ALIASES = mapOf(
        "واتساب" to "whatsapp", "واتس اب" to "whatsapp", "واتس" to "whatsapp",
        "يوتيوب" to "youtube", "تلغرام" to "telegram", "تليجرام" to "telegram",
        "انستغرام" to "instagram", "انستا" to "instagram", "سناب" to "snapchat",
        "سناب شات" to "snapchat", "تيك توك" to "tiktok", "كاميرا" to "camera",
        "الكاميرا" to "camera", "اعدادات" to "settings", "الاعدادات" to "settings",
        "خرائط" to "maps", "الخرائط" to "maps", "جيميل" to "gmail", "كروم" to "chrome",
        "المتصفح" to "browser", "متصفح" to "browser", "الصور" to "photos",
        "معرض الصور" to "gallery", "الحاسبه" to "calculator", "الساعه" to "clock",
        "الرسائل" to "messages", "الهاتف" to "phone", "جهات الاتصال" to "contacts",
        "الملفات" to "files", "الموسيقى" to "music", "موسيقى" to "music",
        "متجر بلاي" to "play store", "بلاي ستور" to "play store",
        "تويتر" to "x", "فيسبوك" to "facebook", "ماسنجر" to "messenger"
    )

    private fun norm(s: String): String {
        return s.lowercase().trim()
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace('ة', 'ه').replace('ى', 'ي')
            .replace(Regex("[\\u064B-\\u065F]"), "")
    }

    /**
     * Runs one action that [app.xion.security.ActionPolicy] has already validated (and, where needed, the user
     * has approved). This is the only entry point to the device: it accepts typed actions, never model text.
     * [directCall] is true only when the user enabled direct calling and the phone permission is granted.
     */
    fun run(ctx: Context, a: Action, directCall: Boolean): ActionResult {
        return try {
            when (a) {
                is Action.OpenApp -> openApp(ctx, a.name)
                is Action.Call -> call(ctx, a.to, directCall)
                is Action.Sms -> sms(ctx, a.to, a.text)
                is Action.Whatsapp -> whatsapp(ctx, a.to, a.text)
                is Action.SetAlarm -> alarm(ctx, a)
                is Action.SetTimer -> timer(ctx, a)
                is Action.WebSearch -> webSearch(ctx, a.query)
                is Action.OpenUrl -> openUrl(ctx, a.url)
                is Action.Navigate -> navigate(ctx, a.destination)
                is Action.OpenSettings -> settings(ctx, a.page)
                is Action.Flashlight -> flashlight(ctx, a.on)
                is Action.Volume -> volume(ctx, a)
                is Action.Music -> music(ctx, a.command)
                is Action.Camera -> launch(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "ما قدرت أفتح الكاميرا")
                is Action.Calendar -> calendar(ctx, a)
                is Action.Copy -> copy(ctx, a.text)
                is Action.Share -> share(ctx, a.text)
            }
        } catch (e: Exception) {
            ActionResult(false, "صار خطأ وأنا أنفذ الأمر", false)
        }
    }

    /** True when a call would start immediately (user enabled it and the permission is granted). */
    fun directCallArmed(ctx: Context): Boolean =
        Config(ctx).directCall &&
            ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED

    private fun launch(ctx: Context, intent: Intent, failMsg: String): ActionResult {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            ActionResult(true, "", true)
        } catch (e: Exception) {
            ActionResult(false, failMsg, false)
        }
    }

    // ---------- apps ----------

    private fun openApp(ctx: Context, nameRaw: String): ActionResult {
        if (nameRaw.isBlank()) return ActionResult(false, "ما عرفت أي تطبيق تقصد", false)
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)

        var q = norm(nameRaw)
        val alias = ALIASES[q]
        if (alias != null) q = alias

        var bestPkg: String? = null
        var bestScore = 0
        var bestLen = Int.MAX_VALUE
        for (ri in apps) {
            val label = norm(ri.loadLabel(pm).toString())
            val score = when {
                label == q -> 100
                label.startsWith(q) -> 80
                label.contains(q) -> 60
                label.length >= 3 && q.contains(label) -> 40
                else -> 0
            }
            if (score > bestScore || (score == bestScore && score > 0 && label.length < bestLen)) {
                bestScore = score
                bestLen = label.length
                bestPkg = ri.activityInfo.packageName
            }
        }
        if (bestPkg == null || bestScore == 0) {
            return ActionResult(false, "ما لقيت تطبيق اسمه $nameRaw", false)
        }
        val li = pm.getLaunchIntentForPackage(bestPkg)
            ?: return ActionResult(false, "ما قدرت أفتح $nameRaw", false)
        return launch(ctx, li, "ما قدرت أفتح $nameRaw")
    }

    // ---------- contacts / calls / messages ----------

    private fun resolveNumber(ctx: Context, to: String): String? {
        val t = to.trim()
        if (t.isEmpty()) return null
        val hasLetters = t.any { it.isLetter() }
        val digitCount = t.count { it.isDigit() }
        if (!hasLetters && digitCount >= 3) {
            return t.filter { it.isDigit() || it == '+' }
        }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$t%"),
            null
        ) ?: return null
        var bestNumber: String? = null
        var bestLen = Int.MAX_VALUE
        cursor.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: ""
                val number = c.getString(1) ?: ""
                if (number.isNotEmpty() && name.length < bestLen) {
                    bestLen = name.length
                    bestNumber = number
                }
            }
        }
        return bestNumber
    }

    private fun needNumberMsg(ctx: Context, to: String): String {
        return if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            "ما عندي صلاحية جهات الاتصال، فعّلها من إعدادات التطبيق"
        else
            "ما لقيت رقم لـ $to"
    }

    private fun call(ctx: Context, to: String, directCall: Boolean): ActionResult {
        val num = resolveNumber(ctx, to) ?: return ActionResult(false, needNumberMsg(ctx, to), false)
        val intent = Intent(
            if (directCall) Intent.ACTION_CALL else Intent.ACTION_DIAL,
            Uri.fromParts("tel", num, null)
        )
        return launch(ctx, intent, "ما قدرت أبدأ الاتصال")
    }

    private fun sms(ctx: Context, to: String, text: String): ActionResult {
        val num = resolveNumber(ctx, to) ?: return ActionResult(false, needNumberMsg(ctx, to), false)
        val intent = Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", num, null))
        intent.putExtra("sms_body", text)
        return launch(ctx, intent, "ما قدرت أفتح الرسائل")
    }

    private fun intlDigits(num: String, cc: String): String {
        val trimmed = num.trim()
        val d = trimmed.filter { it.isDigit() }
        if (trimmed.startsWith("+")) return d
        if (d.startsWith("00")) return d.substring(2)
        if (d.startsWith("0")) return cc + d.substring(1)
        return d
    }

    private fun whatsapp(ctx: Context, to: String, text: String): ActionResult {
        val num = resolveNumber(ctx, to) ?: return ActionResult(false, needNumberMsg(ctx, to), false)
        val digits = intlDigits(num, Config(ctx).countryCode)
        val uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(text))
        return launch(ctx, Intent(Intent.ACTION_VIEW, uri), "ما قدرت أفتح واتساب")
    }

    // ---------- time ----------

    private fun alarm(ctx: Context, a: Action.SetAlarm): ActionResult {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, a.hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, a.minute)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (a.label.isNotBlank()) intent.putExtra(AlarmClock.EXTRA_MESSAGE, a.label)
        return launch(ctx, intent, "ما قدرت أضبط المنبه")
    }

    private fun timer(ctx: Context, a: Action.SetTimer): ActionResult {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, a.seconds)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (a.label.isNotBlank()) intent.putExtra(AlarmClock.EXTRA_MESSAGE, a.label)
        return launch(ctx, intent, "ما قدرت أشغل المؤقت")
    }

    private fun calendar(ctx: Context, a: Action.Calendar): ActionResult {
        val zone = ZoneId.systemDefault()
        val intent = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, a.title)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, a.start.atZone(zone).toInstant().toEpochMilli())
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, a.end.atZone(zone).toInstant().toEpochMilli())
        if (a.location.isNotBlank()) intent.putExtra(CalendarContract.Events.EVENT_LOCATION, a.location)
        return launch(ctx, intent, "ما قدرت أفتح التقويم")
    }

    // ---------- web / maps / settings ----------

    private fun webSearch(ctx: Context, q: String): ActionResult {
        if (q.isBlank()) return ActionResult(false, "ما عرفت وش أبحث", false)
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))
        return launch(ctx, Intent(Intent.ACTION_VIEW, uri), "ما قدرت أفتح البحث")
    }

    private fun openUrl(ctx: Context, url: String): ActionResult {
        val u = url.trim()
        if (!u.startsWith("http://") && !u.startsWith("https://")) {
            return ActionResult(false, "الرابط غير صحيح", false)
        }
        return launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)), "ما قدرت أفتح الرابط")
    }

    private fun navigate(ctx: Context, dest: String): ActionResult {
        if (dest.isBlank()) return ActionResult(false, "ما عرفت الوجهة", false)
        val uri = Uri.parse("geo:0,0?q=" + Uri.encode(dest))
        return launch(ctx, Intent(Intent.ACTION_VIEW, uri), "ما قدرت أفتح الخرائط")
    }

    private fun settings(ctx: Context, page: String): ActionResult {
        val action = when (page.lowercase().trim()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            "nfc" -> Settings.ACTION_NFC_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return launch(ctx, Intent(action), "ما قدرت أفتح الإعدادات")
    }

    // ---------- hardware ----------

    private fun flashlight(ctx: Context, on: Boolean): ActionResult {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return ActionResult(false, "الجهاز ما فيه فلاش", false)
        cm.setTorchMode(id, on)
        return ActionResult(true, "", false)
    }

    private fun volume(ctx: Context, a: Action.Volume): ActionResult {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val level = a.level
        if (level != null) {
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                (level / 100f * max).roundToInt(),
                AudioManager.FLAG_SHOW_UI
            )
        } else {
            val dir = if (a.change == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        }
        return ActionResult(true, "", false)
    }

    private fun music(ctx: Context, cmd: String): ActionResult {
        val code = when (cmd.lowercase().trim()) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return ActionResult(false, "ما عرفت أمر الموسيقى", false)
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ActionResult(true, "", false)
    }

    // ---------- clipboard / share ----------

    private fun copy(ctx: Context, text: String): ActionResult {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("text", text))
        return ActionResult(true, "", false)
    }

    private fun share(ctx: Context, text: String): ActionResult {
        val send = Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, text)
        return launch(ctx, Intent.createChooser(send, null), "ما قدرت أفتح المشاركة")
    }
}
