package app.xion.ai

import android.content.Context
import app.xion.ai.provider.Provider

/**
 * Entry point used by the voice overlay (unchanged since 2.1). It no longer has its own logic: a spoken request
 * goes into the same [ConversationEngine] as typed messages, so both share history, routing and policy.
 */
object Brain {

    /** Starts a spoken turn and returns immediately; events arrive on [l]. A running turn is interrupted. */
    fun ask(ctx: Context, userText: String, l: BrainListener) {
        if (!XionApp.engine(ctx).submit(userText, Source.VOICE, l, interrupt = true)) {
            l.onFailure("ما سمعت شي واضح، جرّب مرة ثانية.")
        }
    }

    /** Health check of one provider (settings screen). Blocking: call from a background thread. */
    fun ping(ctx: Context, p: Provider): String = XionApp.orchestrator(ctx).ping(p)

    fun clearHistory(ctx: Context) {
        XionApp.engine(ctx).clear()
    }
}
