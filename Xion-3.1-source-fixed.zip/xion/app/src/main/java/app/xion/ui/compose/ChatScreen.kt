package app.xion.ui.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import app.xion.ai.EngineState
import app.xion.ai.MsgStatus
import app.xion.ai.Role
import app.xion.ai.Source
import app.xion.ai.UiMessage
import app.xion.ui.ChatController
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The main screen: one conversation, typed or spoken. Both inputs go to the same engine (ChatController),
 * so switching between them never loses context. Works fully without the microphone permission.
 */
@Composable
fun ChatScreen(c: ChatController, onMenu: () -> Unit) {
    val snap = c.snapshot.value
    val busy = snap.state != EngineState.IDLE
    var draft by remember { mutableStateOf("") }
    var askClear by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    val atBottom by remember { derivedStateOf { val i = list.layoutInfo; i.totalItemsCount == 0 || (i.visibleItemsInfo.lastOrNull()?.index ?: 0) >= i.totalItemsCount - 1 } }
    val tail = snap.messages.lastOrNull()
    // follow new content only while the user is already at the bottom; reading older messages is never interrupted
    LaunchedEffect(snap.messages.size, tail?.text?.length, snap.state) {
        if (atBottom && snap.messages.isNotEmpty()) list.scrollToItem(snap.messages.size)
    }

    fun send() {
        if (draft.isBlank() || busy) return
        if (c.sendText(draft.trim())) draft = ""
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        // ---- top bar
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            XionLogo(Modifier.size(40.dp), active = busy || c.listening.value)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                XText("Xion", 20, weight = FontWeight.Bold)
                XText(
                    when {
                        c.listening.value -> "أسمعك…"
                        snap.state == EngineState.SEARCHING -> "أبحث بالإنترنت…"
                        busy -> "أفكر…"
                        c.speaking.value -> "أتكلم…"
                        else -> "TECH TO EASY LIFE"
                    }, 11, X.muted
                )
            }
            Chip(if (c.listening.value) "🎙 وضع الصوت" else "⌨ وضع الكتابة", if (c.listening.value) X.cyan else X.purple)
            Chip(if (c.continuousVoice.value) "∞ تشغيل" else "∞", if (c.continuousVoice.value) X.cyan else X.muted) {
                c.setContinuousVoice(!c.continuousVoice.value)
            }
            Box(Modifier.padding(start = 8.dp).size(38.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)).clickable { askClear = true }, contentAlignment = Alignment.Center) { XText("🗑", 15) }
            Box(Modifier.padding(start = 8.dp).size(38.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)).clickable(onClick = onMenu), contentAlignment = Alignment.Center) { XText("⚙", 17) }
        }

        // ---- messages
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (snap.messages.isEmpty()) {
                Column(Modifier.align(Alignment.Center).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    XionLogo(Modifier.size(110.dp), active = false)
                    XText("اكتب رسالة أو اضغط الميكروفون", 16, X.muted, modifier = Modifier.padding(top = 16.dp))
                    XText("نفس المحادثة بالصوت والكتابة", 12, X.muted, modifier = Modifier.padding(top = 4.dp))
                }
            }
            LazyColumn(
                state = list,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp)
            ) {
                items(snap.messages, key = { it.id }) { m ->
                    Bubble(m, onCopy = { clipboard.setText(AnnotatedString(m.text)) }, onRetry = { c.retry() }, canRetry = !busy && m === snap.messages.lastOrNull { it.role == Role.ASSISTANT })
                }
                if (busy && (tail == null || tail.role == Role.USER)) item { Glass(Modifier.padding(4.dp)) { Box(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) { ThinkingDots() } } }
                item { Box(Modifier.size(1.dp)) }
            }
            if (!atBottom && snap.messages.isNotEmpty()) {
                Box(
                    Modifier.align(Alignment.BottomCenter).padding(8.dp).clip(RoundedCornerShape(50))
                        .background(X.accent, RoundedCornerShape(50))
                        .clickable { scope.launch { list.animateScrollToItem(snap.messages.size) } }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) { XText("↓ آخر رسالة", 12, Color.White) }
            }
        }

        // ---- notice and approval card
        c.notice.value?.let { n ->
            Glass(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp), 16.dp) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    XText(n, 13, X.warn, modifier = Modifier.weight(1f))
                    XText("✕", 14, X.muted, modifier = Modifier.clickable { c.notice.value = null }.padding(start = 12.dp))
                }
            }
        }
        c.confirm.value?.let { d ->
            Glass(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), 20.dp, strong = true) {
                Column(Modifier.padding(16.dp)) {
                    XText("يحتاج موافقتك", 12, X.cyan, FontWeight.SemiBold)
                    XText(d.action.describe(), 16, modifier = Modifier.padding(top = 6.dp, bottom = 12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GlassButton("نفّذ", Modifier.weight(1f), accent = true) { c.confirmAction(true) }
                        GlassButton("إلغاء", Modifier.weight(1f)) { c.confirmAction(false) }
                    }
                    if (c.listening.value) XText("أسمعك: قل نعم أو لا", 12, X.muted, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        if (c.listening.value && c.partial.value.isNotEmpty()) {
            XText(c.partial.value, 14, X.cyan, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        }

        // ---- input row
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.Bottom) {
            val micColor = if (c.listening.value) X.cyan else X.purple
            Box(
                Modifier.size(48.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(micColor.copy(alpha = if (c.listening.value) 0.9f else 0.45f), micColor.copy(alpha = 0.15f))), CircleShape)
                    .border(1.dp, micColor.copy(alpha = 0.6f), CircleShape)
                    .clickable { c.onMicClick() },
                contentAlignment = Alignment.Center
            ) { XText(if (c.listening.value) "■" else "🎙", 18) }

            val shape = RoundedCornerShape(24.dp)
            BasicTextField(
                value = draft,
                onValueChange = { draft = it.take(8000) },
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                    .clip(shape).background(Color.Black.copy(alpha = 0.30f), shape).border(1.dp, Color.White.copy(alpha = 0.16f), shape)
                    .onPreviewKeyEvent { e ->
                        // hardware keyboard: Enter sends, Shift+Enter makes a new line. The on-screen keyboard keeps Enter = new line.
                        if (e.key == Key.Enter && !e.isShiftPressed) {
                            if (e.type == KeyEventType.KeyDown) send()
                            true
                        } else false
                    },
                textStyle = TextStyle(color = X.text, fontSize = 15.sp, lineHeight = 22.sp),
                cursorBrush = SolidColor(X.cyan),
                maxLines = 6,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                decorationBox = { inner ->
                    Box(Modifier.padding(horizontal = 16.dp, vertical = 13.dp)) {
                        if (draft.isEmpty()) XText("اكتب رسالتك…", 15, X.muted)
                        inner()
                    }
                }
            )
            val can = draft.isNotBlank() && !busy
            Box(
                Modifier.size(48.dp).clip(CircleShape)
                    .background(if (can) X.accent else SolidColor(Color.White.copy(alpha = 0.08f)), CircleShape)
                    .clickable(enabled = can) { send() },
                contentAlignment = Alignment.Center
            ) { XText("➤", 18, if (can) Color.White else X.muted) }
        }
    }

    if (askClear) {
        Dialog(onDismissRequest = { askClear = false }) {
            Glass(Modifier.fillMaxWidth(), 24.dp, strong = true) {
                Column(Modifier.padding(20.dp)) {
                    XText("مسح المحادثة؟", 18, weight = FontWeight.Bold)
                    XText("تنمسح الرسائل وذاكرة المحادثة. ما يمكن التراجع.", 13, X.muted, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GlassButton("امسح", Modifier.weight(1f), accent = true) { c.clear(); askClear = false }
                        GlassButton("لا", Modifier.weight(1f)) { askClear = false }
                    }
                }
            }
        }
    }
}

private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

@Composable
private fun Bubble(m: UiMessage, onCopy: () -> Unit, onRetry: () -> Unit, canRetry: Boolean) {
    if (m.role == Role.NOTE) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Chip(m.text, X.muted) }
        return
    }
    val mine = m.role == Role.USER
    // RTL layout: Start = right edge. The user's bubbles sit at the start, Xion's at the end.
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End) {
        val shape = RoundedCornerShape(20.dp)
        Column(
            Modifier.widthIn(max = 320.dp).clip(shape)
                .background(
                    if (mine) Brush.horizontalGradient(listOf(X.purple.copy(alpha = 0.55f), X.purple.copy(alpha = 0.30f)))
                    else Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.05f))), shape
                )
                .border(1.dp, if (m.status == MsgStatus.ERROR) X.bad.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.14f), shape)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            if (m.text.isEmpty() && m.status == MsgStatus.STREAMING) ThinkingDots()
            else XText(m.text, 15, lineHeight = 23)
            if (m.error != null) XText(m.error, 12, X.bad, modifier = Modifier.padding(top = 6.dp))
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                XText(timeFmt.format(Date(m.time)) + (if (m.source == Source.VOICE) "  🎙" else "") + (m.provider?.let { "  · $it" } ?: ""), 10, X.muted, modifier = Modifier.weight(1f))
                if (!mine && m.text.isNotEmpty()) XText("نسخ", 11, X.cyan, modifier = Modifier.clickable(onClick = onCopy).padding(start = 12.dp))
                if (!mine && m.status == MsgStatus.ERROR && canRetry) XText("إعادة", 11, X.warn, modifier = Modifier.clickable(onClick = onRetry).padding(start = 12.dp))
            }
        }
    }
}
