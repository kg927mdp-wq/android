package app.xion.ai

/** Events of one turn, in the order they happen. Implemented by the voice overlay and by the chat screen. */
interface BrainListener {
    fun isCancelled(): Boolean
    fun onSearching(query: String)
    fun onSentence(text: String)
    /** [tainted] is true when the answer was built from web content, so the policy layer is stricter. */
    fun onAction(action: Map<String, Any?>, tainted: Boolean)
    fun onDone(followUp: Boolean)
    fun onCorrection(text: String)
    fun onFailure(message: String)
}
