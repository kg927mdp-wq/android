package app.xion.security

import java.net.URI
import java.time.LocalDateTime

sealed class Decision {
    /** Safe to run now. */
    data class Allow(val action: Action) : Decision()

    /** Valid, but the user must approve it first. [reason] is shown to the user. */
    data class Confirm(val action: Action, val reason: String) : Decision()

    /** Never runs. [reason] is for the audit log only. */
    data class Reject(val type: String, val reason: String) : Decision()
}

/**
 * Central policy for everything an AI model may ask the phone to do. One instance is used per user turn.
 *
 * It is enforced in application code, not in the prompt, so it holds for every provider:
 *  1. whitelist of action types and fields, with strict types and limits;
 *  2. at most [MAX_PER_TURN] actions per turn;
 *  3. actions with an external effect are never repeated within a turn;
 *  4. a direct phone call always needs approval;
 *  5. when the answer was built from web content ("tainted"), actions with an external effect need approval,
 *     so text found on a web page can never silently call, message, copy or open links.
 */
class ActionPolicy {

    private var count = 0
    private val seen = HashSet<Action>()

    fun evaluate(raw: Map<String, Any?>, tainted: Boolean, directCallArmed: Boolean): Decision {
        val type = (raw["type"] as? String)?.trim()?.lowercase() ?: return Decision.Reject("?", "missing type")
        if (count >= MAX_PER_TURN) return Decision.Reject(type, "too many actions in one turn")
        val action = try {
            parse(type, raw)
        } catch (e: Invalid) {
            return Decision.Reject(type, e.message ?: "invalid")
        }
        if (action.externalEffect && !seen.add(action)) {
            return Decision.Reject(type, "duplicate action in the same turn")
        }
        count++

        if (action is Action.Call && directCallArmed) {
            return Decision.Confirm(action, "الاتصال المباشر يبدأ المكالمة فوراً")
        }
        if (tainted && (action.externalEffect || (action is Action.OpenSettings && action.page == "accessibility"))) {
            return Decision.Confirm(action, "هذا الطلب جاء بعد قراءة محتوى من الإنترنت")
        }
        return Decision.Allow(action)
    }

    private class Invalid(message: String) : Exception(message)

    private fun parse(type: String, a: Map<String, Any?>): Action = when (type) {
        "open_app" -> Action.OpenApp(text(a, "name", 60, required = true))
        "call" -> Action.Call(target(a, "to"))
        "sms" -> Action.Sms(target(a, "to"), text(a, "text", MAX_TEXT, required = true))
        "whatsapp" -> Action.Whatsapp(target(a, "to"), text(a, "text", MAX_TEXT, required = true))
        "alarm" -> {
            val h = int(a, "hour") ?: throw Invalid("hour")
            val m = int(a, "minute") ?: 0
            if (h !in 0..23 || m !in 0..59) throw Invalid("time out of range")
            Action.SetAlarm(h, m, text(a, "label", 60))
        }
        "timer" -> {
            val s = int(a, "seconds") ?: throw Invalid("seconds")
            if (s !in 1..86_400) throw Invalid("duration out of range")
            Action.SetTimer(s, text(a, "label", 60))
        }
        "web_search" -> Action.WebSearch(text(a, "query", 200, required = true))
        "open_url" -> Action.OpenUrl(url(a, "url"))
        "navigate" -> Action.Navigate(text(a, "destination", 200, required = true))
        "settings" -> {
            val p = text(a, "page", 20).lowercase()
            Action.OpenSettings(if (p in SETTINGS_PAGES) p else "main")
        }
        "flashlight" -> Action.Flashlight(bool(a, "on") ?: true)
        "volume" -> {
            val level = int(a, "level")
            if (level != null) {
                Action.Volume(level.coerceIn(0, 100), null)
            } else {
                val c = text(a, "change", 8).lowercase()
                if (c != "up" && c != "down") throw Invalid("volume needs level or change")
                Action.Volume(null, c)
            }
        }
        "music" -> {
            val c = text(a, "command", 10, required = true).lowercase()
            if (c !in MUSIC_COMMANDS) throw Invalid("music command")
            Action.Music(c)
        }
        "camera" -> Action.Camera
        "calendar" -> {
            val title = text(a, "title", 120, required = true)
            val start = dateTime(a, "start") ?: throw Invalid("start")
            val end = dateTime(a, "end")?.takeIf { it.isAfter(start) } ?: start.plusHours(1)
            Action.Calendar(title, start, end, text(a, "location", 120))
        }
        "copy" -> Action.Copy(text(a, "text", MAX_TEXT, required = true))
        "share" -> Action.Share(text(a, "text", MAX_TEXT, required = true))
        else -> throw Invalid("unknown action type")
    }

    // ---------------------------------------------------------------- field readers

    /** Control characters become spaces, the text is trimmed and cut to [max]. A wrong type is rejected. */
    private fun text(a: Map<String, Any?>, key: String, max: Int, required: Boolean = false): String {
        val v = a[key]
        val s = when (v) {
            null -> ""
            is String -> v
            is Number, is Boolean -> v.toString()
            else -> throw Invalid("$key must be text")
        }
        val clean = s.map { if (it.isISOControl()) ' ' else it }.joinToString("").trim().take(max)
        if (required && clean.isEmpty()) throw Invalid("$key is empty")
        return clean
    }

    /** A contact name or a phone number. */
    private fun target(a: Map<String, Any?>, key: String): String {
        val t = text(a, key, 60, required = true)
        val ok = t.all { it.isLetterOrDigit() || it == ' ' || it in ".'’-_()+" }
        if (!ok) throw Invalid("$key has invalid characters")
        return t
    }

    private fun int(a: Map<String, Any?>, key: String): Int? {
        return when (val v = a[key]) {
            null -> null
            is Long -> if (v in Int.MIN_VALUE..Int.MAX_VALUE) v.toInt() else throw Invalid("$key out of range")
            is Double -> if (v == Math.floor(v) && Math.abs(v) < 1e9) v.toInt() else throw Invalid("$key not whole")
            is String -> v.trim().toIntOrNull() ?: throw Invalid("$key not a number")
            else -> throw Invalid("$key not a number")
        }
    }

    private fun bool(a: Map<String, Any?>, key: String): Boolean? {
        return when (val v = a[key]) {
            null -> null
            is Boolean -> v
            is String -> when (v.trim().lowercase()) {
                "true" -> true
                "false" -> false
                else -> throw Invalid("$key not boolean")
            }
            else -> throw Invalid("$key not boolean")
        }
    }

    private fun url(a: Map<String, Any?>, key: String): String {
        val u = text(a, key, 2000, required = true)
        val uri = try {
            URI(u)
        } catch (e: Exception) {
            throw Invalid("bad url")
        }
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") throw Invalid("url scheme")
        if (uri.host.isNullOrEmpty()) throw Invalid("url host")
        if (uri.userInfo != null) throw Invalid("url has credentials")
        return u
    }

    private fun dateTime(a: Map<String, Any?>, key: String): LocalDateTime? {
        val s = text(a, key, 32)
        if (s.isEmpty()) return null
        return try {
            LocalDateTime.parse(s)
        } catch (e: Exception) {
            throw Invalid("$key is not a date")
        }
    }

    companion object {
        const val MAX_PER_TURN = 4
        const val MAX_TEXT = 1000
        val SETTINGS_PAGES = setOf(
            "wifi", "bluetooth", "display", "sound", "battery", "location", "apps",
            "accessibility", "date", "language", "nfc", "airplane", "main"
        )
        val MUSIC_COMMANDS = setOf("play", "pause", "next", "previous")
    }
}
