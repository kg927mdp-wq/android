package app.xion.voice

/** Pure policy for turn-taking; kept independent of Android so it can be unit tested on the JVM. */
enum class VoiceFailure {
    NO_MATCH,
    SPEECH_TIMEOUT,
    RECOGNIZER_BUSY,
    NETWORK,
    PERMISSION,
    OTHER
}

object VoiceSessionPolicy {
    fun shouldResumeAfterReply(sourceWasVoice: Boolean, followUpRequested: Boolean, continuousEnabled: Boolean): Boolean =
        sourceWasVoice && (followUpRequested || continuousEnabled)

    fun shouldRetryListening(continuousEnabled: Boolean, failure: VoiceFailure): Boolean =
        continuousEnabled && failure in setOf(
            VoiceFailure.NO_MATCH,
            VoiceFailure.SPEECH_TIMEOUT,
            VoiceFailure.RECOGNIZER_BUSY
        )

    fun retryDelayMillis(failure: VoiceFailure): Long =
        if (failure == VoiceFailure.RECOGNIZER_BUSY) 1_200L else 650L
}
