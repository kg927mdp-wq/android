package app.xion.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import app.xion.ai.Brain
import app.xion.data.Config
import app.xion.ai.XionApp
import app.xion.ai.provider.Provider
import app.xion.device.ActionGateway
import app.xion.security.BackupCodec
import app.xion.security.BackupException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The Xion 2.1 settings screen, kept until the new Compose settings are verified on a device. Reachable from the new settings. */
class LegacySettingsActivity : Activity() {

    private lateinit var cfg: Config
    private val keyFields = HashMap<Provider, EditText>()
    private val modelFields = HashMap<Provider, EditText>()
    private val resultViews = HashMap<Provider, TextView>()
    private lateinit var primarySpinner: Spinner
    private lateinit var modeSpinner: Spinner
    private lateinit var langSpinner: Spinner
    private lateinit var searchSwitch: Switch
    private lateinit var tavilyField: EditText
    private lateinit var countryField: EditText
    private lateinit var directSwitch: Switch
    private lateinit var logView: TextView

    private val modeValues = listOf("instant", "careful", "fast")
    private val modeLabels = listOf(
        "فوري: يرد مباشرة ويراجع بالخلفية",
        "دقيق: نموذج ثاني يراجع قبل ما يرد",
        "سريع: بدون مراجعة"
    )
    private val langValues = listOf("ar-IQ", "ar-SA", "ar-AE", "ar-EG", "en-US", "")
    private val langLabels = listOf(
        "عربي – العراق", "عربي – السعودية", "عربي – الإمارات", "عربي – مصر", "English", "لغة الجهاز"
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------ small builders

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        val g = GradientDrawable()
        g.cornerRadius = dp(22).toFloat()
        g.setColor(Color.parseColor("#141A33"))
        g.setStroke(dp(1), Color.parseColor("#262D52"))
        c.background = g
        return c
    }

    private fun heading(text: String): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 16f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setTextColor(Color.WHITE)
        tv.setPadding(0, 0, 0, dp(6))
        return tv
    }

    private fun note(text: String, color: String = "#8F98C4"): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 13f
        tv.setTextColor(Color.parseColor(color))
        tv.setPadding(0, dp(6), 0, dp(2))
        return tv
    }

    private fun field(value: String, hint: String, secret: Boolean): EditText {
        val e = EditText(this)
        e.setText(value)
        e.hint = hint
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.parseColor("#5C6485"))
        e.isSingleLine = true
        e.layoutDirection = View.LAYOUT_DIRECTION_LTR
        e.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        e.inputType = if (secret) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT
        }
        val g = GradientDrawable()
        g.cornerRadius = dp(14).toFloat()
        g.setColor(Color.parseColor("#0C1126"))
        g.setStroke(dp(1), Color.parseColor("#2A3260"))
        e.background = g
        return e
    }

    private fun button(text: String, c1: String, c2: String, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.textSize = 16f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(Color.WHITE)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(16), dp(15), dp(16), dp(15))
        val g = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor(c1), Color.parseColor(c2))
        )
        g.cornerRadius = dp(16).toFloat()
        b.background = g
        b.setOnClickListener { onClick() }
        return b
    }

    private fun spinner(labels: List<String>, selected: Int): Spinner {
        val s = Spinner(this)
        val a = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        s.adapter = a
        s.setSelection(selected.coerceAtLeast(0))
        return s
    }

    private fun add(parent: LinearLayout, v: View, top: Int = 0) {
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = top
        parent.addView(v, lp)
    }

    // ------------------------------------------------------------------ screen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Config(this)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#070A18"))
        scroll.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(36), dp(18), dp(40))
        scroll.addView(
            col,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        // header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val orb = OrbView(this)
        header.addView(orb, LinearLayout.LayoutParams(dp(96), dp(96)))
        val titleBox = LinearLayout(this)
        titleBox.orientation = LinearLayout.VERTICAL
        titleBox.setPadding(dp(14), 0, 0, 0)
        val title = TextView(this)
        title.text = "Xion"
        title.textSize = 32f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        title.post {
            val w = title.width.toFloat().coerceAtLeast(1f)
            title.paint.shader = LinearGradient(
                0f, 0f, w, 0f,
                intArrayOf(PALETTE[3], PALETTE[0], PALETTE[1], PALETTE[2]),
                null,
                Shader.TileMode.CLAMP
            )
            title.invalidate()
        }
        titleBox.addView(title)
        titleBox.addView(note("مساعد صوتي ذكي متعدد النماذج"))
        header.addView(titleBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        add(col, header)

        // keys
        add(col, note("حط مفتاح واحد على الأقل. المفاتيح تنحفظ داخل جوالك فقط."), dp(10))
        for (p in Provider.values()) {
            val c = card()
            c.addView(heading("مفتاح " + p.label))
            val k = field(cfg.key(p), "API key", true)
            keyFields[p] = k
            add(c, k)
            val m = field(cfg.model(p), "اسم الموديل", false)
            modelFields[p] = m
            add(c, m, dp(8))
            val r = note("", "#7FE3C2")
            resultViews[p] = r
            add(c, r)
            add(col, c, dp(12))
        }

        // brain
        val brain = card()
        brain.addView(heading("طريقة التفكير"))
        brain.addView(note("أول نموذج يجاوب"))
        val providers = Provider.values().toList()
        primarySpinner = spinner(providers.map { it.label }, providers.indexOfFirst { it.name == cfg.primary })
        add(brain, primarySpinner)
        brain.addView(note("الوضع"))
        modeSpinner = spinner(modeLabels, modeValues.indexOf(cfg.mode))
        add(brain, modeSpinner)
        searchSwitch = Switch(this)
        searchSwitch.text = "البحث بالإنترنت للأخبار والأسعار"
        searchSwitch.setTextColor(Color.WHITE)
        searchSwitch.isChecked = cfg.searchEnabled
        searchSwitch.setPadding(0, dp(12), 0, dp(4))
        add(brain, searchSwitch)
        brain.addView(note("مفتاح Tavily (اختياري). بدونه يشتغل البحث بوضع مجاني محدود، ومعه أقوى. وإذا فشل Tavily يستخدم DuckDuckGo."))
        tavilyField = field(cfg.tavilyKey, "tvly-...", true)
        add(brain, tavilyField)
        add(col, brain, dp(12))

        // voice and region
        val voice = card()
        voice.addView(heading("الصوت والمنطقة"))
        voice.addView(note("لغة الكلام"))
        langSpinner = spinner(langLabels, langValues.indexOf(cfg.lang))
        add(voice, langSpinner)
        voice.addView(note("رمز دولتك للأرقام (العراق 964، السعودية 966)"))
        countryField = field(cfg.countryCode, "964", false)
        countryField.inputType = InputType.TYPE_CLASS_NUMBER
        add(voice, countryField)
        directSwitch = Switch(this)
        directSwitch.text = "بدء الاتصال فوراً بعد موافقتك (بدون لوحة الأرقام)"
        directSwitch.setTextColor(Color.WHITE)
        directSwitch.isChecked = cfg.directCall
        directSwitch.setPadding(0, dp(12), 0, dp(4))
        add(voice, directSwitch)
        add(col, voice, dp(12))

        // actions
        add(col, button("حفظ", "#5B6CFF", "#A06BFF") {
            if (save()) toast("انحفظت الإعدادات") else toast("تعذّر تخزين أحد المفاتيح بأمان، لم يُحفظ")
        }, dp(20))
        add(col, button("اختبر المفاتيح", "#263058", "#2E3A6E") { testKeys() }, dp(10))
        add(col, button("إعطاء الصلاحيات", "#263058", "#2E3A6E") { askPermissions() }, dp(10))
        add(col, button("سجل الإجراءات", "#263058", "#2E3A6E") { showAudit() }, dp(10))
        add(col, button("نسخة احتياطية مشفّرة", "#263058", "#2E3A6E") { exportBackup() }, dp(10))
        add(col, button("استعادة نسخة احتياطية", "#263058", "#2E3A6E") { importBackup() }, dp(10))
        add(col, button("اجعل Xion المساعد الافتراضي", "#0E9F8E", "#3DE3D0") { openAssistantSettings() }, dp(10))
        add(col, button("جرّب المساعد الحين", "#A06BFF", "#FF5FA8") {
            save()
            startActivity(Intent(this, AssistantActivity::class.java))
        }, dp(10))

        logView = note("")
        add(col, logView, dp(10))
        add(
            col,
            note(
                "بعد ما تختاره مساعد افتراضي: اضغط مطولاً على زر الهوم أو الباور حسب جوالك. " +
                    "إذا طلعت «اسم الموديل غلط» غيّر الاسم من الحقل تحت المفتاح."
            )
        )

        setContentView(scroll)
    }

    private fun toast(msg: String) {
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()
    }

    /** Returns false when a key could not be stored securely. */
    private fun save(): Boolean {
        var ok = true
        for (p in Provider.values()) {
            if (!cfg.setKey(p, keyFields[p]?.text?.toString() ?: "")) ok = false
            cfg.setModel(p, modelFields[p]?.text?.toString() ?: "")
        }
        val provs = Provider.values()
        cfg.primary = provs[primarySpinner.selectedItemPosition.coerceIn(0, provs.size - 1)].name
        cfg.mode = modeValues[modeSpinner.selectedItemPosition.coerceIn(0, modeValues.size - 1)]
        cfg.searchEnabled = searchSwitch.isChecked
        if (!cfg.setTavilyKey(tavilyField.text.toString())) ok = false
        cfg.lang = langValues[langSpinner.selectedItemPosition.coerceIn(0, langValues.size - 1)]
        val cc = countryField.text.toString()
        if (cc.isNotBlank()) cfg.countryCode = cc
        cfg.directCall = directSwitch.isChecked
        Brain.clearHistory(this)
        for (p in Provider.values()) XionApp.orchestrator(this).stats.resetHealth(p)
        return ok
    }

    private fun testKeys() {
        save()
        for (p in Provider.values()) {
            resultViews[p]?.setTextColor(Color.parseColor("#8F98C4"))
            resultViews[p]?.text = "أختبر…"
        }
        val app = applicationContext
        Thread {
            for (p in Provider.values()) {
                val res = Brain.ping(app, p)
                runOnUiThread {
                    val v = resultViews[p]
                    if (v != null) {
                        v.text = res
                        v.setTextColor(Color.parseColor(if (res.contains("✓")) "#7FE3C2" else "#FF8A80"))
                    }
                }
            }
        }.start()
    }

    private fun askPermissions() {
        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE
            ),
            1
        )
    }

    // ------------------------------------------------------------ audit log and backup

    private fun outcomeLabel(o: String): String = when (o) {
        "executed" -> "نُفّذ"
        "confirmed" -> "نُفّذ بموافقتك"
        "denied" -> "رُفض"
        "asked" -> "طُلبت موافقتك"
        "rejected" -> "مرفوض أمنياً"
        "failed" -> "فشل"
        else -> o
    }

    private fun showAudit() {
        val audit = ActionGateway.auditFor(this)
        val items = audit.recent(30)
        val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
        val text = if (items.isEmpty()) {
            "لا توجد إجراءات مسجّلة بعد."
        } else {
            items.joinToString("\n\n") {
                fmt.format(Date(it.time)) + "  " + it.type + "  " + outcomeLabel(it.outcome) + "\n" + it.note
            }
        }
        AlertDialog.Builder(this)
            .setTitle("سجل الإجراءات")
            .setMessage(text)
            .setPositiveButton("إغلاق", null)
            .setNeutralButton("مسح السجل") { _, _ -> audit.clear() }
            .show()
    }

    private fun exportBackup() {
        save()
        val pass = field("", "عبارة المرور (8 أحرف على الأقل)", true)
        AlertDialog.Builder(this)
            .setTitle("نسخة احتياطية مشفّرة")
            .setMessage("تحتوي النسخة على مفاتيحك وإعداداتك وهي مشفّرة بعبارة المرور. لا يمكن استرجاعها إذا نسيتها.")
            .setView(pass)
            .setPositiveButton("إنشاء") { _, _ ->
                val chars = CharArray(pass.text.length)
                pass.text.getChars(0, chars.size, chars, 0)
                Thread {
                    try {
                        val blob = BackupCodec.encrypt(cfg.exportJson(), chars)
                        runOnUiThread {
                            val send = Intent(Intent.ACTION_SEND)
                                .setType("text/plain")
                                .putExtra(Intent.EXTRA_TEXT, blob)
                            startActivity(Intent.createChooser(send, "حفظ النسخة المشفّرة"))
                        }
                    } catch (e: BackupException) {
                        runOnUiThread { toast("عبارة المرور قصيرة (8 أحرف على الأقل)") }
                    } catch (e: Exception) {
                        runOnUiThread { toast("تعذّر إنشاء النسخة") }
                    } finally {
                        chars.fill('0')
                    }
                }.start()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun importBackup() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(8), dp(18), 0)
        val blobField = field("", "الصق النسخة المشفّرة هنا", false)
        val passField = field("", "عبارة المرور", true)
        add(box, blobField)
        add(box, passField, dp(8))
        AlertDialog.Builder(this)
            .setTitle("استعادة نسخة احتياطية")
            .setView(box)
            .setPositiveButton("استعادة") { _, _ ->
                val blob = blobField.text.toString()
                val chars = CharArray(passField.text.length)
                passField.text.getChars(0, chars.size, chars, 0)
                Thread {
                    try {
                        val json = BackupCodec.decrypt(blob, chars)
                        val ok = cfg.importJson(json)
                        runOnUiThread {
                            toast(if (ok) "تمت الاستعادة" else "تعذّر تخزين بعض المفاتيح بأمان")
                            recreate()
                        }
                    } catch (e: BackupException) {
                        runOnUiThread { toast("عبارة المرور خاطئة أو النسخة تالفة") }
                    } catch (e: Exception) {
                        runOnUiThread { toast("تعذّرت الاستعادة") }
                    } finally {
                        chars.fill('0')
                    }
                }.start()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun openAssistantSettings() {
        try {
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            logView.text = "اختر «Xion» من قائمة تطبيق المساعد الرقمي."
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                logView.text = "ادخل: التطبيقات الافتراضية ← تطبيق المساعد الرقمي ← Xion."
            } catch (e2: Exception) {
                logView.text = "ما قدرت أفتح الإعدادات."
            }
        }
    }
}
