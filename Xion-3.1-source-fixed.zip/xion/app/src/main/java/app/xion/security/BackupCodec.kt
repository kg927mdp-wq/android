package app.xion.security

import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class BackupException(message: String) : Exception(message)

/**
 * Passphrase-protected export of Xion's settings and API keys, so they can be moved to another phone or
 * another install without ever existing as readable text. PBKDF2-HMAC-SHA256 derives the key, AES-256-GCM
 * encrypts and authenticates. The passphrase is never stored.
 *
 * Format: XIONBK1.<salt>.<iterations>.<iv>.<ciphertext>   (base64url, no padding)
 */
object BackupCodec {
    private const val MAGIC = "XIONBK1"
    const val MIN_PASSPHRASE = 8
    private const val ITERATIONS = 210_000
    private const val MIN_ITER = 100_000
    private const val MAX_ITER = 1_000_000
    private const val SALT_BYTES = 16
    private const val IV_BYTES = 12
    private const val MAX_BLOB = 64_000

    private fun derive(pass: CharArray, salt: ByteArray, iter: Int): SecretKeySpec {
        val spec = PBEKeySpec(pass, salt, iter, 256)
        try {
            val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            return SecretKeySpec(f.generateSecret(spec).encoded, "AES")
        } finally {
            spec.clearPassword()
        }
    }

    fun encrypt(plain: String, pass: CharArray, random: SecureRandom = SecureRandom()): String {
        if (pass.size < MIN_PASSPHRASE) throw BackupException("passphrase too short")
        val salt = ByteArray(SALT_BYTES).also { random.nextBytes(it) }
        val iv = ByteArray(IV_BYTES).also { random.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, derive(pass, salt, ITERATIONS), GCMParameterSpec(128, iv))
        c.updateAAD(MAGIC.toByteArray(Charsets.UTF_8))
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        val e = Base64.getUrlEncoder().withoutPadding()
        return listOf(MAGIC, e.encodeToString(salt), ITERATIONS.toString(), e.encodeToString(iv), e.encodeToString(ct))
            .joinToString(".")
    }

    /** Throws [BackupException] for a wrong passphrase, a damaged blob, or anything that is not a Xion backup. */
    fun decrypt(blob: String, pass: CharArray): String {
        val t = blob.trim()
        if (t.length > MAX_BLOB) throw BackupException("not a Xion backup")
        val p = t.split('.')
        if (p.size != 5 || p[0] != MAGIC) throw BackupException("not a Xion backup")
        try {
            val d = Base64.getUrlDecoder()
            val salt = d.decode(p[1])
            val iter = p[2].toInt()
            val iv = d.decode(p[3])
            val ct = d.decode(p[4])
            if (iter !in MIN_ITER..MAX_ITER || salt.size != SALT_BYTES || iv.size != IV_BYTES) {
                throw BackupException("not a Xion backup")
            }
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, derive(pass, salt, iter), GCMParameterSpec(128, iv))
            c.updateAAD(MAGIC.toByteArray(Charsets.UTF_8))
            return String(c.doFinal(ct), Charsets.UTF_8)
        } catch (e: BackupException) {
            throw e
        } catch (e: Exception) {
            throw BackupException("wrong passphrase or damaged backup")
        }
    }
}
