package app.xion.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import app.xion.ai.Brain
import app.xion.ai.BrainListener
import app.xion.data.Config
import app.xion.device.ActionGateway
import app.xion.security.Action
import app.xion.security.Decision
import app.xion.voice.ConfirmationMatcher
import app.xion.voice.GOOGLE_RECOGNIZER
import app.xion.voice.Verdict
import java.util.Locale
import java.util.concurrent.Executors

class AssistantActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var cfg: Config
    private lateinit var orb: OrbView
    private lateinit var glow: GlowBarView
    private lateinit var mic: MicButton
    private lateinit var sheet: LinearLayout
    private lateinit var scrim: View
    private lateinit var statusView: TextView
    private lateinit var userView: TextView
    private lateinit var replyView: TextView
    private lateinit var confirmBox: LinearLayout
    private lateinit var confirmText: TextView

    // actions that need the user's approval before they run
    private var gateway: ActionGateway? = null
    private val confirmQueue = ArrayDeque<Decision.Confirm>()
    private var confirmCurrent: Decision.Confirm? = null
    private var confirmListening = false
    private var confirmUnheard = 0

    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newCachedThreadPool()

    private var recognizer: SpeechRecognizer? = null
    private var usingGoogle = true

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsFailed = false
    private val queued = ArrayList<String>()
    private var utteranceSeq = 0

    private var state = OrbState.IDLE
    private var requestId = 0
    private var pending = 0
    private var streamDone = false
    private var wantFollowUp = false
    private var leftApp = false
    private var actionCount = 0
    private var spokeAnything = false
    private var destroyed = false
    private val replyBuf = StringBuilder()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ UI

    private fun glassPill(label: String, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.parseColor("#DDE3FF"))
        tv.textSize = 14f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(18), dp(11), dp(18), dp(11))
        val g = GradientDrawable()
        g.cornerRadius = dp(22).toFloat()
        g.setColor(Color.parseColor("#1FFFFFFF"))
        g.setStroke(dp(1), Color.parseColor("#26FFFFFF"))
        tv.background = g
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun buildUi(): View {
        val root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL

        scrim = View(this)
        scrim.setBackgroundColor(Color.parseColor("#80000000"))
        scrim.alpha = 0f
        scrim.setOnClickListener { finish() }
        root.addView(scrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        sheet = LinearLayout(this)
        sheet.orientation = LinearLayout.VERTICAL
        sheet.gravity = Gravity.CENTER_HORIZONTAL
        sheet.isClickable = true
        sheet.setPadding(dp(22), dp(10), dp(22), dp(34))
        val r = dp(34).toFloat()
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#F4161B38"), Color.parseColor("#F40A0D1F"))
        )
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        bg.setStroke(dp(1), Color.parseColor("#2AFFFFFF"))
        sheet.background = bg

        val handle = View(this)
        val hg = GradientDrawable()
        hg.cornerRadius = dp(3).toFloat()
        hg.setColor(Color.parseColor("#40FFFFFF"))
        handle.background = hg
        sheet.addView(handle, LinearLayout.LayoutParams(dp(40), dp(4)))

        orb = OrbView(this)
        val olp = LinearLayout.LayoutParams(dp(210), dp(210))
        olp.topMargin = dp(8)
        sheet.addView(orb, olp)

        statusView = TextView(this)
        statusView.textSize = 13f
        statusView.setTextColor(Color.parseColor("#BFC8F5"))
        statusView.gravity = Gravity.CENTER
        statusView.setPadding(dp(16), dp(6), dp(16), dp(6))
        val sg = GradientDrawable()
        sg.cornerRadius = dp(16).toFloat()
        sg.setColor(Color.parseColor("#1AFFFFFF"))
        statusView.background = sg
        sheet.addView(statusView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        userView = TextView(this)
        userView.textSize = 14f
        userView.setTextColor(Color.parseColor("#8F98C4"))
        userView.gravity = Gravity.CENTER
        userView.maxLines = 2
        userView.setPadding(0, dp(12), 0, 0)
        sheet.addView(userView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        replyView = TextView(this)
        replyView.textSize = 20f
        replyView.setTextColor(Color.WHITE)
        replyView.gravity = Gravity.CENTER
        replyView.minLines = 2
        replyView.maxLines = 8
        replyView.setLineSpacing(0f, 1.15f)
        replyView.setPadding(0, dp(8), 0, dp(16))
        sheet.addView(replyView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        confirmBox = LinearLayout(this)
        confirmBox.orientation = LinearLayout.VERTICAL
        confirmBox.gravity = Gravity.CENTER_HORIZONTAL
        confirmBox.visibility = View.GONE
        confirmBox.setPadding(dp(16), dp(14), dp(16), dp(14))
        val cg = GradientDrawable()
        cg.cornerRadius = dp(22).toFloat()
        cg.setColor(Color.parseColor("#26FFFFFF"))
        cg.setStroke(dp(1), Color.parseColor("#805B6CFF"))
        confirmBox.background = cg
        confirmText = TextView(this)
        confirmText.textSize = 15f
        confirmText.setTextColor(Color.WHITE)
        confirmText.gravity = Gravity.CENTER
        confirmBox.addView(confirmText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val confirmRow = LinearLayout(this)
        confirmRow.orientation = LinearLayout.HORIZONTAL
        confirmRow.gravity = Gravity.CENTER
        val confirmLp = {
            val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            p.setMargins(dp(8), dp(12), dp(8), 0)
            p
        }
        confirmRow.addView(glassPill("نفّذ") { onConfirm(true) }, confirmLp())
        confirmRow.addView(glassPill("إلغاء") { onConfirm(false) }, confirmLp())
        confirmBox.addView(confirmRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val boxLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        boxLp.bottomMargin = dp(16)
        sheet.addView(confirmBox, boxLp)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        mic = MicButton(this)
        mic.setOnClickListener { onMicClick() }
        val pillLp = {
            val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            p.setMargins(dp(8), 0, dp(8), 0)
            p
        }
        row.addView(glassPill("الإعدادات") {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, pillLp())
        row.addView(mic, LinearLayout.LayoutParams(dp(84), dp(84)))
        row.addView(glassPill("إغلاق") { finish() }, pillLp())
        sheet.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        sheet.translationY = dp(620).toFloat()
        root.addView(
            sheet,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )

        glow = GlowBarView(this)
        root.addView(
            glow,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170), Gravity.BOTTOM)
        )
        return root
    }

    private fun setState(s: OrbState, status: String) {
        state = s
        orb.state = s
        glow.state = s
        mic.state = s
        statusView.text = status
    }

    private fun playEntrance() {
        scrim.animate().alpha(1f).setDuration(300).start()
        sheet.animate().translationY(0f).setDuration(420).setInterpolator(DecelerateInterpolator(2f)).start()
    }

    private fun showReply() {
        replyView.text = replyBuf.toString()
        replyView.alpha = 0.55f
        replyView.animate().alpha(1f).setDuration(180).start()
    }

    // ------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Config(this)
        setContentView(buildUi())
        setState(OrbState.IDLE, "جاهز")
        playEntrance()
        tts = TextToSpeech(this, this)
        startListening()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        startListening()
    }

    override fun onStop() {
        super.onStop()
        if (!leftApp && !isChangingConfigurations) finish()
    }

    override fun onDestroy() {
        destroyed = true
        requestId++
        dropConfirmations()
        destroyRecognizer()
        tts?.stop()
        tts?.shutdown()
        tts = null
        worker.shutdownNow()
        super.onDestroy()
    }

    // ---------------------------------------------------------- permissions

    private fun hasMic(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasMic()) {
            startListening()
        } else {
            setState(OrbState.IDLE, "ما عندي صلاحية الميكروفون")
            replyView.text = "افتح إعدادات التطبيق وفعّل الميكروفون"
        }
    }

    // ------------------------------------------------------------ listening

    private fun onMicClick() {
        mic.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        if (confirmCurrent != null) {
            // an approval is waiting: the microphone answers it instead of starting a new request
            confirmUnheard = 0
            startListening(keepConfirm = true)
            return
        }
        requestId++
        resetSpeech()
        startListening()
    }

    private fun resetSpeech() {
        dropConfirmations()
        stopSpeech()
    }

    private fun stopSpeech() {
        tts?.stop()
        queued.clear()
        pending = 0
    }

    private fun destroyRecognizer() {
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
            // ignore
        }
        recognizer = null
    }

    private fun makeRecognizer(): SpeechRecognizer {
        if (usingGoogle) {
            try {
                packageManager.getServiceInfo(GOOGLE_RECOGNIZER, 0)
                return SpeechRecognizer.createSpeechRecognizer(this, GOOGLE_RECOGNIZER)
            } catch (e: Exception) {
                usingGoogle = false
            }
        }
        return SpeechRecognizer.createSpeechRecognizer(this)
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            val v = (rmsdB + 2f) / 12f
            orb.setLevel(v)
            glow.setLevel(v)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            orb.setLevel(0f)
            glow.setLevel(0f)
        }

        override fun onError(error: Int) {
            if (confirmCurrent != null) {
                confirmListening = false
                onConfirmNotUnderstood()
                return
            }
            handleError(error)
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (confirmCurrent != null) {
                confirmListening = false
                handleVoiceConfirm(list ?: ArrayList(), results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES))
                return
            }
            val t = (list?.firstOrNull() ?: "").trim()
            if (t.isEmpty()) handleError(SpeechRecognizer.ERROR_NO_MATCH) else process(t)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val t = list?.firstOrNull()
            if (!t.isNullOrEmpty()) userView.text = t
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun startListening(keepConfirm: Boolean = false) {
        if (destroyed) return
        leftApp = false
        if (!cfg.anyKey()) {
            setState(OrbState.IDLE, "ما في مفتاح محفوظ")
            replyView.text = "افتح الإعدادات وحط مفتاح واحد على الأقل"
            return
        }
        if (!hasMic()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
            return
        }
        if (keepConfirm) stopSpeech() else resetSpeech()
        destroyRecognizer()
        val r = makeRecognizer()
        recognizer = r
        r.setRecognitionListener(recognitionListener)

        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        if (keepConfirm) i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        val lang = cfg.lang
        if (lang.isNotEmpty()) {
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
        }
        try {
            r.startListening(i)
            if (keepConfirm) {
                confirmListening = true
                setState(OrbState.LISTENING, "قل نعم أو لا")
            } else {
                setState(OrbState.LISTENING, "أسمعك…")
                userView.text = ""
                replyBuf.setLength(0)
                replyView.text = ""
            }
        } catch (e: Exception) {
            setState(OrbState.IDLE, "ما قدرت أشغل الميكروفون")
        }
    }

    private fun handleError(error: Int) {
        if (destroyed) return
        if (error == SpeechRecognizer.ERROR_CLIENT && usingGoogle) {
            // Google's recogniser could not be used on this phone, fall back to the default one once
            usingGoogle = false
            startListening()
            return
        }
        val msg = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                "ما سمعت شي. اضغط الميكروفون وجرّب مرة ثانية"
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                "في مشكلة بالإنترنت"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                "أحتاج صلاحية الميكروفون"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                "التعرف على الصوت مشغول، جرّب بعد ثانية"
            else -> "تعذّر التعرف على الصوت (رمز $error)"
        }
        setState(OrbState.IDLE, "جاهز")
        replyView.text = msg
    }

    // ------------------------------------------------------------- thinking

    private fun alive(id: Int): Boolean = !destroyed && id == requestId

    private fun process(text: String) {
        userView.text = text
        replyBuf.setLength(0)
        replyView.text = ""
        streamDone = false
        wantFollowUp = false
        actionCount = 0
        spokeAnything = false
        pending = 0
        queued.clear()
        dropConfirmations()
        setState(OrbState.THINKING, "أفكّر…")
        val id = ++requestId
        val app = applicationContext
        gateway = ActionGateway(this)

        val l = object : BrainListener {
            override fun isCancelled(): Boolean = !alive(id)

            override fun onSearching(query: String) {
                ui.post { if (alive(id)) setState(OrbState.THINKING, "أبحث في الإنترنت…") }
            }

            override fun onSentence(text: String) {
                ui.post { if (alive(id)) addSentence(text) }
            }

            override fun onAction(action: Map<String, Any?>, tainted: Boolean) {
                ui.post { if (alive(id)) handleProposal(action, tainted) }
            }

            override fun onDone(followUp: Boolean) {
                ui.post {
                    if (alive(id)) {
                        streamDone = true
                        wantFollowUp = followUp
                        maybeFinish()
                    }
                }
            }

            override fun onCorrection(text: String) {
                ui.post { if (alive(id) && state == OrbState.IDLE) addCorrection(text) }
            }

            override fun onFailure(message: String) {
                ui.post {
                    if (alive(id)) {
                        addSentence(message)
                        streamDone = true
                        wantFollowUp = false
                        maybeFinish()
                    }
                }
            }
        }
        try {
            worker.execute {
                try {
                    Brain.ask(app, text, l)
                } catch (e: Exception) {
                    l.onFailure("صار خطأ غير متوقع، جرّب مرة ثانية.")
                }
            }
        } catch (e: Exception) {
            setState(OrbState.IDLE, "جاهز")
        }
    }

    private fun addSentence(t: String) {
        if (replyBuf.isNotEmpty()) replyBuf.append(' ')
        replyBuf.append(t)
        showReply()
        speak(t)
    }

    private fun addCorrection(t: String) {
        val msg = "تصحيح: $t"
        replyBuf.append("\n\n").append(msg)
        showReply()
        speak(msg)
    }

    /** A model only ever proposes. The gateway validates it and decides: run, ask the user, or refuse. */
    private fun handleProposal(raw: Map<String, Any?>, tainted: Boolean) {
        val gw = gateway ?: return
        when (val d = gw.propose(raw, tainted)) {
            is Decision.Allow -> runAction(gw, d.action, false)
            is Decision.Confirm -> {
                confirmQueue.addLast(d)
                showNextConfirm()
            }
            is Decision.Reject -> addSentence("ما أقدر أنفذ هذا الأمر.")
        }
    }

    private fun runAction(gw: ActionGateway, a: Action, confirmed: Boolean) {
        actionCount++
        val r = gw.execute(a, confirmed)
        if (r.leftApp) leftApp = true
        if (!r.ok && r.message.isNotBlank()) addSentence(r.message)
    }

    private fun showNextConfirm() {
        if (confirmCurrent != null) return
        val d = confirmQueue.removeFirstOrNull()
        if (d == null) {
            confirmBox.visibility = View.GONE
            maybeFinish()
            return
        }
        confirmCurrent = d
        confirmUnheard = 0
        confirmText.text = d.action.describe() + "\n(" + d.reason + ")"
        confirmBox.visibility = View.VISIBLE
        speak(if (d.action is Action.OpenUrl) "أحتاج موافقتك لفتح رابط." else "أحتاج موافقتك: " + d.action.describe())
    }

    private fun onConfirm(accept: Boolean) {
        val d = confirmCurrent ?: return
        confirmCurrent = null
        val gw = gateway
        if (accept && gw != null) runAction(gw, d.action, true) else gw?.deny(d.action)
        showNextConfirm()
    }

    /**
     * A spoken answer to an approval. Only a clear "yes" approves (see [ConfirmationMatcher]); a clear "no" refuses;
     * anything else leaves the buttons in charge after one more attempt.
     */
    private fun handleVoiceConfirm(alternatives: List<String>, confidences: FloatArray?) {
        when (ConfirmationMatcher.interpret(alternatives, confidences)) {
            Verdict.YES -> onConfirm(true)
            Verdict.NO -> onConfirm(false)
            Verdict.UNSURE -> onConfirmNotUnderstood()
        }
    }

    private fun onConfirmNotUnderstood() {
        confirmUnheard++
        if (confirmUnheard < 2 && hasMic()) {
            replyView.text = "ما فهمت. قل نعم أو لا، أو اضغط الزر."
            startListening(keepConfirm = true)
        } else {
            setState(OrbState.IDLE, "اضغط نفّذ أو إلغاء")
        }
    }

    /** Pending approvals are cancelled (and logged as denied) when a new request starts or the screen closes. */
    private fun dropConfirmations() {
        val gw = gateway
        val cur = confirmCurrent
        if (gw != null) {
            if (cur != null) gw.deny(cur.action)
            for (d in confirmQueue) gw.deny(d.action)
        }
        confirmCurrent = null
        confirmQueue.clear()
        if (::confirmBox.isInitialized) confirmBox.visibility = View.GONE
    }

    private fun maybeFinish() {
        if (destroyed || !streamDone || pending > 0) return
        if (confirmCurrent != null) {
            setState(OrbState.IDLE, "بانتظار موافقتك")
            if (!confirmListening && confirmUnheard == 0 && hasMic()) startListening(keepConfirm = true)
            return
        }
        if (!spokeAnything && actionCount > 0 && !leftApp) {
            addSentence("تم")
            return
        }
        if (leftApp) {
            finish()
            return
        }
        if (wantFollowUp) {
            wantFollowUp = false
            startListening()
        } else {
            setState(OrbState.IDLE, "اضغط الميكروفون للمتابعة")
        }
    }

    // -------------------------------------------------------------- speaking

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            ttsFailed = true
            ttsReady = false
            queued.clear()
            pending = 0
            maybeFinish()
            return
        }
        val lang = cfg.lang
        val loc = if (lang.isEmpty()) Locale.getDefault() else Locale.forLanguageTag(lang)
        val res = t.setLanguage(loc)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(Locale("ar"))
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                spokenDone(utteranceId)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                spokenDone(utteranceId)
            }
        })
        ttsReady = true
        val list = ArrayList(queued)
        queued.clear()
        for (s in list) speakNow(s)
    }

    private fun spokenDone(utteranceId: String?) {
        val owner = utteranceId?.substringBefore(':') ?: return
        ui.post {
            if (!destroyed && owner == requestId.toString()) {
                if (pending > 0) pending--
                if (pending == 0) maybeFinish()
            }
        }
    }

    private fun speak(text: String) {
        spokeAnything = true
        setState(OrbState.SPEAKING, "أتكلم…")
        if (ttsFailed) return
        pending++
        if (ttsReady) speakNow(text) else queued.add(text)
    }

    private fun speakNow(text: String) {
        val id = requestId.toString() + ":" + (utteranceSeq++)
        tts?.speak(text.take(3500), TextToSpeech.QUEUE_ADD, Bundle(), id)
    }
}
