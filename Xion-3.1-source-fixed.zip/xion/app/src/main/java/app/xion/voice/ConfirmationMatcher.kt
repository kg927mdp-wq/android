package app.xion.voice

enum class Verdict { YES, NO, UNSURE }

/**
 * Decides whether a spoken reply approves or refuses an action. Approving is deliberately hard and refusing is
 * deliberately easy, because a misheard "yes" can do harm and a misheard "no" only costs a second tap:
 *  - YES needs the whole utterance to be one of a short list of approval phrases (no sentences, no "yes but");
 *  - YES is dropped when any alternative recognition result says "no" or something else entirely;
 *  - YES is dropped when the recogniser reports a confidence below [MIN_CONFIDENCE];
 *  - any alternative that clearly says "no" is a NO.
 */
object ConfirmationMatcher {
    const val MIN_CONFIDENCE = 0.7f

    private val yes = setOf(
        "نعم", "ايوه", "ايوا", "اي", "ايه", "نفذ", "نفذه", "نفذها", "تمام", "موافق", "اوكي", "اوك", "اكيد", "طبعا", "ايوه نفذ", "نعم نفذ",
        "yes", "yeah", "yep", "ok", "okay", "confirm", "do it", "go ahead", "sure", "yes do it", "yes please"
    )
    private val no = setOf(
        "لا", "لأ", "كلا", "الغاء", "الغي", "الغيه", "الغيها", "وقف", "ارفض", "رفض", "لا تنفذ", "لا تنفذه", "لا تنفذها", "مو موافق", "ماكو",
        "no", "nope", "cancel", "stop", "don't", "dont", "do not", "abort", "no thanks", "never mind"
    )

    fun normalize(s: String): String {
        val sb = StringBuilder()
        for (c in s.trim().lowercase()) {
            when {
                c in 'ً'..'ٟ' || c == 'ـ' -> {}      // diacritics, tatweel
                c == 'أ' || c == 'إ' || c == 'آ' -> sb.append('ا')
                c == 'ة' -> sb.append('ه')
                c == 'ى' -> sb.append('ي')
                c.isLetterOrDigit() || c == ' ' || c == '\'' -> sb.append(c)
                else -> sb.append(' ')
            }
        }
        return sb.toString().trim().replace(Regex("\\s+"), " ")
    }

    private fun one(s: String): Verdict {
        val n = normalize(s)
        return when {
            n in no -> Verdict.NO
            n in yes -> Verdict.YES
            else -> Verdict.UNSURE
        }
    }

    /** [alternatives] are the recogniser's results, best first. [confidences] may be null or contain -1 for "unknown". */
    fun interpret(alternatives: List<String>, confidences: FloatArray? = null): Verdict {
        if (alternatives.isEmpty()) return Verdict.UNSURE
        val verdicts = alternatives.map { one(it) }
        if (Verdict.NO in verdicts) return Verdict.NO
        if (verdicts[0] != Verdict.YES) return Verdict.UNSURE
        if (verdicts.any { it != Verdict.YES }) return Verdict.UNSURE
        val c = confidences?.firstOrNull()
        if (c != null && c >= 0f && c < MIN_CONFIDENCE) return Verdict.UNSURE
        return Verdict.YES
    }
}
