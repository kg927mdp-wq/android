package app.xion.ai.provider

/**
 * How a provider is billed. Only what has been checked against the provider's own documentation is stated;
 * everything else is [UNVERIFIED] and shown as such. Xion never assumes a service is free or unlimited.
 */
enum class Billing { UNVERIFIED }

/**
 * The AI services Xion can talk to. Each one is reached through an adapter ([OpenAiCompatAdapter] for all
 * entries below, because they expose an OpenAI-style chat API). Native adapters for incompatible APIs
 * (Anthropic, Cohere, Cloudflare Workers AI...) plug in through [ProviderAdapter] and are not implemented yet.
 *
 * [defaultModel] is only set for the providers Xion 2.1 already shipped with. For the others the user picks a
 * model from the list the provider itself returns ([modelsUrl]); no model id is hardcoded for them.
 * [docsChecked] is true only for URLs confirmed in the provider's official documentation during development.
 */
enum class Provider(
    val label: String,
    val url: String,
    val modelsUrl: String?,
    val defaultModel: String,
    val docsChecked: Boolean = false,
    val billing: Billing = Billing.UNVERIFIED
) {
    DEEPSEEK("DeepSeek", "https://api.deepseek.com/chat/completions", "https://api.deepseek.com/models", "deepseek-chat"),
    GEMINI(
        "Gemini",
        "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
        "https://generativelanguage.googleapis.com/v1beta/openai/models",
        "gemini-flash-latest"
    ),
    GROK("Grok", "https://api.x.ai/v1/chat/completions", "https://api.x.ai/v1/models", "grok-4.7"),
    OPENROUTER(
        "OpenRouter",
        "https://openrouter.ai/api/v1/chat/completions",
        "https://openrouter.ai/api/v1/models",
        "",
        docsChecked = true
    ),
    GROQ("Groq", "https://api.groq.com/openai/v1/chat/completions", "https://api.groq.com/openai/v1/models", ""),
    MISTRAL("Mistral AI", "https://api.mistral.ai/v1/chat/completions", "https://api.mistral.ai/v1/models", ""),
    CEREBRAS("Cerebras", "https://api.cerebras.ai/v1/chat/completions", "https://api.cerebras.ai/v1/models", ""),
    TOGETHER("Together AI", "https://api.together.xyz/v1/chat/completions", "https://api.together.xyz/v1/models", "");

    /** Extra request headers the provider documents as optional or required. */
    val extraHeaders: Map<String, String>
        get() = if (this == OPENROUTER) mapOf("X-Title" to "Xion") else emptyMap()

    /** Request fields Xion 2.1 already sent to this provider (kept for identical behaviour). */
    val bodyDefaults: Map<String, Any?>
        get() = if (this == DEEPSEEK) mapOf("temperature" to 0.3, "max_tokens" to 2000) else emptyMap()

    companion object {
        fun fromName(n: String?): Provider? = values().firstOrNull { it.name == n }
    }
}
