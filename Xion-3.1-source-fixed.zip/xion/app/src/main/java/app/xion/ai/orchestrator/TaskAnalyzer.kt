package app.xion.ai.orchestrator

enum class TaskType(val label: String) {
    COMMAND("أمر للجهاز"),
    CHAT("محادثة"),
    CODE("برمجة"),
    REASONING("تحليل وتفكير"),
    LIVE_INFO("معلومة حديثة")
}

data class TaskProfile(val type: TaskType, val approxTokens: Int, val longContext: Boolean)

/**
 * Looks at the request and says what kind of work it is. This is a keyword and length heuristic, not a model:
 * it only decides which routing rule applies, never what the answer is.
 */
object TaskAnalyzer {

    private val code = listOf(
        "```", "kotlin", "python", "javascript", "java ", "function", "compile", "stack trace", "exception", "regex", "sql",
        "كود", "برمجة", "اكتب برنامج", "دالة", "خطأ برمجي", "سكربت"
    )
    private val live = listOf(
        "سعر", "اخبار", "أخبار", "طقس", "الطقس", "نتيجة", "مباراة", "اليوم", "الآن", "حاليا", "حالياً",
        "price", "news", "weather", "score", "today", "latest", "right now", "current"
    )
    private val reasoning = listOf(
        "حلل", "قارن", "اشرح لي", "ليش", "لماذا", "استنتج", "برهن", "خطة", "مزايا وعيوب",
        "analyze", "compare", "explain why", "prove", "step by step", "pros and cons", "plan "
    )
    private val command = listOf(
        "افتح", "اتصل", "كلم", "نبهني", "نبّهني", "شغل", "شغّل", "اطفي", "أطفئ", "ارسل", "أرسل", "ضبط", "اضبط", "وقف", "ارفع", "اخفض",
        "open ", "call ", "set alarm", "set a timer", "turn on", "turn off", "text ", "send ", "play ", "pause"
    )

    /** [historyChars] is the size of the conversation that will be sent along with the request. */
    fun analyze(text: String, historyChars: Int): TaskProfile {
        val t = text.lowercase().trim()
        val tokens = (t.length + historyChars) / 4
        val type = when {
            code.any { t.contains(it) } -> TaskType.CODE
            t.length <= 80 && command.any { t.startsWith(it) || t.contains(" $it") } -> TaskType.COMMAND
            live.any { t.contains(it) } -> TaskType.LIVE_INFO
            t.length > 300 || reasoning.any { t.contains(it) } -> TaskType.REASONING
            else -> TaskType.CHAT
        }
        return TaskProfile(type, tokens, tokens > 6000)
    }
}
