package app.xion.ai.orchestrator

import app.xion.ai.provider.ErrorKind
import app.xion.ai.provider.Provider
import app.xion.ai.provider.ProviderError
import app.xion.security.Json

/** What has actually been measured for one provider. Nothing here is estimated from marketing claims. */
data class ProviderSnapshot(
    val provider: Provider,
    val ok: Int,
    val fail: Int,
    val consecutiveFail: Int,
    val avgFirstTokenMs: Double?,
    val avgTotalMs: Double?,
    val lastError: ErrorKind?,
    val cooldownUntil: Long,
    val estTokensIn: Long,
    val estTokensOut: Long,
    val reviews: Int,
    val reviewFixes: Int
) {
    val attempts: Int get() = ok + fail
    val successRate: Double? get() = if (attempts == 0) null else ok.toDouble() / attempts
}

/**
 * Measured health of every provider: success/failure counts, smoothed latency, cool-down after failures and
 * an estimated token count (characters / 4, labelled estimate: only [reportedTokens] come from the provider).
 * Thread-safe. Persisted as JSON so the figures survive restarts.
 */
class ProviderStats(private val clock: () -> Long = { System.currentTimeMillis() }) {

    private class Rec {
        var ok = 0
        var fail = 0
        var consecutive = 0
        var first: Double? = null
        var total: Double? = null
        var lastError: ErrorKind? = null
        var cooldownUntil = 0L
        var tin = 0L
        var tout = 0L
        var reviews = 0
        var fixes = 0
    }

    private val recs = HashMap<Provider, Rec>()

    private fun rec(p: Provider) = recs.getOrPut(p) { Rec() }

    private fun ewma(old: Double?, v: Double): Double = if (old == null) v else old + ALPHA * (v - old)

    @Synchronized
    fun recordSuccess(p: Provider, firstTokenMs: Long, totalMs: Long, charsIn: Int, charsOut: Int) {
        val r = rec(p)
        r.ok++
        r.consecutive = 0
        r.cooldownUntil = 0
        if (firstTokenMs > 0) r.first = ewma(r.first, firstTokenMs.toDouble())
        if (totalMs > 0) r.total = ewma(r.total, totalMs.toDouble())
        r.tin += charsIn / 4
        r.tout += charsOut / 4
    }

    /** Latency measured by a health check counts as a measurement but not as a conversation success. */
    @Synchronized
    fun recordPing(p: Provider, totalMs: Long) {
        val r = rec(p)
        r.consecutive = 0
        r.cooldownUntil = 0
        r.lastError = null
        if (totalMs > 0) r.total = ewma(r.total, totalMs.toDouble())
    }

    @Synchronized
    fun recordFailure(p: Provider, e: ProviderError) {
        val r = rec(p)
        r.fail++
        r.consecutive++
        r.lastError = e.kind
        val sec = when (e.kind) {
            ErrorKind.RATE_LIMIT -> maxOf(e.retryAfterSec ?: 60, 5)
            ErrorKind.AUTH, ErrorKind.QUOTA, ErrorKind.MODEL_NOT_FOUND -> 600
            ErrorKind.BAD_REQUEST -> 0 // the request was at fault, not the provider
            else -> minOf(15 shl minOf(r.consecutive - 1, 5), 300)
        }
        r.cooldownUntil = if (sec == 0) 0 else clock() + sec * 1000L
    }

    @Synchronized
    fun recordReview(p: Provider, changedAnswer: Boolean) {
        val r = rec(p)
        r.reviews++
        if (changedAnswer) r.fixes++
    }

    /** Called when the user changes a key or model: old failures no longer say anything about the new setup. */
    @Synchronized
    fun resetHealth(p: Provider) {
        val r = rec(p)
        r.consecutive = 0
        r.cooldownUntil = 0
        r.lastError = null
    }

    @Synchronized
    fun isCoolingDown(p: Provider): Boolean = (recs[p]?.cooldownUntil ?: 0L) > clock()

    @Synchronized
    fun snapshot(p: Provider): ProviderSnapshot {
        val r = rec(p)
        return ProviderSnapshot(p, r.ok, r.fail, r.consecutive, r.first, r.total, r.lastError, r.cooldownUntil, r.tin, r.tout, r.reviews, r.fixes)
    }

    @Synchronized
    fun clear() = recs.clear()

    @Synchronized
    fun toJson(): String {
        val out = LinkedHashMap<String, Any?>()
        for ((p, r) in recs) {
            out[p.name] = mapOf(
                "ok" to r.ok, "fail" to r.fail, "first" to r.first, "total" to r.total,
                "tin" to r.tin, "tout" to r.tout, "rev" to r.reviews, "fix" to r.fixes
            )
        }
        return Json.stringify(out)
    }

    @Synchronized
    fun loadJson(text: String) {
        val m = Json.parseObject(text, Json.API) ?: return
        for ((k, v) in m) {
            val p = Provider.fromName(k) ?: continue
            val o = v as? Map<*, *> ?: continue
            val r = rec(p)
            r.ok = (o["ok"] as? Long)?.toInt() ?: 0
            r.fail = (o["fail"] as? Long)?.toInt() ?: 0
            r.first = (o["first"] as? Number)?.toDouble()
            r.total = (o["total"] as? Number)?.toDouble()
            r.tin = (o["tin"] as? Long) ?: 0
            r.tout = (o["tout"] as? Long) ?: 0
            r.reviews = (o["rev"] as? Long)?.toInt() ?: 0
            r.fixes = (o["fix"] as? Long)?.toInt() ?: 0
        }
    }

    private companion object {
        const val ALPHA = 0.3
    }
}
