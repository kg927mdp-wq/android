package app.xion.ai.orchestrator

import app.xion.ai.provider.ChatMsg
import app.xion.ai.provider.Completion
import app.xion.ai.provider.ErrorKind
import app.xion.ai.provider.ModelInfo
import app.xion.ai.provider.OpenAiCompatAdapter
import app.xion.ai.provider.Provider
import app.xion.ai.provider.ProviderAdapter
import app.xion.ai.provider.ProviderError
import app.xion.ai.provider.Timeouts
import app.xion.ai.provider.Transport

/** What the orchestrator needs to know about the user's setup. Implemented by Config on Android. */
interface RoutingSettings {
    fun key(p: Provider): String
    fun model(p: Provider): String
    fun enabled(p: Provider): Boolean
    fun declaredFree(p: Provider): Boolean
    var strategy: Strategy
    val primary: Provider?
    fun taskRoute(t: TaskType): Provider?
    /** Cached result of model discovery for the selected model, if the user ever ran it. */
    fun modelInfo(p: Provider, model: String): ModelInfo?
}

/** Receives the answer while it is produced. [onAttempt] fires before each provider is tried, so the caller can reset partial state. */
interface StreamSink {
    fun onAttempt(provider: Provider, model: String)
    fun onDelta(text: String)
}

class StreamResult(
    val provider: Provider,
    val model: String,
    val text: String,
    /** True when the provider failed after part of the answer had already been delivered. */
    val truncated: Boolean
)

class CompleteResult(val provider: Provider, val model: String, val completion: Completion)

/**
 * Chooses providers for each request, runs them with fallback, and records what actually happened.
 *
 * Rules:
 *  - one provider at a time: no parallel requests, so no wasted tokens;
 *  - failure moves to the next ranked provider, never to the same one in a tight loop
 *    (single-provider setups get exactly one retry for transient errors);
 *  - once part of a live answer has been delivered the answer is kept, never restarted elsewhere;
 *  - an authentication/quota/model error puts that provider on cool-down (see [ProviderStats]).
 */
class Orchestrator(
    private val transport: Transport,
    private val settings: RoutingSettings,
    val stats: ProviderStats = ProviderStats(),
    private val timeouts: Timeouts = Timeouts(),
    private val sleep: (Long) -> Unit = { Thread.sleep(it) },
    private val adapterFactory: (Provider) -> ProviderAdapter = { OpenAiCompatAdapter(it, transport) }
) {
    private val adapters = HashMap<Provider, ProviderAdapter>()

    private fun adapter(p: Provider): ProviderAdapter = synchronized(adapters) { adapters.getOrPut(p) { adapterFactory(p) } }

    /** Providers that have a key, a model, and are switched on. */
    fun available(): List<Candidate> = Provider.values().filter {
        settings.enabled(it) && settings.key(it).isNotEmpty() && settings.model(it).isNotEmpty()
    }.map {
        val m = settings.model(it)
        Candidate(it, m, settings.modelInfo(it, m), settings.declaredFree(it))
    }

    /** [prefer] (for example the provider that just asked for a web search) goes first unless it is cooling down. */
    fun rank(profile: TaskProfile, exclude: Set<Provider> = emptySet(), prefer: Provider? = null): List<Candidate> {
        val ranked = Router.rank(
            profile, available().filter { it.provider !in exclude }, settings.strategy,
            settings.primary, settings.taskRoute(profile.type), stats
        )
        val first = ranked.firstOrNull { it.provider == prefer && !stats.isCoolingDown(it.provider) } ?: return ranked
        return listOf(first) + ranked.filter { it !== first }
    }

    /** Why nothing can run, in words for the user; null when at least one provider is usable. */
    fun problem(): String? {
        val keyed = Provider.values().filter { settings.key(it).isNotEmpty() }
        if (keyed.isEmpty()) return "ما في مفتاح محفوظ. افتح الإعدادات وحط مفتاح واحد على الأقل."
        if (available().isEmpty()) {
            return if (keyed.all { settings.model(it).isEmpty() }) "اختر موديل للمزوّد من إعدادات المزودين."
            else "كل المزودين المتاحين مطفأة. فعّل واحداً من الإعدادات."
        }
        return null
    }

    fun stream(
        messages: List<ChatMsg>,
        profile: TaskProfile,
        liveOutput: Boolean,
        cancelled: () -> Boolean,
        sink: StreamSink,
        errors: MutableList<ProviderError>,
        prefer: Provider? = null
    ): StreamResult? {
        val ranked = rank(profile, prefer = prefer)
        for (c in ranked) {
            if (cancelled()) return null
            var attempt = 0
            while (true) {
                attempt++
                var delivered = false
                val text = StringBuilder()
                sink.onAttempt(c.provider, c.model)
                try {
                    val out = adapter(c.provider).stream(settings.key(c.provider), c.model, messages, timeouts, cancelled) {
                        delivered = true
                        text.append(it)
                        sink.onDelta(it)
                    }
                    stats.recordSuccess(c.provider, out.firstTokenMs, out.totalMs, messages.sumOf { m -> m.content.length }, out.text.length)
                    return StreamResult(c.provider, c.model, out.text, false)
                } catch (e: ProviderError) {
                    if (cancelled()) return null
                    stats.recordFailure(c.provider, e)
                    errors.add(e)
                    if (delivered && liveOutput && text.isNotBlank()) {
                        return StreamResult(c.provider, c.model, text.toString(), true)
                    }
                    val onlyOne = ranked.size == 1
                    if (onlyOne && attempt == 1 && !delivered && e.kind in RETRY_ALONE) {
                        sleep(800)
                        continue
                    }
                    break
                }
            }
        }
        return null
    }

    /** One non-streaming call, trying ranked providers (never those in [exclude]) until one answers. */
    fun complete(
        messages: List<ChatMsg>,
        profile: TaskProfile,
        exclude: Set<Provider>,
        errors: MutableList<ProviderError>
    ): CompleteResult? {
        for (c in rank(profile, exclude)) {
            try {
                val r = adapter(c.provider).complete(settings.key(c.provider), c.model, messages, timeouts)
                stats.recordSuccess(c.provider, 0, r.totalMs, messages.sumOf { m -> m.content.length }, r.text.length)
                return CompleteResult(c.provider, c.model, r)
            } catch (e: ProviderError) {
                stats.recordFailure(c.provider, e)
                errors.add(e)
            }
        }
        return null
    }

    /** Health check used by the provider screen: one tiny request, latency recorded as a measurement. */
    fun ping(p: Provider): String {
        val key = settings.key(p)
        val model = settings.model(p)
        if (key.isEmpty()) return "لا يوجد مفتاح"
        if (model.isEmpty()) return "اختر موديل أولاً"
        return try {
            val r = adapter(p).complete(key, model, listOf(ChatMsg("user", "Reply with the single word OK")), timeouts)
            stats.recordPing(p, r.totalMs)
            "يشتغل ✓ (" + r.totalMs + " مللي ثانية)"
        } catch (e: ProviderError) {
            stats.recordFailure(p, e)
            e.describe() + " ✗"
        }
    }

    /** Asks the provider which models this key can use. */
    fun discover(p: Provider): List<ModelInfo> {
        val key = settings.key(p)
        if (key.isEmpty()) throw ProviderError(p, ErrorKind.AUTH, -1, "no key")
        return adapter(p).listModels(key, timeouts)
    }

    private companion object {
        val RETRY_ALONE = setOf(ErrorKind.NETWORK, ErrorKind.TIMEOUT, ErrorKind.SERVER, ErrorKind.EMPTY)
    }
}
