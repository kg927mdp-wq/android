package app.xion.voice

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import app.xion.ui.AssistantActivity

val GOOGLE_RECOGNIZER = ComponentName(
    "com.google.android.googlequicksearchbox",
    "com.google.android.voicesearch.serviceapi.GoogleRecognitionService"
)

/** Makes the app selectable as the phone's default digital assistant. */
class AssistInteractionService : VoiceInteractionService()

class AssistSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = AssistSession(this)
}

class AssistSession(context: Context) : VoiceInteractionSession(context) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        try {
            setUiEnabled(false)
        } catch (e: Exception) {
            // ignore, the session window stays empty anyway
        }
        val intent = Intent(context, AssistantActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try {
            startAssistantActivity(intent)
        } catch (e: Exception) {
            try {
                context.startActivity(intent)
            } catch (e2: Exception) {
                // nothing else to try
            }
        }
    }
}

/**
 * When the app becomes the default assistant, Android may also pick this service as the
 * system speech recogniser. To avoid breaking voice input in other apps, it simply
 * forwards every request to Google's own recogniser.
 */
class ProxyRecognitionService : RecognitionService() {

    private var delegate: SpeechRecognizer? = null

    override fun onStartListening(recognizerIntent: Intent?, listener: RecognitionService.Callback?) {
        val cb = listener ?: return
        val r: SpeechRecognizer? = try {
            SpeechRecognizer.createSpeechRecognizer(this, GOOGLE_RECOGNIZER)
        } catch (e: Exception) {
            null
        }
        if (r == null) {
            cb.error(SpeechRecognizer.ERROR_CLIENT)
            return
        }
        delegate?.destroy()
        delegate = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                cb.readyForSpeech(params ?: Bundle())
            }

            override fun onBeginningOfSpeech() {
                cb.beginningOfSpeech()
            }

            override fun onRmsChanged(rmsdB: Float) {
                cb.rmsChanged(rmsdB)
            }

            override fun onBufferReceived(buffer: ByteArray?) {
                if (buffer != null) cb.bufferReceived(buffer)
            }

            override fun onEndOfSpeech() {
                cb.endOfSpeech()
            }

            override fun onError(error: Int) {
                cb.error(error)
            }

            override fun onResults(results: Bundle?) {
                cb.results(results ?: Bundle())
            }

            override fun onPartialResults(partialResults: Bundle?) {
                cb.partialResults(partialResults ?: Bundle())
            }

            override fun onEvent(eventType: Int, params: Bundle?) {
                // not forwarded
            }
        })
        r.startListening(recognizerIntent ?: Intent())
    }

    override fun onStopListening(listener: RecognitionService.Callback?) {
        delegate?.stopListening()
    }

    override fun onCancel(listener: RecognitionService.Callback?) {
        delegate?.cancel()
    }

    override fun onDestroy() {
        delegate?.destroy()
        delegate = null
        super.onDestroy()
    }
}
