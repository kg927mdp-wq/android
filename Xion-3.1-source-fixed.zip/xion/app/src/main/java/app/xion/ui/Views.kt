package app.xion.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Coloured light that rises from the bottom edge of the screen, like a glowing horizon. */
class GlowBarView(context: Context) : View(context) {

    var state: OrbState = OrbState.IDLE
    private var target = 0f
    private var intensity = 0f
    private var phase = 0f
    private var lastNs = 0L

    private val colors = intArrayOf(PALETTE[0], PALETTE[1], PALETTE[2], PALETTE[3], PALETTE[0])
    private var shader: LinearGradient? = null
    private val matrix = Matrix()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density

    fun setLevel(v: Float) {
        target = v.coerceIn(0f, 1f)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        shader = if (w > 0) LinearGradient(0f, 0f, w.toFloat(), 0f, colors, null, Shader.TileMode.REPEAT) else null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastNs = System.nanoTime()
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - lastNs) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastNs = now
        phase += dt

        val goal = when (state) {
            OrbState.IDLE -> 0.28f
            OrbState.LISTENING -> 0.45f + 0.5f * target
            OrbState.THINKING -> 0.65f + 0.25f * sin(phase * 4f)
            OrbState.SPEAKING -> 0.6f + 0.25f * sin(phase * 6f)
        }
        intensity += (goal - intensity) * min(1f, dt * 6f)

        val sh = shader
        if (sh != null) {
            val w = width.toFloat()
            val h = height.toFloat()
            val speed = if (state == OrbState.THINKING) 0.55f else 0.18f
            matrix.setTranslate((phase * speed * w) % w, 0f)
            sh.setLocalMatrix(matrix)
            paint.shader = sh

            val strips = 28
            val stripH = h / strips
            for (i in 0 until strips) {
                val t = i / strips.toFloat()
                val a = (intensity * 255f * (1f - t).pow(2.2f)).toInt().coerceIn(0, 255)
                if (a <= 2) continue
                paint.alpha = a
                canvas.drawRect(0f, h - (i + 1) * stripH, w, h - i * stripH, paint)
            }
            paint.alpha = (intensity * 330f).toInt().coerceIn(0, 255)
            canvas.drawRect(0f, h - 3f * d, w, h, paint)
        }
        postInvalidateOnAnimation()
    }
}

/** Round microphone button with a soft pulse while listening. */
class MicButton(context: Context) : View(context) {

    var state: OrbState = OrbState.IDLE
        set(value) {
            field = value
            invalidate()
        }

    private var phase = 0f
    private var lastNs = 0L
    private var fillShader: LinearGradient? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pulse = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val iconFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val capsule = RectF()
    private val arc = RectF()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fillShader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            PALETTE[0], PALETTE[1], Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - lastNs) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastNs = now
        phase += dt

        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val r = s * 0.40f

        if (state == OrbState.LISTENING) {
            val t = (phase * 0.9f) % 1f
            pulse.strokeWidth = s * 0.03f
            pulse.color = withAlpha(PALETTE[3], ((1f - t) * 150f).toInt())
            canvas.drawCircle(cx, cy, r * (1f + 0.38f * t), pulse)
        }

        fill.shader = fillShader
        canvas.drawCircle(cx, cy, r, fill)

        icon.strokeWidth = s * 0.045f
        capsule.set(cx - s * 0.09f, cy - s * 0.24f * 0.9f - s * 0.02f, cx + s * 0.09f, cy + s * 0.05f)
        canvas.drawRoundRect(capsule, s * 0.09f, s * 0.09f, iconFill)
        arc.set(cx - s * 0.16f, cy - s * 0.12f, cx + s * 0.16f, cy + s * 0.17f)
        canvas.drawArc(arc, 0f, 180f, false, icon)
        canvas.drawLine(cx, cy + s * 0.17f, cx, cy + s * 0.25f, icon)
        canvas.drawLine(cx - s * 0.07f, cy + s * 0.25f, cx + s * 0.07f, cy + s * 0.25f, icon)

        if (state == OrbState.LISTENING) postInvalidateOnAnimation()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastNs = System.nanoTime()
    }
}
