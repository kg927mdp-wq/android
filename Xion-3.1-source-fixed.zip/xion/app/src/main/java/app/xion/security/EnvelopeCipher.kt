package app.xion.security

import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * AES-256-GCM for small secrets such as API keys. The key itself comes from [key]: on Android it is a
 * non-exportable Android Keystore key, in unit tests a plain software key.
 *
 * Each value is bound to its [slot] name (as authenticated data), so an encrypted value copied from one
 * setting into another is rejected instead of being accepted.
 */
class EnvelopeCipher(private val key: () -> SecretKey) {

    fun encrypt(plain: String, slot: String): String {
        val c = Cipher.getInstance(TRANSFORM)
        // No IV is supplied: the provider generates a fresh random one (Android Keystore requires this).
        c.init(Cipher.ENCRYPT_MODE, key())
        c.updateAAD(slot.toByteArray(Charsets.UTF_8))
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        val enc = Base64.getUrlEncoder().withoutPadding()
        return "v1." + enc.encodeToString(c.iv) + "." + enc.encodeToString(ct)
    }

    /** Returns null when the value is missing, damaged, from another slot or from another key. Never throws. */
    fun decrypt(token: String, slot: String): String? {
        return try {
            val parts = token.split('.')
            if (parts.size != 3 || parts[0] != "v1") return null
            val dec = Base64.getUrlDecoder()
            val iv = dec.decode(parts[1])
            val ct = dec.decode(parts[2])
            if (iv.size != IV_BYTES) return null
            val c = Cipher.getInstance(TRANSFORM)
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(TAG_BITS, iv))
            c.updateAAD(slot.toByteArray(Charsets.UTF_8))
            String(c.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }

    private companion object {
        const val TRANSFORM = "AES/GCM/NoPadding"
        const val IV_BYTES = 12
        const val TAG_BITS = 128
    }
}
