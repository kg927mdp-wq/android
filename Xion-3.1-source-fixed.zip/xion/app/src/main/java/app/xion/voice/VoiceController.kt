package app.xion.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import app.xion.data.Config
import java.util.Locale

/**
 * Speech recognition and speech output for the chat screen. It only turns sound into text and text into sound:
 * what the text means is decided elsewhere (engine, policy). Use it from the main thread.
 * Microphone permission is checked by the caller; without it the chat keeps working as plain text.
 */
class VoiceController(context: Context, private val cb: Callback) : TextToSpeech.OnInitListener {

    interface Callback {
        fun onListeningChanged(listening: Boolean)
        fun onLevel(level: Float)
        fun onPartial(text: String)
        fun onResult(alternatives: List<String>, confidences: FloatArray?)
        fun onRecognitionError(code: Int)
        fun onSpeakingChanged(speaking: Boolean)
    }

    private val app = context.applicationContext
    private val cfg = Config(app)
    private val ui = Handler(Looper.getMainLooper())

    private var recognizer: SpeechRecognizer? = null
    private var usingGoogle = true
    private var listening = false

    private var tts: TextToSpeech? = TextToSpeech(app, this)
    private var ttsReady = false
    private var ttsFailed = false
    private val queued = ArrayList<String>()
    private var pending = 0
    private var seq = 0
    private var generation = 0

    fun hasMic(): Boolean = app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    val isListening: Boolean get() = listening
    val isSpeaking: Boolean get() = pending > 0

    // ------------------------------------------------------------------ listening

    private fun makeRecognizer(): SpeechRecognizer {
        if (usingGoogle) {
            try {
                app.packageManager.getServiceInfo(GOOGLE_RECOGNIZER, 0)
                return SpeechRecognizer.createSpeechRecognizer(app, GOOGLE_RECOGNIZER)
            } catch (e: Exception) {
                usingGoogle = false
            }
        }
        return SpeechRecognizer.createSpeechRecognizer(app)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) = cb.onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            cb.onLevel(0f)
        }

        override fun onError(error: Int) {
            setListening(false)
            if (error == SpeechRecognizer.ERROR_CLIENT && usingGoogle) {
                // Google's recogniser cannot be used on this phone: fall back to the default one once
                usingGoogle = false
                startListening()
                return
            }
            cb.onRecognitionError(error)
        }

        override fun onResults(results: Bundle?) {
            setListening(false)
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (list.isNullOrEmpty()) {
                cb.onRecognitionError(SpeechRecognizer.ERROR_NO_MATCH)
            } else {
                cb.onResult(list, results.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES))
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrEmpty()) cb.onPartial(t)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun setListening(v: Boolean) {
        if (listening == v) return
        listening = v
        cb.onListeningChanged(v)
    }

    /** Starts listening. Returns false when the microphone permission is missing (nothing else happens). */
    fun startListening(maxResults: Int = 1): Boolean {
        if (!hasMic()) return false
        stopSpeaking()
        destroyRecognizer()
        val r = makeRecognizer()
        recognizer = r
        r.setRecognitionListener(listener)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
        if (maxResults > 1) i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, maxResults)
        val lang = cfg.lang
        if (lang.isNotEmpty()) {
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
        }
        return try {
            r.startListening(i)
            setListening(true)
            true
        } catch (e: Exception) {
            setListening(false)
            cb.onRecognitionError(SpeechRecognizer.ERROR_CLIENT)
            false
        }
    }

    fun stopListening() {
        destroyRecognizer()
        setListening(false)
        cb.onLevel(0f)
    }

    private fun destroyRecognizer() {
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
            // ignore
        }
        recognizer = null
    }

    // ------------------------------------------------------------------ speaking

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            ttsFailed = true
            queued.clear()
            pending = 0
            cb.onSpeakingChanged(false)
            return
        }
        val lang = cfg.lang
        val loc = if (lang.isEmpty()) Locale.getDefault() else Locale.forLanguageTag(lang)
        val res = t.setLanguage(loc)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale("ar"))
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = finished(utteranceId)

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = finished(utteranceId)
        })
        ttsReady = true
        val list = ArrayList(queued)
        queued.clear()
        for (s in list) speakNow(s)
    }

    private fun finished(utteranceId: String?) {
        val owner = utteranceId?.substringBefore(':')?.toIntOrNull() ?: return
        ui.post {
            if (owner == generation && pending > 0) {
                pending--
                if (pending == 0) cb.onSpeakingChanged(false)
            }
        }
    }

    fun speak(text: String) {
        if (ttsFailed || text.isBlank()) return
        pending++
        if (pending == 1) cb.onSpeakingChanged(true)
        if (ttsReady) speakNow(text) else queued.add(text)
    }

    private fun speakNow(text: String) {
        tts?.speak(text.take(3500), TextToSpeech.QUEUE_ADD, Bundle(), generation.toString() + ":" + (seq++))
    }

    /** Stops talking at once (the user interrupted, or started to speak). */
    fun stopSpeaking() {
        generation++
        tts?.stop()
        queued.clear()
        if (pending != 0) {
            pending = 0
            cb.onSpeakingChanged(false)
        }
    }

    fun shutdown() {
        destroyRecognizer()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
