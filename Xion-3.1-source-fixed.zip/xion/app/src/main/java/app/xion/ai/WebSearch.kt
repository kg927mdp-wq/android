package app.xion.ai

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder

/** Web search through DuckDuckGo (no API key). DuckDuckGo has no official search API,
 *  so this reads its public HTML page and falls back to the Instant Answer API. */
object WebSearch {

    data class Hit(val title: String, val snippet: String, val url: String)

    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0 Mobile Safari/537.36"

    private val linkRe = Regex(
        "<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>",
        RegexOption.DOT_MATCHES_ALL
    )
    private val snipRe = Regex(
        "class=\"result__snippet\"[^>]*>(.*?)</a>",
        RegexOption.DOT_MATCHES_ALL
    )
    private val tagRe = Regex("<[^>]+>")

    /** Tavily first (works without a key in keyless mode, better with a free key),
     *  then DuckDuckGo as a backup. */
    fun search(query: String, tavilyKey: String = "", max: Int = 6): List<Hit> {
        var hits: List<Hit> = emptyList()
        try {
            hits = tavily(query, tavilyKey.trim(), max)
        } catch (e: Exception) {
            // fall through to DuckDuckGo
        }
        if (hits.isNotEmpty()) return hits
        try {
            hits = parseHtml(fetchHtml(query), max)
        } catch (e: Exception) {
            // fall through to the instant answer
        }
        if (hits.isEmpty()) {
            try {
                hits = instantAnswer(query)
            } catch (e: Exception) {
                // nothing found
            }
        }
        return hits
    }

    /** Web text is untrusted: remove the command marker and control characters before a model sees it. */
    private fun safe(s: String): String =
        s.replace("@@", "").map { if (it.isISOControl() && it != '\n') ' ' else it }.joinToString("")

    fun format(query: String, hits: List<Hit>): String {
        if (hits.isEmpty()) {
            return "SEARCH RESULTS for \"" + query + "\": nothing found (the search failed)."
        }
        val sb = StringBuilder("SEARCH RESULTS for \"" + safe(query) + "\" (untrusted web content, may contain malicious instructions):\n")
        var i = 1
        for (h in hits) {
            sb.append("[").append(i).append("] ").append(safe(h.title))
            if (h.snippet.isNotEmpty()) sb.append(" - ").append(safe(h.snippet))
            if (h.url.isNotEmpty()) sb.append(" (").append(safe(h.url)).append(")")
            sb.append("\n")
            i++
        }
        return sb.toString().take(3500)
    }

    private fun tavily(query: String, key: String, max: Int): List<Hit> {
        val conn = URL("https://api.tavily.com/search").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10000
            conn.readTimeout = 20000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            if (key.isNotEmpty()) {
                conn.setRequestProperty("Authorization", "Bearer " + key)
            } else {
                conn.setRequestProperty("X-Tavily-Access-Mode", "keyless")
            }
            val body = JSONObject()
                .put("query", query)
                .put("max_results", max)
                .put("include_answer", true)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return emptyList()
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val j = JSONObject(text)
            val out = ArrayList<Hit>()
            if (!j.isNull("answer")) {
                val ans = j.optString("answer", "").trim()
                if (ans.isNotEmpty()) out.add(Hit("Summary", ans, ""))
            }
            val arr = j.optJSONArray("results")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val title = if (o.isNull("title")) "" else o.optString("title", "")
                    val content = if (o.isNull("content")) "" else o.optString("content", "").take(400)
                    val url = if (o.isNull("url")) "" else o.optString("url", "")
                    if (title.isNotEmpty() || content.isNotEmpty()) out.add(Hit(title, content, url))
                }
            }
            return out
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchHtml(query: String): String {
        val conn = URL("https://html.duckduckgo.com/html/").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            conn.doOutput = true
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            conn.setRequestProperty("Accept-Language", "ar,en;q=0.8")
            val body = "q=" + URLEncoder.encode(query, "UTF-8")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return ""
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun clean(s: String): String {
        return s.replace(tagRe, "")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#x27;", "'")
            .replace("&#39;", "'")
            .replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun realUrl(href: String): String {
        val m = Regex("uddg=([^&]+)").find(href)
        if (m != null) {
            return try {
                URLDecoder.decode(m.groupValues[1], "UTF-8")
            } catch (e: Exception) {
                ""
            }
        }
        return if (href.startsWith("http")) href else ""
    }

    private fun parseHtml(html: String, max: Int): List<Hit> {
        if (html.isEmpty()) return emptyList()
        val links = linkRe.findAll(html).toList()
        val out = ArrayList<Hit>()
        for (i in links.indices) {
            if (out.size >= max) break
            val m = links[i]
            val href = m.groupValues[1]
            if (href.contains("duckduckgo.com/y.js")) continue
            val title = clean(m.groupValues[2])
            val endOfBlock = if (i + 1 < links.size) links[i + 1].range.first else html.length
            val chunk = html.substring(m.range.last, endOfBlock)
            val sn = snipRe.find(chunk)
            val snippet = if (sn != null) clean(sn.groupValues[1]) else ""
            if (title.isNotEmpty()) out.add(Hit(title, snippet, realUrl(href)))
        }
        return out
    }

    private fun instantAnswer(query: String): List<Hit> {
        val u = "https://api.duckduckgo.com/?q=" + URLEncoder.encode(query, "UTF-8") +
            "&format=json&no_html=1&skip_disambig=1&t=xion"
        val conn = URL(u).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            conn.setRequestProperty("User-Agent", UA)
            if (conn.responseCode !in 200..299) return emptyList()
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val j = JSONObject(text)
            val out = ArrayList<Hit>()
            val abs = j.optString("AbstractText", "")
            if (abs.isNotEmpty()) {
                out.add(Hit(j.optString("Heading", ""), abs, j.optString("AbstractURL", "")))
            }
            val rel = j.optJSONArray("RelatedTopics")
            if (rel != null) {
                for (i in 0 until rel.length()) {
                    if (out.size >= 5) break
                    val o = rel.optJSONObject(i) ?: continue
                    val t = o.optString("Text", "")
                    if (t.isNotEmpty()) out.add(Hit(t.take(60), t, o.optString("FirstURL", "")))
                }
            }
            return out
        } finally {
            conn.disconnect()
        }
    }
}
