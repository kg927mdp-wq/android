package app.xion.ai.orchestrator

import app.xion.ai.provider.ModelInfo
import app.xion.ai.provider.Provider

/** How the router orders providers. Every rule uses user choices or measured data, never invented rankings. */
enum class Strategy(val label: String, val help: String) {
    MANUAL("يدوي", "يبدأ بالمزوّد الذي اخترته ثم يجرّب الباقي بالترتيب فقط عند الفشل"),
    AUTO("تلقائي", "للأوامر والمحادثة: الأسرع حسب القياس الفعلي. للتحليل والبرمجة: المزوّد الذي اخترته أولاً"),
    SPEED("أسرع استجابة", "الأقل زمناً حسب القياسات الفعلية"),
    COST("أرخص", "الأقل سعراً حسب أسعار المزوّد نفسه، والمعروف سعره قبل المجهول"),
    FREE_ONLY("مجاني فقط", "فقط النماذج التي يقول المزوّد إنها بلا تكلفة، أو مزوّد صنّفته أنت مجانياً"),
    QUALITY("أعلى جودة", "المزوّد الذي اخترته أولاً مع مراجعة الجواب بنموذج آخر")
}

/** A provider with a model, ready to be tried. */
data class Candidate(
    val provider: Provider,
    val model: String,
    val info: ModelInfo?,
    val declaredFree: Boolean
)

object Router {

    /**
     * Orders [candidates] for one request. Providers that are cooling down after failures go last (not removed),
     * so a stale cool-down can never leave Xion without any answer.
     */
    fun rank(
        profile: TaskProfile,
        candidates: List<Candidate>,
        strategy: Strategy,
        primary: Provider?,
        taskRoute: Provider?,
        stats: ProviderStats
    ): List<Candidate> {
        var pool = candidates
        if (strategy == Strategy.FREE_ONLY) pool = pool.filter { it.declaredFree || it.info?.isFree == true }

        // a model whose known context window cannot hold the request is the last resort
        fun fits(c: Candidate): Boolean {
            val ctx = c.info?.contextLength ?: return true
            return profile.approxTokens < ctx * 0.8
        }

        val byPrimary = compareBy<Candidate>({ if (it.provider == taskRoute) 0 else 1 }, { if (it.provider == primary) 0 else 1 }, { it.provider.ordinal })
        val latency = compareBy<Candidate> {
            stats.snapshot(it.provider).let { s -> s.avgFirstTokenMs ?: s.avgTotalMs ?: Double.MAX_VALUE }
        }
        val failureRate = compareBy<Candidate> { 1.0 - (stats.snapshot(it.provider).successRate ?: 0.5) }

        val order: Comparator<Candidate> = when (strategy) {
            Strategy.MANUAL, Strategy.QUALITY, Strategy.FREE_ONLY ->
                if (strategy == Strategy.FREE_ONLY) byPrimary.thenComparing(latency) else byPrimary
            Strategy.SPEED -> compareBy<Candidate> { if (it.provider == taskRoute) 0 else 1 }.then(latency).then(byPrimary)
            Strategy.COST -> compareBy<Candidate> { if (it.provider == taskRoute) 0 else 1 }
                .thenBy { c -> if (c.declaredFree || c.info?.isFree == true) 0 else 1 }
                .thenBy { c -> c.info?.pricePerMillion ?: Double.MAX_VALUE }
                .then(byPrimary)
            Strategy.AUTO -> when (profile.type) {
                TaskType.COMMAND, TaskType.CHAT -> compareBy<Candidate> { if (it.provider == taskRoute) 0 else 1 }.then(latency).then(byPrimary)
                else -> byPrimary.then(failureRate).then(latency)
            }
        }

        val healthy = pool.filter { !stats.isCoolingDown(it.provider) }.sortedWith(order)
        val cooling = pool.filter { stats.isCoolingDown(it.provider) }
            .sortedBy { stats.snapshot(it.provider).cooldownUntil }
        val all = healthy + cooling
        return all.filter { fits(it) } + all.filter { !fits(it) }
    }
}
