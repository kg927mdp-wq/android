package app.xion.security

/** Removes secrets and personal numbers from anything that could reach a screen, a log or the audit file. */
object Redactor {

    private val patterns = listOf(
        Regex("(?i)bearer\\s+[A-Za-z0-9._~+/=-]{8,}"),
        Regex("\\bsk-[A-Za-z0-9_-]{10,}"),
        Regex("\\bAIza[0-9A-Za-z_-]{20,}"),
        Regex("\\bxai-[A-Za-z0-9]{10,}"),
        Regex("\\btvly-[A-Za-z0-9_-]{8,}"),
        Regex("\\b[A-Za-z0-9_-]{32,}\\b")
    )

    /** Replaces anything that looks like an API key or token. */
    fun scrub(s: String): String {
        var out = s
        for (p in patterns) out = p.replace(out, "[redacted]")
        return out
    }

    /** Phone numbers keep only their last two digits. Names are returned unchanged. */
    fun maskTarget(s: String): String {
        val digits = s.count { it.isDigit() }
        val hasLetters = s.any { it.isLetter() }
        if (hasLetters || digits < 6) return s
        val d = s.filter { it.isDigit() }
        return "•".repeat(d.length - 2) + d.takeLast(2)
    }
}
