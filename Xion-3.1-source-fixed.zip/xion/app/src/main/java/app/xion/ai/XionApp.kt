package app.xion.ai

import android.content.Context
import app.xion.ai.orchestrator.Orchestrator
import app.xion.ai.orchestrator.ProviderStats
import app.xion.ai.provider.UrlTransport
import app.xion.data.Config
import app.xion.data.ConfigRouting

/** Builds the one engine and orchestrator the whole app shares: the chat screen, the voice overlay and the settings screens all use these. */
object XionApp {
    private var engineRef: ConversationEngine? = null
    private var orchRef: Orchestrator? = null
    private var routingRef: ConfigRouting? = null

    @Synchronized
    private fun init(ctx: Context) {
        if (engineRef != null) return
        val app = ctx.applicationContext
        val cfg = Config(app)
        val routing = ConfigRouting(cfg)
        val stats = ProviderStats()
        try {
            stats.loadJson(cfg.statsJson)
        } catch (e: Exception) {
            // unreadable statistics are simply measured again
        }
        val orch = Orchestrator(UrlTransport(), routing, stats)
        val settings = object : EngineSettings {
            override val mode: String get() = cfg.mode
            override val searchEnabled: Boolean get() = cfg.searchEnabled
        }
        val search = SearchPort { q ->
            val hits = try {
                WebSearch.search(q, cfg.tavilyKey)
            } catch (e: Exception) {
                emptyList()
            }
            WebSearch.format(q, hits)
        }
        routingRef = routing
        orchRef = orch
        engineRef = ConversationEngine(orch, settings, search, onTurnFinished = { cfg.statsJson = stats.toJson() })
    }

    fun engine(ctx: Context): ConversationEngine {
        init(ctx)
        return engineRef!!
    }

    fun orchestrator(ctx: Context): Orchestrator {
        init(ctx)
        return orchRef!!
    }

    fun routing(ctx: Context): ConfigRouting {
        init(ctx)
        return routingRef!!
    }
}
