package app.xion.security

class JsonException(message: String) : Exception(message)

/**
 * Small strict JSON reader/writer with no Android dependency, so it can be unit tested on a plain JVM.
 * It is used for everything that comes from an AI model: bounded size, bounded depth, bounded key count.
 */
/** Bounds for a parse. Model-produced actions get tight limits; provider API responses get larger ones. */
class JsonLimits(val maxLength: Int, val maxDepth: Int, val maxKeys: Int, val maxItems: Int)

object Json {
    const val MAX_LENGTH = 8000
    val ACTION = JsonLimits(MAX_LENGTH, 6, 32, 64)
    /** Provider responses and model lists (a full model catalogue can be several MB). */
    val API = JsonLimits(8_000_000, 24, 5_000, 20_000)

    @Suppress("UNCHECKED_CAST")
    fun parseObject(s: String, limits: JsonLimits = ACTION): Map<String, Any?>? = try {
        parse(s, limits) as? Map<String, Any?>
    } catch (e: JsonException) {
        null
    }

    fun parse(s: String, limits: JsonLimits = ACTION): Any? {
        if (s.length > limits.maxLength) throw JsonException("too long")
        val p = Reader(s, limits)
        val v = p.value(0)
        p.ws()
        if (p.i != s.length) throw JsonException("trailing data")
        return v
    }

    private class Reader(val s: String, val lim: JsonLimits) {
        var i = 0

        fun ws() {
            while (i < s.length && s[i].isWhitespace()) i++
        }

        fun value(depth: Int): Any? {
            if (depth > lim.maxDepth) throw JsonException("too deep")
            ws()
            if (i >= s.length) throw JsonException("unexpected end")
            return when (s[i]) {
                '{' -> obj(depth)
                '[' -> arr(depth)
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> num()
            }
        }

        private fun lit(word: String, v: Any?): Any? {
            if (!s.startsWith(word, i)) throw JsonException("bad literal")
            i += word.length
            return v
        }

        private fun num(): Any {
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] in "+-.eE")) i++
            val t = s.substring(start, i)
            if (t.isEmpty()) throw JsonException("bad value")
            if (t.any { it == '.' || it == 'e' || it == 'E' }) {
                val d = t.toDoubleOrNull() ?: throw JsonException("bad number")
                if (d.isNaN() || d.isInfinite()) throw JsonException("bad number")
                return d
            }
            return t.toLongOrNull() ?: throw JsonException("bad number")
        }

        private fun str(): String {
            i++ // opening quote
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) throw JsonException("unterminated string")
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (i >= s.length) throw JsonException("bad escape")
                        when (val e = s[i++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (i + 4 > s.length) throw JsonException("bad unicode escape")
                                val code = s.substring(i, i + 4).toIntOrNull(16)
                                    ?: throw JsonException("bad unicode escape")
                                sb.append(code.toChar())
                                i += 4
                            }
                            else -> throw JsonException("bad escape $e")
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        private fun arr(depth: Int): List<Any?> {
            i++
            val out = ArrayList<Any?>()
            ws()
            if (i < s.length && s[i] == ']') {
                i++
                return out
            }
            while (true) {
                if (out.size >= lim.maxItems) throw JsonException("too many items")
                out.add(value(depth + 1))
                ws()
                if (i >= s.length) throw JsonException("unterminated array")
                val c = s[i++]
                if (c == ']') return out
                if (c != ',') throw JsonException("bad array")
            }
        }

        private fun obj(depth: Int): Map<String, Any?> {
            i++
            val out = LinkedHashMap<String, Any?>()
            ws()
            if (i < s.length && s[i] == '}') {
                i++
                return out
            }
            while (true) {
                if (out.size >= lim.maxKeys) throw JsonException("too many keys")
                ws()
                if (i >= s.length || s[i] != '"') throw JsonException("bad key")
                val k = str()
                ws()
                if (i >= s.length || s[i] != ':') throw JsonException("missing colon")
                i++
                out[k] = value(depth + 1)
                ws()
                if (i >= s.length) throw JsonException("unterminated object")
                val c = s[i++]
                if (c == '}') return out
                if (c != ',') throw JsonException("bad object")
            }
        }
    }

    fun stringify(v: Any?): String {
        val sb = StringBuilder()
        write(sb, v)
        return sb.toString()
    }

    private fun write(sb: StringBuilder, v: Any?) {
        when (v) {
            null -> sb.append("null")
            is String -> quote(sb, v)
            is Boolean -> sb.append(v.toString())
            is Int, is Long -> sb.append(v.toString())
            is Number -> sb.append(v.toDouble().toString())
            is Map<*, *> -> {
                sb.append('{')
                var first = true
                for ((k, x) in v) {
                    if (!first) sb.append(',')
                    first = false
                    quote(sb, k.toString())
                    sb.append(':')
                    write(sb, x)
                }
                sb.append('}')
            }
            is List<*> -> {
                sb.append('[')
                for ((n, x) in v.withIndex()) {
                    if (n > 0) sb.append(',')
                    write(sb, x)
                }
                sb.append(']')
            }
            else -> quote(sb, v.toString())
        }
    }

    private fun quote(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c < ' ' -> sb.append(String.format("\\u%04x", c.code))
                else -> sb.append(c)
            }
        }
        sb.append('"')
    }
}
