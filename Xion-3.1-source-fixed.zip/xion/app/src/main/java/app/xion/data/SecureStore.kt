package app.xion.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import app.xion.security.EnvelopeCipher
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/** The non-exportable AES key that protects every stored secret. It never leaves the Android Keystore. */
internal object KeystoreKey {
    private const val ALIAS = "xion_master_v1"
    private const val PROVIDER = "AndroidKeyStore"

    @Synchronized
    fun get(): SecretKey {
        val ks = KeyStore.getInstance(PROVIDER)
        ks.load(null)
        val existing = ks.getKey(ALIAS, null)
        if (existing is SecretKey) return existing
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        gen.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }
}

/**
 * Encrypted key/value storage for secrets (API keys). Values are AES-GCM encrypted with the Keystore key.
 * There is deliberately no plain-text fallback: if the Keystore fails, [put] returns false and nothing is saved.
 */
class SecureStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("xion_secure", Context.MODE_PRIVATE)
    private val cipher = EnvelopeCipher { KeystoreKey.get() }

    /** Empty string when the value is missing or cannot be decrypted. */
    fun get(name: String): String {
        val token = sp.getString(name, null) ?: return ""
        return cipher.decrypt(token, name) ?: ""
    }

    fun put(name: String, value: String): Boolean {
        return try {
            if (value.isEmpty()) {
                sp.edit().remove(name).apply()
            } else {
                sp.edit().putString(name, cipher.encrypt(value, name)).apply()
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
