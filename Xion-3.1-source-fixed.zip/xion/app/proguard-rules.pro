# Components are kept automatically through the manifest. Xion uses no reflection and no serialization library.
# Keep line numbers for readable crash reports without exposing source names.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
