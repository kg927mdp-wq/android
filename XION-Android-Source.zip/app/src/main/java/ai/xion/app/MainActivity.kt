package ai.xion.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF08090D)
private val Panel = Color(0xFF11131A)
private val Line = Color(0x26FFFFFF)
private val Silver = Color(0xFFE8EAF2)
private val Muted = Color(0xFF8E93A3)
private val Violet = Color(0xFF9B83FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("xion", MODE_PRIVATE)
        setContent {
            XionApp(
                initialBase = prefs.getString("base", "https://openrouter.ai/api/v1") ?: "",
                initialModel = prefs.getString("model", "") ?: "",
                initialKey = prefs.getString("key", "") ?: "",
                save = { base, model, key ->
                    prefs.edit().putString("base", base).putString("model", model).putString("key", key).apply()
                }
            )
        }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
fun XionApp(initialBase: String, initialModel: String, initialKey: String,
            save: (String, String, String) -> Unit) {
    var base by remember { mutableStateOf(initialBase) }
    var model by remember { mutableStateOf(initialModel) }
    var key by remember { mutableStateOf(initialKey) }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Violet, onBackground = Silver,
        onSurface = Silver, secondary = Muted
    )) {
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF151321), Ink, Color(0xFF08090D)))
        )) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Header(onSettings = { showSettings = true })
                if (messages.isEmpty()) {
                    Welcome()
                    Spacer(Modifier.weight(1f))
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(messages) { MessageBubble(it) }
                        if (busy) item { TypingIndicator() }
                    }
                }
                Composer(
                    value = input, onValue = { input = it }, enabled = !busy,
                    onSend = {
                        val prompt = input.trim()
                        if (prompt.isNotEmpty() && !busy) {
                            input = ""
                            messages.add(ChatMessage(prompt, true))
                            busy = true
                            scope.launch {
                                val answer = withContext(Dispatchers.IO) {
                                    askXion(base, model, key, messages.filter { !it.fromUser || it.text == prompt })
                                }
                                messages.add(ChatMessage(answer, false))
                                busy = false
                            }
                        }
                    }
                )
            }
            if (showSettings) {
                SettingsDialog(base, model, key,
                    onDismiss = { showSettings = false },
                    onSave = { b, m, k -> base=b; model=m; key=k; save(b,m,k); showSettings=false }
                )
            }
        }
    }
}

@Composable
private fun Header(onSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(13.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFB9ACFF), Color(0xFF5D4AAE)))),
            contentAlignment = Alignment.Center
        ) {
            Text("X", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("X I O N", color = Silver, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("INTELLIGENCE, REIMAGINED", color = Muted, fontSize = 8.sp, letterSpacing = 1.5.sp)
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Outlined.Tune, contentDescription = "الإعدادات", tint = Silver)
        }
    }
    HorizontalDivider(color = Line)
}

@Composable
private fun Welcome() {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 26.dp).padding(top = 54.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnimatedCore()
        Spacer(Modifier.height(34.dp))
        Text("فكّر أبعد.", color = Silver, fontSize = 31.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(9.dp))
        Text(
            "مساحة ذكية لأفكارك وأسئلتك وإبداعك.",
            color = Muted, fontSize = 14.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(30.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Suggestion("اكتب لي فكرة") 
            Suggestion("اشرح موضوعاً")
        }
    }
}

@Composable
private fun AnimatedCore() {
    val infinite = rememberInfiniteTransition(label = "core")
    val pulse by infinite.animateFloat(
        initialValue = 0.92f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    Box(Modifier.size(174.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(166.dp).scale(pulse).clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color(0x559B83FF), Color(0x169B83FF), Color.Transparent))))
        Box(Modifier.size(104.dp).clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color(0xFFB7A8FF), Color(0xFF6553B5), Color(0xFF171522))))
            .border(1.dp, Color(0x88D8D0FF), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(48.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color.White, Color(0xFFB8A8FF), Color(0xFF7663C9)))))
        }
    }
}

@Composable
private fun Suggestion(label: String) {
    Surface(
        color = Color(0x331D1B2A), shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, Line)
    ) {
        Text(label, Modifier.padding(horizontal = 14.dp, vertical = 9.dp), color = Silver, fontSize = 11.sp)
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement =
        if (message.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (message.fromUser) Color(0xFF28233D) else Color(0x9913161F),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, if (message.fromUser) Color(0x557F6DCC) else Line),
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            Text(message.text, Modifier.padding(horizontal = 15.dp, vertical = 12.dp),
                color = Silver, fontSize = 14.sp, lineHeight = 22.sp)
        }
    }
}

@Composable
private fun TypingIndicator() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(Modifier.size(15.dp), color = Violet, strokeWidth = 2.dp)
        Spacer(Modifier.width(10.dp))
        Text("XION يفكّر...", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun Composer(value: String, onValue: (String) -> Unit, enabled: Boolean, onSend: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
        Surface(
            color = Color(0xCC151721), shape = RoundedCornerShape(25.dp),
            border = BorderStroke(1.dp, Color(0x35FFFFFF)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.padding(start = 17.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(
                    value = value, onValueChange = onValue,
                    modifier = Modifier.weight(1f).padding(vertical = 10.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(color = Silver, fontSize = 14.sp),
                    cursorBrush = SolidColor(Violet),
                    decorationBox = { inner ->
                        if (value.isEmpty()) Text("اكتب إلى XION...", color = Muted, fontSize = 14.sp)
                        inner()
                    }
                )
                IconButton(onClick = onSend, enabled = enabled && value.isNotBlank(),
                    modifier = Modifier.size(42.dp).clip(CircleShape)
                        .background(if (enabled && value.isNotBlank()) Violet else Color(0xFF34313F))) {
                    Icon(Icons.Outlined.ArrowUpward, contentDescription = "إرسال", tint = Color.White)
                }
            }
        }
        Text("قد تحتاج إلى إعداد مزوّد AI من الإعدادات للبدء", color = Color(0xFF656A78),
            fontSize = 9.sp, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), textAlign = TextAlign.Center)
    }
}

@Composable
private fun SettingsDialog(base: String, model: String, key: String,
                           onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var b by remember { mutableStateOf(base) }
    var m by remember { mutableStateOf(model) }
    var k by remember { mutableStateOf(key) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF171923),
        title = { Text("إعدادات الذكاء الاصطناعي", color = Silver, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("اربط مزوّداً متوافقاً مع واجهة OpenAI. لا توجد خدمة مدفوعة مدمجة أو مفتاح مخفي.", color = Muted, fontSize = 12.sp)
                ConfigField("رابط API", b) { b = it }
                ConfigField("اسم النموذج", m) { m = it }
                ConfigField("مفتاح API", k, secret = true) { k = it }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(b.trim(), m.trim(), k.trim()) }) { Text("حفظ", color = Violet) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = Muted) } }
    )
}

@Composable
private fun ConfigField(label: String, value: String, secret: Boolean = false, onChange: (String) -> Unit) {
    Column {
        Text(label, color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(5.dp))
        OutlinedTextField(value, onChange, singleLine = true,
            visualTransformation = if (secret) androidx.compose.ui.text.input.PasswordVisualTransformation()
                                   else androidx.compose.ui.text.input.VisualTransformation.None,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Silver, unfocusedTextColor = Silver,
                focusedBorderColor = Violet, unfocusedBorderColor = Line
            )
        )
    }
}

private val http = OkHttpClient.Builder()
    .connectTimeout(25, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()

private fun askXion(base: String, model: String, key: String, history: List<ChatMessage>): String {
    if (base.isBlank() || model.isBlank() || key.isBlank()) {
        return "حتى أقدر أجاوبك بذكاء، افتح الإعدادات واربط مزوّد AI ومفتاح API. الواجهة جاهزة، لكن ما راح أوهمك أن الردود الذكية تعمل بدون اتصال بموديل."
    }
    return try {
        val msgs = JSONArray()
        history.takeLast(20).forEach {
            msgs.put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text))
        }
        val body = JSONObject().put("model", model).put("messages", msgs).toString()
            .toRequestBody("application/json".toMediaType())
        val endpoint = base.trimEnd('/') + "/chat/completions"
        val request = Request.Builder().url(endpoint).addHeader("Authorization", "Bearer $key")
            .post(body).build()
        http.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) "تعذّر الاتصال بالمزوّد (${response.code}). تحقق من الرابط والمفتاح واسم النموذج."
            else JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        }
    } catch (e: Exception) {
        "صار خطأ أثناء الاتصال: ${e.localizedMessage ?: "تحقق من إعدادات المزوّد والإنترنت"}"
    }
}
