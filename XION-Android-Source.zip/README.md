# XION Android — fresh native foundation

This is a new native Android project (Kotlin + Jetpack Compose), not a WebView wrapper.

## Included
- Premium dark obsidian / violet visual direction
- Animated central XION core
- Native chat layout and message bubbles
- Settings for an OpenAI-compatible API endpoint, model, and key
- Local persistence for provider settings

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then run the `app` configuration.

## AI connection
The app intentionally does not pretend to provide free unlimited AI. Configure an OpenAI-compatible provider in Settings:
- Base URL, e.g. `https://openrouter.ai/api/v1`
- Model ID supported by your provider
- API key

The app calls `/chat/completions`. Provider free tiers, availability, and limits can change.

## Next engineering steps
- Secure credential storage (Android Keystore)
- Streaming responses and cancellation
- Conversation persistence and search
- Image/file attachments and vision support
- Voice input/output and live sessions
- App icon, splash screen, accessibility, localization, and device testing
