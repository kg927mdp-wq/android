plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.xion"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.xion"
        minSdk = 26
        targetSdk = 34
        versionCode = 310
        versionName = "3.1.0-dev"
    }

    // Let Android Gradle Plugin generate/use the standard debug keystore.
    // Do not reference a project-local debug.keystore that is not in the repository.

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
}

dependencies {
    // Only Jetpack Compose (UI). Networking, crypto and JSON use the Android framework and the JDK.
    // Custom "glass" components are used instead of Material 3, so no Material dependency.
    val composeBom = platform("androidx.compose:compose-bom:2024.09.03")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.runtime:runtime")
    implementation("androidx.activity:activity-compose:1.9.2")
    testImplementation("junit:junit:4.13.2")
}
